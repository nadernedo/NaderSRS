import React, { useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet, Dimensions } from 'react-native';
import { BarChart, LineChart, PieChart } from 'react-native-chart-kit';
import { LinearGradient } from 'expo-linear-gradient';
import { T } from '../theme';
import { LEVELS, getLevelFromXP, nDaysAgo, weekDayAr, dayLabel } from '../state';
import { Card } from '../components';

const W = Dimensions.get('window').width;
const CHART_W = W - 32;

const chartCfg = (t) => ({
  backgroundColor: t.card,
  backgroundGradientFrom: t.card,
  backgroundGradientTo: t.card,
  color: (opacity=1) => `rgba(124,58,237,${opacity})`,
  labelColor: () => t.textMuted,
  decimalPlaces: 0,
  propsForDots: { r:'4', strokeWidth:'2', stroke:'#7C3AED' },
  barPercentage: 0.6,
});

export default function StatsScreen({ state, dk }) {
  const t = T(dk);
  const { profile, words, sessions=[], notes=[] } = state;
  const lv  = getLevelFromXP(profile.xp);
  const lvl = LEVELS[lv] || LEVELS[0];
  const mastered = words.filter(w=>w.mastered);
  const hard     = words.filter(w=>w.hard);
  const learning = words.filter(w=>!w.mastered&&!w.hard&&w.correctStreak>0);
  const newW     = words.filter(w=>!w.mastered&&!w.hard&&!w.correctStreak);

  const totalReviews = sessions.reduce((a,s)=>a+(s.total||0),0);
  const totalCorrect = sessions.reduce((a,s)=>a+(s.correct||0),0);
  const accuracy     = totalReviews>0 ? Math.round((totalCorrect/totalReviews)*100) : 0;
  const avgDuration  = sessions.length>0 ? Math.round(sessions.reduce((a,s)=>a+(s.duration||0),0)/sessions.length) : 0;

  // Last 7 days
  const last7 = useMemo(()=>Array.from({length:7},(_,i)=>{
    const d = nDaysAgo(6-i);
    const ds = sessions.filter(s=>s.date===d);
    return {
      day: weekDayAr(d),
      reviewed: ds.reduce((a,s)=>a+(s.total||0),0),
      correct:  ds.reduce((a,s)=>a+(s.correct||0),0),
      added:    words.filter(w=>w.addedDate?.startsWith(d)).length,
    };
  }),[sessions,words]);

  // Pie data for react-native-chart-kit
  const pieData = [
    { name:'متقنة',  population:mastered.length||0, color:'#10B981', legendFontColor:t.text, legendFontSize:12 },
    { name:'تعلم',   population:learning.length||0, color:'#7C3AED', legendFontColor:t.text, legendFontSize:12 },
    { name:'صعبة',   population:hard.length||0,     color:'#EF4444', legendFontColor:t.text, legendFontSize:12 },
    { name:'جديدة',  population:newW.length||0,     color:'#F59E0B', legendFontColor:t.text, legendFontSize:12 },
  ].filter(d=>d.population>0);

  const barData = {
    labels: last7.map(d=>d.day),
    datasets:[{ data:last7.map(d=>d.reviewed||0) }],
  };

  const addedData = {
    labels: last7.map(d=>d.day),
    datasets:[{ data:last7.map(d=>d.added||0), color:(o=1)=>`rgba(245,158,11,${o})` }],
  };

  const thr=[0,200,500,1000,2000];
  const cur=thr[lv]||0, nxt=thr[lv+1]||cur+500;
  const xpPct = Math.min(((profile.xp-cur)/(nxt-cur))*100,100)||0;

  const KPI = ({label,value,color,bg}) => (
    <View style={[s.kpi,{backgroundColor:bg}]}>
      <Text style={[s.kpiVal,{color}]}>{value}</Text>
      <Text style={[s.kpiLbl,{color}]}>{label}</Text>
    </View>
  );

  return (
    <ScrollView style={[s.container,{backgroundColor:t.bg}]} contentContainerStyle={s.content}>
      <Text style={[s.pageTitle,{color:t.text}]}>📊 الإحصائيات</Text>

      {/* Level hero */}
      <LinearGradient colors={['#7C3AED','#5B21B6']} style={s.levelCard}>
        <View style={{flexDirection:'row',alignItems:'center',gap:16}}>
          <Text style={{fontSize:52,lineHeight:60}}>{lvl.icon}</Text>
          <View style={{flex:1}}>
            <Text style={s.levelName}>{lvl.name}</Text>
            <Text style={s.levelXP}>{profile.xp} XP · المستوى {lv+1}/4</Text>
            <View style={s.xpBarBg}>
              <View style={[s.xpBarFill,{width:`${xpPct}%`}]}/>
            </View>
          </View>
        </View>
      </LinearGradient>

      {/* KPI row 1 */}
      <View style={s.kpiRow}>
        <View style={[s.kpiHero,{backgroundColor:'#FF6B6B'}]}>
          <Text style={{fontSize:32}}>🔥</Text>
          <Text style={s.kpiHeroVal}>{profile.streak}</Text>
          <Text style={s.kpiHeroLbl}>سلسلة الأيام</Text>
        </View>
        <View style={[s.kpiHero,{backgroundColor:'#7C3AED'}]}>
          <Text style={{fontSize:32}}>📝</Text>
          <Text style={s.kpiHeroVal}>{words.length}</Text>
          <Text style={s.kpiHeroLbl}>إجمالي الكلمات</Text>
        </View>
      </View>

      {/* KPI row 2 */}
      <View style={s.kpiRow}>
        <KPI label="متقنة"       value={mastered.length} color="#10B981" bg={t.gLight}/>
        <KPI label="دقة الإجابة" value={`${accuracy}%`} color="#7C3AED" bg={t.pLight}/>
        <KPI label="متوسط الجلسة"value={`${avgDuration}ث`} color="#F59E0B" bg={t.goLight}/>
      </View>

      {/* Hint points */}
      <Card dk={dk} style={{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
        <Text style={{fontSize:14,fontWeight:'700',color:t.textSub}}>💡 Hint points</Text>
        <Text style={{fontSize:22,fontWeight:'900',color:t.gold}}>{profile.hintPoints}</Text>
      </Card>

      {/* Bar chart — weekly activity */}
      {last7.some(d=>d.reviewed>0) && (
        <Card dk={dk} style={s.chartCard}>
          <Text style={[s.chartTitle,{color:t.text}]}>📅 النشاط خلال 7 أيام</Text>
          <BarChart
            data={barData}
            width={CHART_W - 32}
            height={180}
            chartConfig={chartCfg(t)}
            style={s.chart}
            showValuesOnTopOfBars
            fromZero
          />
          <View style={s.legend}>
            <View style={s.legendItem}><View style={[s.legendDot,{backgroundColor:'#7C3AED'}]}/><Text style={[s.legendTxt,{color:t.textSub}]}>مراجعة</Text></View>
          </View>
        </Card>
      )}

      {/* Pie chart */}
      {pieData.length > 0 && (
        <Card dk={dk} style={s.chartCard}>
          <Text style={[s.chartTitle,{color:t.text}]}>توزيع الكلمات</Text>
          <PieChart
            data={pieData}
            width={CHART_W - 32}
            height={160}
            chartConfig={chartCfg(t)}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="12"
            style={s.chart}
          />
        </Card>
      )}

      {/* Daily additions */}
      {last7.some(d=>d.added>0) && (
        <Card dk={dk} style={s.chartCard}>
          <Text style={[s.chartTitle,{color:t.text}]}>➕ الكلمات المضافة يومياً</Text>
          <BarChart
            data={addedData}
            width={CHART_W - 32}
            height={160}
            chartConfig={{...chartCfg(t), color:(o=1)=>`rgba(245,158,11,${o})`}}
            style={s.chart}
            fromZero
          />
        </Card>
      )}

      {/* Sessions history */}
      {sessions.length > 0 && (
        <Card dk={dk} style={s.chartCard}>
          <Text style={[s.chartTitle,{color:t.text}]}>⏱️ آخر الجلسات</Text>
          {sessions.slice(-5).reverse().map((ss,i)=>(
            <View key={i} style={[s.sessionRow, i>0 && {borderTopWidth:1,borderTopColor:t.border}]}>
              <View>
                <Text style={[{fontWeight:'700',fontSize:14,color:t.text}]}>{ss.date}</Text>
                <Text style={[{fontSize:12,color:t.textSub,marginTop:2}]}>{ss.total} بطاقة · {ss.duration}ث</Text>
              </View>
              <View style={{alignItems:'flex-end'}}>
                <Text style={{fontWeight:'900',fontSize:16,color:t.green}}>✅ {ss.correct}/{ss.total}</Text>
                <Text style={{fontSize:11,color:t.textMuted}}>{ss.total>0?Math.round((ss.correct/ss.total)*100):0}%</Text>
              </View>
            </View>
          ))}
        </Card>
      )}

      {/* Hardest words */}
      {hard.length > 0 && (
        <Card dk={dk} style={s.chartCard}>
          <Text style={[s.chartTitle,{color:t.text}]}>💪 الكلمات الأصعب</Text>
          {hard.slice(0,5).map((w,i)=>{
            const pct = Math.min(((w.incorrectStreak||0)/5)*100,100);
            return (
              <View key={w.id} style={{marginBottom:10}}>
                <View style={{flexDirection:'row',justifyContent:'space-between',marginBottom:4}}>
                  <Text style={{color:t.text,fontWeight:'700',fontSize:13}}>{w.word}</Text>
                  <Text style={{color:t.red,fontSize:12}}>خطأ ×{w.incorrectStreak||0}</Text>
                </View>
                <View style={{height:6,backgroundColor:t.border,borderRadius:4,overflow:'hidden'}}>
                  <View style={{height:'100%',width:`${pct}%`,backgroundColor:t.red,borderRadius:4}}/>
                </View>
              </View>
            );
          })}
        </Card>
      )}

      {words.length === 0 && (
        <Card dk={dk} style={{alignItems:'center',padding:44}}>
          <Text style={{fontSize:52,marginBottom:10}}>📭</Text>
          <Text style={{color:t.textMuted,textAlign:'center'}}>لا إحصائيات بعد — أضف كلمات وابدأ المراجعة!</Text>
        </Card>
      )}

      <View style={{height:32}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:  { flex:1 },
  content:    { padding:16 },
  pageTitle:  { fontSize:22, fontWeight:'900', marginBottom:18 },
  levelCard:  { borderRadius:18, padding:16, marginBottom:14 },
  levelName:  { fontSize:18, fontWeight:'900', color:'#fff' },
  levelXP:    { fontSize:13, color:'rgba(255,255,255,.85)', marginVertical:4 },
  xpBarBg:    { height:8, backgroundColor:'rgba(255,255,255,.25)', borderRadius:6, overflow:'hidden', marginTop:6 },
  xpBarFill:  { height:'100%', backgroundColor:'rgba(255,255,255,.85)', borderRadius:6 },
  kpiRow:     { flexDirection:'row', gap:10, marginBottom:10 },
  kpiHero:    { flex:1, borderRadius:16, padding:16, alignItems:'center', gap:4 },
  kpiHeroVal: { fontSize:26, fontWeight:'900', color:'#fff' },
  kpiHeroLbl: { fontSize:12, color:'rgba(255,255,255,.85)' },
  kpi:        { flex:1, borderRadius:13, padding:12, alignItems:'center' },
  kpiVal:     { fontSize:22, fontWeight:'900' },
  kpiLbl:     { fontSize:11, marginTop:2 },
  chartCard:  { marginBottom:14, padding:16 },
  chartTitle: { fontSize:14, fontWeight:'900', marginBottom:12 },
  chart:      { borderRadius:12 },
  legend:     { flexDirection:'row', justifyContent:'center', gap:16, marginTop:8 },
  legendItem: { flexDirection:'row', alignItems:'center', gap:5 },
  legendDot:  { width:10, height:10, borderRadius:2 },
  legendTxt:  { fontSize:12 },
  sessionRow: { flexDirection:'row', justifyContent:'space-between', paddingVertical:10 },
});
