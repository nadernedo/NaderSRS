import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, TextInput, Modal,
} from 'react-native';
import { T } from '../theme';
import { GROQ_MODELS, NOTIF_MESSAGES, LANGUAGES } from '../state';
import { testGroqConnection } from '../services/ai';
import { requestPermission, getPermission, scheduleDaily, cancelAll, sendNow } from '../services/notifications';
import { Card, Btn, Inp, Toggle, Row } from '../components';
import { t, isRTL, setUILang } from '../i18n';

const UI_LANGS = [
  { code:'ar', label:'العربية', flag:'🇸🇦' },
  { code:'en', label:'English', flag:'🇺🇸' },
];

// ── Groq Setup Modal ──────────────────────────────────────────────────────────
const GroqModal = ({ settings, dk, onClose, onSave, onToast }) => {
  const T_ = T(dk);
  const rtl = isRTL();
  const [model,   setModel]   = useState(settings.aiModel || 'compound-beta');
  const [key,     setKey]     = useState(settings.groqApiKey || '');
  const [showKey, setShowKey] = useState(false);
  const [testing, setTesting] = useState(false);
  const [result,  setResult]  = useState(null);

  const runTest = async () => {
    if (!key.trim()) { setResult({ok:false,msg:t('apiKey')+' ?'}); return; }
    setTesting(true); setResult(null);
    const r = await testGroqConnection(key.trim(), model);
    setResult(r);
    if (r.ok) onToast({ icon:'✅', title:'Groq API ✅', body: model });
    setTesting(false);
  };

  return (
    <Modal visible animationType="slide" transparent onRequestClose={onClose}>
      <View style={ms.overlay}>
        <View style={[ms.sheet,{backgroundColor:T_.card}]}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <Row style={ms.header}>
              <Text style={[ms.title,{color:T_.text}]}>⚡ Groq API</Text>
              <TouchableOpacity onPress={onClose}><Text style={{fontSize:20,color:T_.textSub}}>✕</Text></TouchableOpacity>
            </Row>

            <Row style={ms.tipRow}>
              <Text style={{fontSize:48}}>🐘</Text>
              <View style={[ms.tipBubble,{backgroundColor:T_.pLight,borderColor:dk?'#3D1F7A':'#DDD6FE'}]}>
                <Text style={[ms.tipTxt,{color:T_.primary}]}>
                  {t('getFree')} console.groq.com 🎉
                </Text>
              </View>
            </Row>

            <Text style={[ms.sectionLabel,{color:T_.text}]}>{t('chooseModel')}</Text>
            {GROQ_MODELS.map(m=>(
              <TouchableOpacity key={m.id} onPress={()=>setModel(m.id)}
                style={[ms.modelRow,{borderColor:model===m.id?'#7C3AED':T_.border,backgroundColor:model===m.id?T_.pLight:T_.card}]}>
                <View style={[ms.radio,{borderColor:model===m.id?'#7C3AED':T_.border,backgroundColor:model===m.id?'#7C3AED':'transparent'}]}>
                  {model===m.id && <View style={ms.radioDot}/>}
                </View>
                <View style={{flex:1}}>
                  <Text style={[ms.modelLabel,{color:T_.text}]}>{m.label}{model===m.id?' ✓':''}</Text>
                  <Text style={[ms.modelDesc,{color:T_.primary}]}>{m.desc}</Text>
                </View>
              </TouchableOpacity>
            ))}

            <Text style={[ms.sectionLabel,{color:T_.text,marginTop:16}]}>{t('apiKey')}</Text>
            <Row style={{gap:8,marginBottom:14}}>
              <Inp value={key} onChange={setKey} type={showKey?'text':'password'} placeholder="gsk_..." dk={dk} style={{flex:1}}/>
              <TouchableOpacity onPress={()=>setShowKey(v=>!v)} style={[ms.eyeBtn,{backgroundColor:T_.pLight}]}>
                <Text style={{fontSize:18}}>👁</Text>
              </TouchableOpacity>
            </Row>

            <Row style={[ms.secRow,{backgroundColor:T_.gLight,borderColor:T_.green}]}>
              <Text style={{fontSize:16}}>🔒</Text>
              <Text style={[ms.secTxt,{color:T_.textSub}]}>{t('securityNote')}</Text>
            </Row>

            {result && (
              <View style={[ms.resultBox,{backgroundColor:result.ok?T_.gLight:T_.rLight,borderColor:result.ok?T_.green:T_.red}]}>
                <Text style={{color:result.ok?T_.green:T_.red,fontSize:13,fontWeight:'600'}}>{result.msg}</Text>
              </View>
            )}

            <Btn onPress={runTest} disabled={testing||!key.trim()} variant="ghost" full dk={dk} style={{marginBottom:10}}>
              {testing ? t('testing') : t('testConnection')}
            </Btn>
            <Btn onPress={()=>{onSave({groqApiKey:key.trim(),aiModel:model});onClose();}} full size="lg">
              {t('saveSettings')}
            </Btn>
            <View style={{height:24}}/>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const ms = StyleSheet.create({
  overlay:   {flex:1,backgroundColor:'rgba(0,0,0,.58)',justifyContent:'flex-end'},
  sheet:     {borderTopLeftRadius:24,borderTopRightRadius:24,padding:20,maxHeight:'92%'},
  header:    {justifyContent:'space-between',marginBottom:18},
  title:     {fontSize:20,fontWeight:'900'},
  tipRow:    {gap:12,alignItems:'flex-start',marginBottom:18},
  tipBubble: {flex:1,borderRadius:14,borderBottomLeftRadius:4,padding:12,borderWidth:1.5},
  tipTxt:    {fontSize:13,fontWeight:'700',lineHeight:22},
  sectionLabel:{fontSize:14,fontWeight:'900',marginBottom:10},
  modelRow:  {flexDirection:'row',alignItems:'center',gap:12,padding:11,borderRadius:12,borderWidth:1.5,marginBottom:8},
  radio:     {width:18,height:18,borderRadius:9,borderWidth:2,alignItems:'center',justifyContent:'center'},
  radioDot:  {width:8,height:8,borderRadius:4,backgroundColor:'#fff'},
  modelLabel:{fontSize:13,fontWeight:'700'},
  modelDesc: {fontSize:11},
  eyeBtn:    {width:46,height:46,borderRadius:12,alignItems:'center',justifyContent:'center'},
  secRow:    {gap:8,padding:10,borderRadius:10,marginBottom:14,borderWidth:1},
  secTxt:    {flex:1,fontSize:12,lineHeight:20},
  resultBox: {padding:10,borderRadius:10,marginBottom:12,borderWidth:1},
});

// ── Settings Screen ───────────────────────────────────────────────────────────
export default function SettingsScreen({ state, dispatch, dk, onToast }) {
  const T_ = T(dk);
  const S  = state.settings;
  const rtl = isRTL();
  const [name,   setName]   = useState(state.profile.name);
  const [saved,  setSaved]  = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [perm,   setPerm]   = useState('default');

  useEffect(()=>{ getPermission().then(setPerm); },[]);

  const toggle = (key) => dispatch({ type:'SAVE_SETTINGS', settings:{ [key]:!S[key] } });

  const saveProfile = () => {
    dispatch({ type:'SAVE_PROFILE', profile:{ name } });
    setSaved(true); setTimeout(()=>setSaved(false),2000);
  };

  const changeUILang = (code) => {
    setUILang(code);
    dispatch({ type:'SAVE_SETTINGS', settings:{ uiLanguage: code } });
  };

  const saveNotifSettings = async (updates) => {
    const merged = { ...S, ...updates };
    dispatch({ type:'SAVE_SETTINGS', settings: updates });
    if (merged.notifEnabled) {
      await scheduleDaily(true, merged.notifTime, merged.notifMessage, merged.notifCustom, state.profile);
    }
  };

  const enableNotifs = async () => {
    const p = await requestPermission();
    setPerm(p);
    if (p === 'granted') {
      dispatch({ type:'SAVE_SETTINGS', settings:{ notifEnabled:true } });
      await scheduleDaily(true, S.notifTime||'20:00', S.notifMessage, S.notifCustom, state.profile);
    } else {
      Alert.alert('', t('notifPermBlocked'));
    }
  };

  const disableNotifs = async () => {
    dispatch({ type:'SAVE_SETTINGS', settings:{ notifEnabled:false } });
    await cancelAll();
  };

  const testNotif = () => sendNow(
    `${t('hello')} ${state.profile.name}! 🐘`,
    (NOTIF_MESSAGES.find(m=>m.id===S.notifMessage)||NOTIF_MESSAGES[0]).text
  );

  const groqLabel = GROQ_MODELS.find(m=>m.id===S.aiModel)?.label || S.aiModel;
  const textAlign = rtl ? 'right' : 'left';

  const SH = ({children}) => (
    <Text style={[s.sectionHeader,{color:T_.textMuted,textAlign:textAlign}]}>{children}</Text>
  );

  return (
    <ScrollView style={[s.container,{backgroundColor:T_.bg}]} contentContainerStyle={s.content}>
      <Text style={[s.pageTitle,{color:T_.text,textAlign:textAlign}]}>{t('settingsTitle')}</Text>

      {/* Profile */}
      <SH>{t('profile')}</SH>
      <Card dk={dk} style={s.card}>
        <Text style={[s.label,{color:T_.textMuted,textAlign:textAlign}]}>{t('yourName')}</Text>
        <Inp value={name} onChange={setName} placeholder={t('yourName')} dk={dk} style={{marginBottom:10,textAlign:textAlign}}/>
        <Btn onPress={saveProfile} full variant={saved?'green':'primary'}>
          {saved ? t('nameSaved') : t('saveName')}
        </Btn>
      </Card>

      {/* UI Language */}
      <SH>{t('uiLanguage')}</SH>
      <Card dk={dk} style={s.card}>
        <Row style={{gap:10}}>
          {UI_LANGS.map(l=>(
            <TouchableOpacity key={l.code} onPress={()=>changeUILang(l.code)}
              style={[s.uiLangBtn, S.uiLanguage===l.code && s.uiLangBtnActive,
                {borderColor:S.uiLanguage===l.code?'#7C3AED':T_.border,
                 backgroundColor:S.uiLanguage===l.code?T_.pLight:T_.cardAlt}]}>
              <Text style={{fontSize:24}}>{l.flag}</Text>
              <Text style={[s.uiLangTxt,{color:S.uiLanguage===l.code?T_.primary:T_.textMuted}]}>{l.label}</Text>
              {S.uiLanguage===l.code && <Text style={{fontSize:14,color:T_.primary}}>✓</Text>}
            </TouchableOpacity>
          ))}
        </Row>
      </Card>

      {/* Study Language */}
      <SH>{t('studyLanguage')}</SH>
      <Card dk={dk} style={s.card}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={{flexDirection:'row',gap:8}}>
            {LANGUAGES.map(l=>(
              <TouchableOpacity key={l.code}
                onPress={()=>dispatch({type:'SAVE_PROFILE',profile:{language:l.code}})}
                style={[s.langChip,
                  {borderColor:state.profile.language===l.code?'#7C3AED':T_.border,
                   backgroundColor:state.profile.language===l.code?T_.pLight:T_.cardAlt}]}>
                <Text style={{fontSize:20}}>{l.flag}</Text>
                <Text style={[s.langTxt,{color:state.profile.language===l.code?T_.primary:T_.textMuted}]}>{l.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </Card>

      {/* Appearance */}
      <SH>{t('appearance')}</SH>
      <Card dk={dk} style={s.card}>
        <Row style={s.settingRow}>
          <Row style={{gap:10,flex:1}}>
            <View style={[s.settingIcon,{backgroundColor:dk?'#2D2D48':'#FFF7ED'}]}>
              <Text style={{fontSize:20}}>{dk?'🌙':'☀️'}</Text>
            </View>
            <View>
              <Text style={[s.settingLabel,{color:T_.text}]}>{dk?t('darkMode'):t('lightMode')}</Text>
              <Text style={[s.settingSub,{color:T_.textSub}]}>{t('tapToToggle')}</Text>
            </View>
          </Row>
          <Toggle value={dk} onChange={()=>toggle('darkMode')}/>
        </Row>
      </Card>

      {/* Notifications */}
      <SH>{t('notifications')}</SH>
      <Card dk={dk} style={s.card}>
        <View style={[s.permRow,{
          backgroundColor:perm==='granted'?T_.gLight:perm==='denied'?T_.rLight:T_.goLight,
          borderColor:(perm==='granted'?T_.green:perm==='denied'?T_.red:T_.gold)+'30',
        }]}>
          <Text style={{fontSize:18}}>{perm==='granted'?'✅':perm==='denied'?'❌':'⏳'}</Text>
          <Text style={[s.permTxt,{color:perm==='granted'?T_.green:perm==='denied'?T_.red:T_.gold}]}>
            {perm==='granted'?t('permGranted'):perm==='denied'?t('permDenied'):t('permPending')}
          </Text>
        </View>

        <Row style={s.settingRow}>
          <Row style={{gap:10,flex:1}}>
            <View style={[s.settingIcon,{backgroundColor:T_.pLight}]}><Text style={{fontSize:20}}>🔔</Text></View>
            <View>
              <Text style={[s.settingLabel,{color:T_.text}]}>{t('dailyReminder')}</Text>
              <Text style={[s.settingSub,{color:T_.textSub}]}>{S.notifEnabled?t('enabled'):t('disabled')}</Text>
            </View>
          </Row>
          <Toggle value={!!S.notifEnabled} onChange={v=>v?enableNotifs():disableNotifs()}/>
        </Row>

        {S.notifEnabled && (
          <View style={{borderTopWidth:1,borderTopColor:T_.border,paddingTop:14,gap:14}}>
            {/* Time picker */}
            <Row style={{justifyContent:'space-between'}}>
              <Row style={{gap:8}}>
                <Text style={{fontSize:18}}>🕐</Text>
                <Text style={[s.settingLabel,{color:T_.text}]}>{t('reminderTime')}</Text>
              </Row>
              <TextInput
                value={S.notifTime||'20:00'}
                onChangeText={v=>saveNotifSettings({notifTime:v})}
                placeholder="20:00"
                keyboardType="numbers-and-punctuation"
                style={[s.timeInput,{borderColor:T_.border,backgroundColor:T_.card,color:T_.text}]}
              />
            </Row>

            {/* Message type */}
            <Text style={[s.settingLabel,{color:T_.text,textAlign:textAlign}]}>{t('messageType')}</Text>
            {NOTIF_MESSAGES.map(m=>(
              <TouchableOpacity key={m.id} onPress={()=>saveNotifSettings({notifMessage:m.id})}
                style={[s.notifMsgRow,{borderColor:S.notifMessage===m.id?'#7C3AED':T_.border,backgroundColor:S.notifMessage===m.id?T_.pLight:T_.cardAlt}]}>
                <View style={[s.radio2,{borderColor:S.notifMessage===m.id?'#7C3AED':T_.border,backgroundColor:S.notifMessage===m.id?'#7C3AED':'transparent'}]}>
                  {S.notifMessage===m.id && <View style={{width:8,height:8,borderRadius:4,backgroundColor:'#fff'}}/>}
                </View>
                <View style={{flex:1}}>
                  <Row style={{gap:6,marginBottom:2}}>
                    <Text style={{fontSize:16}}>{m.icon}</Text>
                    <Text style={[{fontWeight:'700',fontSize:13,color:T_.text}]}>
                      {m.id==='custom'?t('customMessage'):m.text.slice(0,35)+'...'}
                    </Text>
                  </Row>
                  {m.id==='custom'&&S.notifMessage==='custom'&&(
                    <TextInput value={S.notifCustom} onChangeText={v=>saveNotifSettings({notifCustom:v})}
                      placeholder={t('writeCustom')} placeholderTextColor={T_.textMuted}
                      style={[s.customInput,{borderColor:T_.border,backgroundColor:T_.card,color:T_.text,textAlign:textAlign}]}/>
                  )}
                </View>
              </TouchableOpacity>
            ))}

            {/* Preview */}
            <View style={[s.previewBox,{backgroundColor:T_.cardAlt,borderColor:T_.border}]}>
              <Text style={[{fontWeight:'700',fontSize:12,color:T_.textMuted,marginBottom:6,textAlign:textAlign}]}>{t('notifPreview')}</Text>
              <Row style={{gap:10}}>
                <Text style={{fontSize:22}}>🐘</Text>
                <View style={{flex:1}}>
                  <Text style={[{fontWeight:'800',fontSize:13,color:T_.text,textAlign:textAlign}]}>{t('hello')} {state.profile.name}!</Text>
                  <Text style={[{fontSize:12,color:T_.textSub,marginTop:2,lineHeight:18,textAlign:textAlign}]}>
                    {S.notifMessage==='custom'&&S.notifCustom ? S.notifCustom : (NOTIF_MESSAGES.find(m=>m.id===S.notifMessage)||NOTIF_MESSAGES[0]).text}
                  </Text>
                </View>
              </Row>
            </View>

            {perm==='granted' && (
              <Btn onPress={testNotif} variant="ghost" full size="sm" dk={dk}>{t('testNotif')}</Btn>
            )}
          </View>
        )}
      </Card>

      {/* Groq AI */}
      <SH>{t('groqSection')}</SH>
      <Card dk={dk} style={s.card} onPress={()=>setShowAI(true)}>
        <Row style={{justifyContent:'space-between',alignItems:'center'}}>
          <Row style={{gap:10}}>
            <View style={[s.settingIcon,{backgroundColor:T_.pLight}]}><Text style={{fontSize:20}}>⚡</Text></View>
            <View>
              <Text style={[s.settingLabel,{color:T_.text}]}>Groq API</Text>
              <Text style={[s.settingSub,{color:S.groqApiKey?T_.green:T_.red}]}>
                {S.groqApiKey ? `${t('groqAdded')} — ${groqLabel}` : t('groqMissing')}
              </Text>
            </View>
          </Row>
          <Text style={{color:T_.textMuted,fontSize:18}}>›</Text>
        </Row>
      </Card>

      {/* About */}
      <Card dk={dk} style={[s.card,{alignItems:'center',marginTop:4}]}>
        <Text style={{fontSize:42}}>🐘</Text>
        <Text style={[{fontWeight:'900',fontSize:18,color:T_.text,marginTop:8,marginBottom:2}]}>{t('aboutTitle')}</Text>
        <Text style={[{color:T_.textMuted,fontSize:12}]}>{t('aboutSub')}</Text>
      </Card>

      <View style={{height:32}}/>

      {showAI && (
        <GroqModal settings={S} dk={dk}
          onClose={()=>setShowAI(false)}
          onSave={s=>dispatch({type:'SAVE_SETTINGS',settings:s})}
          onToast={onToast}
        />
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:    {flex:1},
  content:      {padding:16},
  pageTitle:    {fontSize:22,fontWeight:'900',marginBottom:18},
  sectionHeader:{fontSize:12,fontWeight:'700',textTransform:'uppercase',letterSpacing:1,marginBottom:8,marginTop:4},
  card:         {marginBottom:14},
  label:        {fontSize:12,fontWeight:'700',textTransform:'uppercase',letterSpacing:1,marginBottom:6},
  uiLangBtn:    {flex:1,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:8,padding:14,borderRadius:14,borderWidth:2},
  uiLangBtnActive:{},
  uiLangTxt:    {fontSize:14,fontWeight:'700'},
  settingRow:   {justifyContent:'space-between',alignItems:'center'},
  settingIcon:  {width:40,height:40,borderRadius:10,alignItems:'center',justifyContent:'center'},
  settingLabel: {fontSize:14,fontWeight:'700'},
  settingSub:   {fontSize:12,marginTop:1},
  langChip:     {alignItems:'center',gap:4,paddingVertical:8,paddingHorizontal:12,borderRadius:12,borderWidth:2},
  langTxt:      {fontSize:12,fontWeight:'700'},
  permRow:      {flexDirection:'row',alignItems:'center',gap:10,padding:10,borderRadius:12,marginBottom:12,borderWidth:1},
  permTxt:      {fontSize:13,fontWeight:'700'},
  timeInput:    {borderWidth:2,borderRadius:10,paddingHorizontal:10,paddingVertical:6,fontSize:15,fontWeight:'700',width:80,textAlign:'center'},
  notifMsgRow:  {flexDirection:'row',alignItems:'flex-start',gap:10,padding:10,borderRadius:12,borderWidth:1.5,marginBottom:6},
  radio2:       {width:18,height:18,borderRadius:9,borderWidth:2,alignItems:'center',justifyContent:'center',marginTop:1,flexShrink:0},
  customInput:  {marginTop:6,padding:8,borderRadius:8,borderWidth:1.5,fontSize:13},
  previewBox:   {borderRadius:12,padding:12,borderWidth:1},
});
