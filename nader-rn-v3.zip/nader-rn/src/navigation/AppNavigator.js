import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { T } from '../theme';
import { t, isRTL } from '../i18n';
import HomeScreen     from '../screens/HomeScreen';
import WordsScreen    from '../screens/WordsScreen';
import AddScreen      from '../screens/AddScreen';
import ReviewScreen   from '../screens/ReviewScreen';
import StatsScreen    from '../screens/StatsScreen';
import SettingsScreen from '../screens/SettingsScreen';

export default function AppNavigator({ state, dispatch, rtl }) {
  const [tab,        setTab]        = useState('home');
  const [showReview, setShowReview] = useState(false);
  const [toast,      setToast]      = useState(null);

  const dk  = state.settings.darkMode;
  const T_  = T(dk);

  const TABS = [
    { id:'home',     icon:'🏠', labelKey:'home'     },
    { id:'words',    icon:'📝', labelKey:'words'    },
    { id:'add',      icon:'➕', labelKey:'add'      },
    { id:'stats',    icon:'📊', labelKey:'stats'    },
    { id:'settings', icon:'⚙️', labelKey:'settings' },
  ];

  const onNav = (id) => {
    if (id === 'review') setShowReview(true);
    else setTab(id);
  };

  if (showReview) return (
    <ReviewScreen state={state} dispatch={dispatch} dk={dk} onComplete={()=>setShowReview(false)}/>
  );

  const screens = {
    home:     <HomeScreen     state={state} dispatch={dispatch} onNav={onNav} dk={dk}/>,
    words:    <WordsScreen    state={state} dispatch={dispatch} dk={dk}/>,
    add:      <AddScreen      state={state} dispatch={dispatch} dk={dk}/>,
    stats:    <StatsScreen    state={state} dk={dk}/>,
    settings: <SettingsScreen state={state} dispatch={dispatch} dk={dk} onToast={setToast}/>,
  };

  return (
    <View style={{flex:1, backgroundColor:T_.bg}}>
      <View style={{flex:1}}>{screens[tab] || screens.home}</View>

      {/* Bottom Nav — flex-direction flips with RTL */}
      <View style={[s.nav, {backgroundColor:T_.card, borderTopColor:T_.border,
        flexDirection: rtl ? 'row-reverse' : 'row'}]}>
        {TABS.map(tb=>{
          const active = tab === tb.id;
          return (
            <TouchableOpacity key={tb.id} onPress={()=>setTab(tb.id)} style={s.navBtn} activeOpacity={0.7}>
              <Text style={[s.navIcon, active && s.navIconActive]}>{tb.icon}</Text>
              <Text style={[s.navLabel, {color:active?'#7C3AED':T_.textMuted, fontWeight:active?'800':'600'}]}>
                {t(tb.labelKey)}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Toast */}
      {toast && (
        <TouchableOpacity style={s.toast} onPress={()=>setToast(null)} activeOpacity={0.9}>
          <Text style={{fontSize:26}}>{toast.icon}</Text>
          <View style={{flex:1}}>
            <Text style={s.toastTitle}>{toast.title}</Text>
            {toast.body && <Text style={s.toastBody}>{toast.body}</Text>}
          </View>
        </TouchableOpacity>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  nav:        {borderTopWidth:1,paddingBottom:8,paddingTop:6,shadowColor:'#000',shadowOffset:{width:0,height:-2},shadowOpacity:0.06,shadowRadius:8,elevation:8},
  navBtn:     {flex:1,alignItems:'center',gap:2,paddingVertical:4},
  navIcon:    {fontSize:22},
  navIconActive:{fontSize:24,transform:[{translateY:-2}]},
  navLabel:   {fontSize:10},
  toast:      {position:'absolute',top:12,left:'5%',width:'90%',backgroundColor:'#7C3AED',borderRadius:16,padding:14,flexDirection:'row',alignItems:'center',gap:10,shadowColor:'#7C3AED',shadowOffset:{width:0,height:8},shadowOpacity:0.5,shadowRadius:20,elevation:16,zIndex:500},
  toastTitle: {color:'#fff',fontWeight:'800',fontSize:13},
  toastBody:  {color:'rgba(255,255,255,.9)',fontSize:12,marginTop:2},
});
