import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, Animated,
} from 'react-native';
import * as Speech from 'expo-speech';
import { T } from '../theme';
import {
  getDueWords, DAILY_CARDS, MASTERED_THRESHOLD, HARD_THRESHOLD,
  nextReviewDate, similarity, todayStr,
} from '../state';
import { aiReviewContent } from '../services/ai';
import { Card, Btn, Inp, Spinner, Elephant } from '../components';
import SmartImage from '../components/SmartImage';
import ParagraphChallenge from './ParagraphChallenge';

const speak = (text, lang) => Speech.speak(text, { language:lang, rate:0.9 });

const speakWithPause = (text, lang) => {
  Speech.stop();
  const parts = text.split('___');
  if (parts.length === 1) { speak(text, lang); return; }
  let i = 0;
  const next = () => {
    if (i >= parts.length) return;
    const chunk = parts[i++];
    if (chunk.trim()) {
      Speech.speak(chunk, { language:lang, rate:0.9, onDone:() => { if(i<parts.length) setTimeout(next,800); else next(); } });
    } else {
      if (i < parts.length) setTimeout(next, 800); else next();
    }
  };
  next();
};

export default function ReviewScreen({ state, dispatch, onComplete, dk }) {
  const t = T(dk);
  const [session,    setSession]    = useState([]);
  const [idx,        setIdx]        = useState(0);
  const [cardData,   setCardData]   = useState(null);
  const [loadingCard,setLoadingCard]= useState(false);
  const [answer,     setAnswer]     = useState('');
  const [revealed,   setRevealed]   = useState(false);
  const [verdict,    setVerdict]    = useState(null);
  const [hintLetter, setHintLetter] = useState(false);
  const [hintLength, setHintLength] = useState(false);
  const [phase,      setPhase]      = useState('review'); // 'review' | 'paragraph'
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const hintUsed  = useRef({ letter:false, length:false });
  const sessionLog= useRef({ correct:0, total:0, startTime:Date.now() });

  const loadCard = useCallback(async (word, settings) => {
    setLoadingCard(true); setAnswer(''); setRevealed(false); setVerdict(null);
    setHintLetter(false); setHintLength(false);
    hintUsed.current = { letter:false, length:false };
    try {
      if (!settings.groqApiKey) throw new Error('no key');
      const c = await aiReviewContent(word.word, word.language, settings);
      setCardData(c);
    } catch {
      const blank = s => s.replace(new RegExp(word.word,'gi'),'___');
      setCardData({ definition:blank(word.definition||''), examples:(word.examples||[]).map(blank) });
    }
    setLoadingCard(false);
  }, []);

  useEffect(() => {
    const due = getDueWords(state.words).slice(0, DAILY_CARDS);
    setSession(due);
    if (due.length > 0) loadCard(due[0], state.settings);
  }, []);

  const shake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim,{toValue:10,duration:80,useNativeDriver:true}),
      Animated.timing(shakeAnim,{toValue:-10,duration:80,useNativeDriver:true}),
      Animated.timing(shakeAnim,{toValue:6,duration:60,useNativeDriver:true}),
      Animated.timing(shakeAnim,{toValue:0,duration:60,useNativeDriver:true}),
    ]).start();
  };

  const checkAnswer = () => {
    const w = session[idx];
    const sim = similarity(answer, w.word);
    const v = sim>=0.99 ? 'correct' : sim>=0.8 ? 'close' : 'wrong';
    if (v === 'wrong') shake();
    setVerdict(v); setRevealed(true);
    sessionLog.current.total++;
    if (v !== 'wrong') sessionLog.current.correct++;
    setTimeout(() => speak(w.word, w.language), 700);
  };

  const rate = async (difficulty) => {
    let w = { ...session[idx] };
    const correct = verdict==='correct' || verdict==='close';
    if (correct) {
      w.correctStreak = (w.correctStreak||0)+1; w.incorrectStreak = 0;
      if (w.correctStreak >= MASTERED_THRESHOLD) w.mastered = true;
    } else {
      w.incorrectStreak = (w.incorrectStreak||0)+1; w.correctStreak = 0;
      if (w.incorrectStreak >= HARD_THRESHOLD) w.hard = true;
    }
    w.difficulty = difficulty;
    w.nextReview = nextReviewDate(difficulty, w.correctStreak);
    dispatch({ type:'UPDATE_WORD', word:w });
    dispatch({ type:'AWARD_XP', amount:correct?10:2 });

    if (idx+1 >= session.length) {
      dispatch({ type:'LOG_SESSION', session:{ date:todayStr(), wordIds:session.map(x=>x.id), correct:sessionLog.current.correct, total:sessionLog.current.total, duration:Math.round((Date.now()-sessionLog.current.startTime)/1000) } });
      setPhase('paragraph');
    } else {
      const ni = idx+1;
      setIdx(ni); loadCard(session[ni], state.settings);
    }
  };

  const useLetterHint = () => {
    if (hintUsed.current.letter) return;
    if ((state.profile.hintPoints||0) < 5) { Alert.alert('','Not enough hint points! (need 5)'); return; }
    hintUsed.current.letter = true;
    dispatch({ type:'SPEND_HINTS', amount:5 });
    setHintLetter(true);
  };

  const useLengthHint = () => {
    if (hintUsed.current.length) return;
    if ((state.profile.hintPoints||0) < 3) { Alert.alert('','Not enough hint points! (need 3)'); return; }
    hintUsed.current.length = true;
    dispatch({ type:'SPEND_HINTS', amount:3 });
    setHintLength(true);
  };

  if (session.length === 0) return (
    <View style={[s.empty,{backgroundColor:t.bg}]}>
      <Text style={s.emptyEmoji}>🎉</Text>
      <Text style={[s.emptyTitle,{color:t.text}]}>Nothing to review today!</Text>
      <Btn onPress={onComplete} style={{marginTop:16}}>Back home</Btn>
    </View>
  );

  if (phase === 'paragraph') return (
    <ParagraphChallenge session={session} state={state} dispatch={dispatch} onComplete={onComplete} dk={dk}/>
  );

  const word = session[idx];
  const prog = (idx / session.length) * 100;

  return (
    <ScrollView style={[s.container,{backgroundColor:t.bg}]} keyboardShouldPersistTaps="handled">
      {/* Progress bar */}
      <View style={s.progressArea}>
        <TouchableOpacity onPress={onComplete}>
          <Text style={[s.backBtn,{color:t.textSub}]}>←</Text>
        </TouchableOpacity>
        <View style={{ flex:1 }}>
          <View style={s.progRow}>
            <Text style={[s.progTxt,{color:t.textSub}]}>البطاقة {idx+1}/{session.length}</Text>
            <Text style={[s.progTxt,{color:t.textSub}]}>+10 XP ⭐</Text>
          </View>
          <View style={[s.barBg,{backgroundColor:t.border}]}>
            <View style={[s.barFill,{width:`${prog}%`}]}/>
          </View>
        </View>
      </View>

      <View style={s.body}>
        {/* Card */}
        <Card dk={dk} style={s.flashcard}>
          {loadingCard ? (
            <View style={s.loadingCard}>
              <Elephant size={56}/>
              <Text style={[s.loadingTxt,{color:t.primary}]}>الفيل يولّد محتوى جديداً...</Text>
            </View>
          ) : cardData && (
            <>
              {word.imageUrl ? (
                <SmartImage src={word.imageUrl} word={word.word} style={s.cardImg}/>
              ) : null}

              <TouchableOpacity
                onPress={()=>speakWithPause(cardData.definition, word.language)}
                style={[s.textBox,{backgroundColor:t.cardAlt,borderColor:t.border}]}
              >
                <Text style={[s.defText,{color:t.text}]}>📖 {cardData.definition}</Text>
                <Text style={s.speakIcon}>🔊</Text>
              </TouchableOpacity>

              {(cardData.examples||[]).map((ex,i)=>(
                <TouchableOpacity key={i}
                  onPress={()=>speakWithPause(ex, word.language)}
                  style={[s.textBox,{backgroundColor:t.cardAlt,borderColor:t.border}]}
                >
                  <Text style={[s.exText,{color:t.text}]}>💡 {ex}</Text>
                  <Text style={s.speakIcon}>🔊</Text>
                </TouchableOpacity>
              ))}
            </>
          )}
        </Card>

        {/* Hints */}
        {!revealed && (
          <View style={s.hintsSection}>
            <View style={s.hintPtsRow}>
              <Text style={[s.hintPtsTxt,{color:t.gold,backgroundColor:t.goLight}]}>
                💡 {state.profile.hintPoints} pts left
              </Text>
            </View>
            <View style={s.hintsRow}>
              <TouchableOpacity
                onPress={useLetterHint}
                style={[s.hintBtn, hintLetter && s.hintBtnUsed, {borderColor:t.primary,backgroundColor:t.pLight}]}
              >
                {hintLetter
                  ? <Text style={[s.hintBtnTxt,{color:t.primary}]}>First letter: <Text style={{fontWeight:'900'}}>{word.word[0].toUpperCase()}</Text></Text>
                  : <Text style={[s.hintBtnTxt,{color:t.primary}]}>💡 First letter (-5 pts)</Text>
                }
              </TouchableOpacity>
              <TouchableOpacity
                onPress={useLengthHint}
                style={[s.hintBtn, hintLength && s.hintBtnUsed, {borderColor:t.blue,backgroundColor:t.bLight}]}
              >
                {hintLength
                  ? <Text style={[s.hintBtnTxt,{color:t.blue}]}>Length: <Text style={{fontWeight:'900'}}>{word.word.length}</Text></Text>
                  : <Text style={[s.hintBtnTxt,{color:t.blue}]}>📏 Word length (-3 pts)</Text>
                }
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Input / Result */}
        {!revealed ? (
          <Animated.View style={{ transform:[{translateX:shakeAnim}] }}>
            <Card dk={dk}>
              <Inp
                value={answer} onChange={setAnswer}
                placeholder="اكتب الكلمة المخفية..."
                dk={dk}
                style={{ textAlign:'center', fontSize:18, fontWeight:'700', marginBottom:12 }}
                autoFocus
              />
              <Btn onPress={checkAnswer} disabled={!answer} full>التحقق ✅</Btn>
            </Card>
          </Animated.View>
        ) : (
          <Card dk={dk} style={[
            s.resultCard,
            verdict==='correct' && {backgroundColor:t.gLight, borderColor:t.green},
            verdict==='close'   && {backgroundColor:t.goLight,borderColor:t.gold},
            verdict==='wrong'   && {backgroundColor:t.rLight, borderColor:t.red},
          ]}>
            <View style={s.resultTop}>
              <Text style={s.resultEmoji}>{verdict==='correct'?'🎉':verdict==='close'?'🤏':'❌'}</Text>
              <Text style={[s.resultTitle,{color:verdict==='correct'?t.green:verdict==='close'?t.gold:t.red}]}>
                {verdict==='correct'?'Nailed it!':verdict==='close'?'So close!':'Not quite!'}
              </Text>
              <TouchableOpacity onPress={()=>speak(word.word,word.language)} style={s.wordRow}>
                <Text style={[s.wordTxt,{color:t.text}]}>Word: <Text style={{fontWeight:'900'}}>{word.word}</Text></Text>
                <Text style={{fontSize:16}}>🔊</Text>
              </TouchableOpacity>
            </View>
            <Text style={[s.rateLabel,{color:t.textMuted}]}>How hard was that to remember?</Text>
            <View style={s.rateBtns}>
              {[{l:'Easy',v:'easy',c:t.green,e:'😄'},{l:'Medium',v:'medium',c:t.gold,e:'😐'},{l:'Hard',v:'hard',c:t.red,e:'😓'}].map(({l,v,c,e})=>(
                <TouchableOpacity key={v} onPress={()=>rate(v)} style={[s.rateBtn,{borderColor:c,backgroundColor:t.card}]}>
                  <Text style={{fontSize:20}}>{e}</Text>
                  <Text style={{color:c,fontWeight:'700',fontSize:13}}>{l}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </Card>
        )}
      </View>
      <View style={{height:32}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:    { flex:1 },
  progressArea: { flexDirection:'row', alignItems:'center', gap:10, paddingHorizontal:20, paddingTop:56, paddingBottom:16 },
  backBtn:      { fontSize:20 },
  progRow:      { flexDirection:'row', justifyContent:'space-between', marginBottom:5 },
  progTxt:      { fontSize:13 },
  barBg:        { height:10, borderRadius:10, overflow:'hidden' },
  barFill:      { height:'100%', backgroundColor:'#7C3AED', borderRadius:10 },
  body:         { padding:16, gap:12 },
  flashcard:    { minHeight:260 },
  loadingCard:  { alignItems:'center', padding:40, gap:12 },
  loadingTxt:   { fontWeight:'700', fontSize:14 },
  cardImg:      { width:'100%', height:130, borderRadius:12, marginBottom:12 },
  textBox:      { borderRadius:12, padding:13, marginBottom:10, borderWidth:1, flexDirection:'row', alignItems:'flex-start' },
  defText:      { fontSize:15, lineHeight:24, flex:1 },
  exText:       { fontSize:14, lineHeight:22, flex:1 },
  speakIcon:    { fontSize:18, marginLeft:8 },
  hintsSection: { gap:8 },
  hintPtsRow:   { alignItems:'flex-end' },
  hintPtsTxt:   { fontSize:12, fontWeight:'700', paddingHorizontal:10, paddingVertical:3, borderRadius:12 },
  hintsRow:     { flexDirection:'row', gap:8 },
  hintBtn:      { flex:1, padding:10, borderRadius:12, borderWidth:2, borderStyle:'dashed', alignItems:'center' },
  hintBtnUsed:  { borderStyle:'solid' },
  hintBtnTxt:   { fontSize:13, fontWeight:'700', textAlign:'center' },
  resultCard:   { borderWidth:2 },
  resultTop:    { alignItems:'center', marginBottom:16, gap:4 },
  resultEmoji:  { fontSize:44 },
  resultTitle:  { fontSize:18, fontWeight:'900' },
  wordRow:      { flexDirection:'row', alignItems:'center', gap:6, marginTop:4 },
  wordTxt:      { fontSize:17 },
  rateLabel:    { fontSize:13, color:'#999', textAlign:'center', marginBottom:12 },
  rateBtns:     { flexDirection:'row', gap:8 },
  rateBtn:      { flex:1, padding:12, borderRadius:12, borderWidth:2, alignItems:'center', gap:4 },
  empty:        { flex:1, alignItems:'center', justifyContent:'center', padding:40 },
  emptyEmoji:   { fontSize:72, marginBottom:14 },
  emptyTitle:   { fontSize:22, fontWeight:'900', textAlign:'center' },
});
