import React, { useState, useEffect, useRef } from 'react';
import { View, Image, Text, ActivityIndicator, StyleSheet } from 'react-native';

// Colour palette based on word's first char
const PALETTES = [
  ['#7C3AED','#C4B5FD'], ['#10B981','#A7F3D0'], ['#F59E0B','#FDE68A'],
  ['#EF4444','#FECACA'], ['#3B82F6','#BFDBFE'], ['#EC4899','#FBCFE8'],
  ['#06B6D4','#A5F3FC'], ['#84CC16','#D9F99D'],
];

const palette = (word='?') => PALETTES[Math.abs((word.charCodeAt(0)||0) % PALETTES.length)];

// Fallback: coloured gradient box with letter
const Fallback = ({ word='?', style={} }) => {
  const [c1, c2] = palette(word);
  const letter   = (word[0]||'?').toUpperCase();
  return (
    <View style={[sf.fallback, style, { backgroundColor: c1 }]}>
      <View style={[sf.circle, { backgroundColor: c2 + 'AA' }]}>
        <Text style={sf.letter}>{letter}</Text>
      </View>
      <Text style={sf.wordTxt} numberOfLines={1}>{word}</Text>
    </View>
  );
};

// SmartImage — handles Pollinations URL loading with states
export default function SmartImage({ src, word, style = {}, resizeMode = 'cover' }) {
  const [phase,  setPhase]  = useState('loading'); // loading | ok | fallback
  const timerRef = useRef(null);

  useEffect(() => {
    if (!src) { setPhase('fallback'); return; }
    setPhase('loading');
    // Pollinations can take up to 20s to generate — give it time
    timerRef.current = setTimeout(() => setPhase('fallback'), 25000);
    return () => clearTimeout(timerRef.current);
  }, [src]);

  const onLoad  = () => { clearTimeout(timerRef.current); setPhase('ok'); };
  const onError = () => { clearTimeout(timerRef.current); setPhase('fallback'); };

  if (!src || phase === 'fallback') {
    return <Fallback word={word} style={style}/>;
  }

  return (
    <View style={[style, { overflow:'hidden' }]}>
      {/* Placeholder visible while loading */}
      {phase === 'loading' && (
        <View style={[StyleSheet.absoluteFill, sf.placeholder]}>
          <Fallback word={word} style={StyleSheet.absoluteFill}/>
          <View style={sf.loadingOverlay}>
            <ActivityIndicator color="#fff" size="small"/>
          </View>
        </View>
      )}
      <Image
        source={{ uri: src, headers: { Accept: 'image/*' } }}
        style={[style, phase !== 'ok' && { opacity: 0 }]}
        resizeMode={resizeMode}
        onLoad={onLoad}
        onError={onError}
      />
    </View>
  );
}

const sf = StyleSheet.create({
  fallback:      { justifyContent:'center', alignItems:'center', gap:6 },
  circle:        { width:60, height:60, borderRadius:30, alignItems:'center', justifyContent:'center' },
  letter:        { fontSize:28, fontWeight:'900', color:'#fff' },
  wordTxt:       { fontSize:12, fontWeight:'700', color:'rgba(255,255,255,.85)', maxWidth:'80%' },
  placeholder:   { overflow:'hidden' },
  loadingOverlay:{ position:'absolute', inset:0, alignItems:'center', justifyContent:'center',
                   backgroundColor:'rgba(0,0,0,.18)' },
});
