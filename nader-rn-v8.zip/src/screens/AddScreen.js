import React, { useState, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Speech from 'expo-speech';
import { T } from '../theme';
import { LOADING_MSGS, randMsg, getImageUrl, todayStr } from '../state';
import { aiGenerateWord } from '../services/ai';
import { Card, Btn, Inp, ErrBox, Elephant, SpeakBtn } from '../components';
import { t, isRTL } from '../i18n';
import SmartImage, { makeImageUrl } from '../components/SmartImage';

export default function AddScreen({ state, dispatch, dk }) {
  const t = T(dk);
  const [input, setInput]       = useState('');
  const [autoImg, setAutoImg]   = useState(true);
  const [loading, setLoading]   = useState(false);
  const [loadMsg, setLoadMsg]   = useState('');
  const [error, setError]       = useState('');
  const [generated, setGenerated] = useState([]);
  const fileRefs = useRef([]);
  const msgInterval = useRef(null);

  const startMsgCycle = () => {
    setLoadMsg(randMsg());
    msgInterval.current = setInterval(()=>setLoadMsg(randMsg()), 2000);
  };
  const stopMsgCycle = () => {
    if (msgInterval.current) { clearInterval(msgInterval.current); msgInterval.current=null; }
  };

  const generate = async () => {
    const words = input.split(',').map(w=>w.trim()).filter(Boolean);
    if (!words.length) { setError('أدخل كلمة على الأقل'); return; }
    if (!state.settings.groqApiKey) { Alert.alert('⚠️','أضف مفتاح Groq API في الإعدادات أولاً'); return; }
    setError(''); setLoading(true); startMsgCycle();
    const results = [];
    for (const word of words) {
      try {
        const c = await aiGenerateWord(word, state.profile.language, state.settings);
        results.push({
          id:`\${Date.now()}-\${Math.random()}`,
          word, language:state.profile.language,
          definition:c.definition,
          examples:c.examples||['',''],
          imageUrl: autoImg ? makeImageUrl(word) : '',
          mastered:false, hard:false,
          correctStreak:0, incorrectStreak:0,
          difficulty:'medium',
          nextReview:todayStr(),
          addedDate:new Date().toISOString(),
        });
      } catch(e) {
        setError(`❌ خطأ في "\${word}": \${e.message}`);
        break;
      }
    }
    stopMsgCycle(); setGenerated(results); setLoading(false);
  };

  const save = () => {
    dispatch({ type:'ADD_WORDS', words:generated });
    setGenerated([]); setInput('');
    Alert.alert('🎉',`تم حفظ \${generated.length} كلمة!`);
  };

  const pickImage = async (idx) => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes:ImagePicker.MediaTypeOptions.Images,
      allowsEditing:true, aspect:[16,9], quality:0.7,
    });
    if (!res.canceled && res.assets[0]) {
      setGenerated(p=>p.map((x,i)=>i===idx?{...x,imageUrl:res.assets[0].uri}:x));
    }
  };

  return (
    <ScrollView style={[s.container,{backgroundColor:t.bg}]} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <Text style={[s.title,{color:t.text}]}>➕ Add New Words</Text>

      {/* Elephant tip */}
      <View style={s.tipRow}>
        <Elephant size={52}/>
        <View style={[s.tipBubble,{backgroundColor:t.pLight,borderColor:dk?'#3D1F7A':'#DDD6FE'}]}>
          <Text style={[s.tipText,{color:t.primary}]}>
            Drop in your words and I'll generate definitions, examples, and images automatically! 🧠
          </Text>
        </View>
      </View>

      <Card dk={dk} style={s.inputCard}>
        <Text style={[s.label,{color:t.textMuted}]}>الكلمة أو عدة كلمات مفصولة بفاصلة</Text>
        <Inp value={input} onChange={setInput} placeholder="مثال: apple, curious, ephemeral" dk={dk} style={{marginBottom:12}}/>

        {/* Auto image toggle */}
        <View style={[s.toggleRow,{backgroundColor:t.cardAlt,borderColor:t.border}]}>
          <Text style={{ fontSize:22 }}>🖼️</Text>
          <View style={{ flex:1 }}>
            <Text style={[s.toggleLabel,{color:t.text}]}>توليد صورة تلقائياً</Text>
            <Text style={[s.toggleSub,{color:t.green}]}>✨ مجاني — Pollinations.ai</Text>
          </View>
          <TouchableOpacity
            onPress={()=>setAutoImg(v=>!v)}
            style={[s.switchBox,{backgroundColor:autoImg?'#7C3AED':'#CCC'}]}
          >
            <View style={[s.switchThumb,{alignSelf:autoImg?'flex-end':'flex-start'}]}/>
          </TouchableOpacity>
        </View>

        <ErrBox msg={error} dk={dk}/>
        <Btn onPress={generate} disabled={loading||!input.trim()} full size="lg">
          {loading ? '⏳ جاري التوليد...' : '✦ توليد بالذكاء الاصطناعي'}
        </Btn>
      </Card>

      {loading && (
        <View style={[s.spinner,{backgroundColor:t.pLight}]}>
          <Elephant size={56}/>
          <ActivityIndicator color="#7C3AED" size="large" style={{marginTop:8}}/>
          <Text style={[s.spinnerTxt,{color:t.primary}]}>{loadMsg}</Text>
        </View>
      )}

      {generated.length > 0 && (
        <View>
          {generated.map((r,idx)=>(
            <Card key={r.id} dk={dk} style={s.wordCard}>
              {/* Header */}
              <View style={s.wordCardHeader}>
                <Text style={[s.wordTitle,{color:t.text}]}>{r.word}</Text>
                <SpeakBtn onPress={()=>Speech.speak(r.word,{language:r.language})} dk={dk}/>
              </View>

              {/* Image */}
              {r.imageUrl ? (
                <SmartImage src={r.imageUrl} word={r.word} style={s.wordImg} onNewUrl={url=>setGenerated(p=>p.map((x,i)=>i===idx?{...x,imageUrl:url}:x))}/>
              ) : null}
              <View style={s.imgBtns}>
                <Btn onPress={()=>setGenerated(p=>p.map((x,i)=>i===idx?{...x,imageUrl:getImageUrl(x.word,x.definition,Date.now())}:x))} variant="ghost" size="sm" dk={dk}>🔄 صورة جديدة</Btn>
                <Btn onPress={()=>pickImage(idx)} variant="white" size="sm" dk={dk}>📤 رفع من الجهاز</Btn>
              </View>

              {/* Definition */}
              <Text style={[s.label,{color:t.textMuted,marginTop:10}]}>التعريف</Text>
              <Inp value={r.definition} onChange={v=>setGenerated(p=>p.map((x,i)=>i===idx?{...x,definition:v}:x))} rows={2} dk={dk} style={{marginBottom:10}}/>

              {/* Examples */}
              {r.examples.map((ex,ei)=>(
                <View key={ei}>
                  <Text style={[s.label,{color:t.textMuted}]}>مثال {ei+1}</Text>
                  <Inp value={ex} onChange={v=>{const e=[...r.examples];e[ei]=v;setGenerated(p=>p.map((x,i)=>i===idx?{...x,examples:e}:x));}} dk={dk} style={{marginBottom:8}}/>
                </View>
              ))}
            </Card>
          ))}
          <Btn onPress={save} full size="lg" variant="gold">💾 حفظ {generated.length} كلمة</Btn>
        </View>
      )}
      <View style={{height:32}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:   { flex:1 },
  content:     { padding:20 },
  title:       { fontSize:22, fontWeight:'900', marginBottom:18 },
  tipRow:      { flexDirection:'row', gap:14, alignItems:'flex-start', marginBottom:16 },
  tipBubble:   { flex:1, borderRadius:16, borderBottomLeftRadius:4, padding:12, borderWidth:1.5 },
  tipText:     { fontSize:13, fontWeight:'700', lineHeight:22 },
  inputCard:   { marginBottom:12 },
  label:       { fontSize:12, fontWeight:'700', textTransform:'uppercase', letterSpacing:1, marginBottom:6 },
  toggleRow:   { flexDirection:'row', alignItems:'center', gap:10, padding:10, borderRadius:12, marginBottom:12, borderWidth:1 },
  toggleLabel: { fontSize:14, fontWeight:'700' },
  toggleSub:   { fontSize:11 },
  switchBox:   { width:50, height:28, borderRadius:14, justifyContent:'center', paddingHorizontal:3 },
  switchThumb: { width:22, height:22, borderRadius:11, backgroundColor:'#fff', shadowColor:'#000', shadowOffset:{width:0,height:1}, shadowOpacity:.2, elevation:2 },
  spinner:     { alignItems:'center', padding:36, borderRadius:16, marginBottom:12 },
  spinnerTxt:  { fontWeight:'700', marginTop:10, fontSize:14, textAlign:'center' },
  wordCard:    { marginBottom:14 },
  wordCardHeader:{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:10 },
  wordTitle:   { fontSize:20, fontWeight:'900' },
  wordImg:     { width:'100%', height:140, borderRadius:10, marginBottom:10 },
  imgBtns:     { flexDirection:'row', gap:8, marginBottom:8 },
});
