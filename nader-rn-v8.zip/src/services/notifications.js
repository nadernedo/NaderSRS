import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { NOTIF_MESSAGES } from '../state';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert:true, shouldPlaySound:true, shouldSetBadge:false }),
});

let _timer = null;

export const requestPermission = async () => {
  if (!Device.isDevice) return 'simulator';
  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === 'granted') return 'granted';
  const { status } = await Notifications.requestPermissionsAsync();
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name:'Nader', importance: Notifications.AndroidImportance.MAX,
    });
  }
  return status;
};

export const getPermission = async () => {
  const { status } = await Notifications.getPermissionsAsync();
  return status;
};

export const sendNow = async (title, body) => {
  await Notifications.scheduleNotificationAsync({
    content:{ title, body, sound:true },
    trigger: null,
  });
};

export const scheduleDaily = async (enabled, timeStr, messageTemplate, customText, profile) => {
  await Notifications.cancelAllScheduledNotificationsAsync();
  if (!_timer) { clearTimeout(_timer); _timer=null; }
  if (!enabled) return;

  const [hh, mm] = (timeStr||"20:00").split(":").map(Number);
  const tpl = NOTIF_MESSAGES.find(m=>m.id===messageTemplate)||NOTIF_MESSAGES[0];
  const body = messageTemplate==="custom" && customText ? customText : tpl.text;
  const title = `مرحباً \${profile?.name||""}! 🐘`;

  await Notifications.scheduleNotificationAsync({
    content:{ title, body, sound:true },
    trigger:{ hour:hh, minute:mm, repeats:true },
  });
};

export const cancelAll = async () => {
  await Notifications.cancelAllScheduledNotificationsAsync();
};
