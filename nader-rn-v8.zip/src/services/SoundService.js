/**
 * SoundService — plays real Duolingo-style MP3 files via expo-av.
 * Audio files are bundled as assets in assets/sounds/.
 */
import { Audio } from 'expo-av';

const SOUND_MAP = {
  correct:   require('../../assets/sounds/correct.mp3'),
  wrong:     require('../../assets/sounds/wrong.mp3'),
  completed: require('../../assets/sounds/completed.mp3'),
};

const soundObjects = {};
let audioReady = false;

export const preloadSounds = async () => {
  if (audioReady) return;
  try {
    await Audio.setAudioModeAsync({ playsInSilentModeIOS: true, staysActiveInBackground: false });
    audioReady = true;
    for (const [name, src] of Object.entries(SOUND_MAP)) {
      const { sound } = await Audio.Sound.createAsync(src, { shouldPlay: false, volume: 1 });
      soundObjects[name] = sound;
    }
  } catch (e) {
    console.log('[SoundService] preload error:', e.message);
  }
};

export const playSound = async (name) => {
  try {
    if (!audioReady) await preloadSounds();
    const sound = soundObjects[name];
    if (!sound) return;
    await sound.setPositionAsync(0);
    await sound.playAsync();
  } catch (e) {
    console.log('[SoundService] play error:', e.message);
  }
};

export const unloadSounds = async () => {
  for (const s of Object.values(soundObjects)) {
    try { await s.unloadAsync(); } catch {}
  }
};
