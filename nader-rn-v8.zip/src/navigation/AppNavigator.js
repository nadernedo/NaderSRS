import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated, Easing } from 'react-native';
import * as Haptics from 'expo-haptics';
import { T }        from '../theme';
import { t, isRTL } from '../i18n';
import HomeScreen     from '../screens/HomeScreen';
import WordsScreen    from '../screens/WordsScreen';
import AddScreen      from '../screens/AddScreen';
import ReviewScreen   from '../screens/ReviewScreen';
import StatsScreen    from '../screens/StatsScreen';
import SettingsScreen from '../screens/SettingsScreen';

const TABS = [
  { id:'home',     icon:'🏠', labelKey:'home'     },
  { id:'words',    icon:'📝', labelKey:'words'    },
  { id:'add',      icon:'➕', labelKey:'add'      },
  { id:'stats',    icon:'📊', labelKey:'stats'    },
  { id:'settings', icon:'⚙️', labelKey:'settings' },
];

// ── Animated screen wrapper ───────────────────────────────────────────────────
const ScreenSlide = ({ children, active }) => {
  const opacity = useRef(new Animated.Value(active ? 1 : 0)).current;
  const scale   = useRef(new Animated.Value(active ? 1 : 0.96)).current;

  useEffect(() => {
    if (active) {
      Animated.parallel([
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.spring(scale,   { toValue: 1, useNativeDriver: true, tension: 100, friction: 12 }),
      ]).start();
    } else {
      opacity.setValue(0);
      scale.setValue(0.96);
    }
  }, [active]);

  // Never unmount — just hide (preserves state)
  return (
    <Animated.View style={[StyleSheet.absoluteFill, { opacity, transform: [{ scale }] }]}
      pointerEvents={active ? 'auto' : 'none'}>
      {children}
    </Animated.View>
  );
};

// ── Animated tab icon ─────────────────────────────────────────────────────────
const TabIcon = ({ icon, labelKey, active, onPress, th }) => {
  const scale  = useRef(new Animated.Value(1)).current;
  const bounce = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (active) {
      Animated.sequence([
        Animated.spring(scale,  { toValue: 1.2, useNativeDriver: true, speed: 60 }),
        Animated.spring(scale,  { toValue: 1.0, useNativeDriver: true, speed: 30 }),
        Animated.timing(bounce, { toValue: -4,  duration: 120, useNativeDriver: true }),
        Animated.timing(bounce, { toValue: 0,   duration: 120, useNativeDriver: true }),
      ]).start();
    }
  }, [active]);

  return (
    <TouchableOpacity onPress={onPress} style={s.navBtn} activeOpacity={0.7}>
      <Animated.Text style={[s.navIcon, { transform: [{ scale }, { translateY: bounce }] }]}>
        {icon}
      </Animated.Text>
      <Text style={[s.navLabel, { color: active ? '#7C3AED' : th.textMuted, fontWeight: active ? '800' : '600' }]}>
        {t(labelKey)}
      </Text>
      {active && <View style={s.activeDot}/>}
    </TouchableOpacity>
  );
};

export default function AppNavigator({ state, dispatch, rtl }) {
  const [tab,        setTab]        = useState('home');
  const [showReview, setShowReview] = useState(false);
  const [toast,      setToast]      = useState(null);
  const toastAnim = useRef(new Animated.Value(-80)).current;

  const dk  = state.settings.darkMode;
  const th  = T(dk);

  // ── Toast animation ──────────────────────────────────────────────────────────
  useEffect(() => {
    if (toast) {
      toastAnim.setValue(-80);
      Animated.sequence([
        Animated.spring(toastAnim, { toValue: 12, useNativeDriver: true, tension: 80, friction: 10 }),
        Animated.delay(2500),
        Animated.timing(toastAnim, { toValue: -80, duration: 300, useNativeDriver: true, easing: Easing.in(Easing.quad) }),
      ]).start(() => setToast(null));
    }
  }, [toast]);

  const onNav = (id) => {
    if (id === 'review') setShowReview(true);
    else setTab(id);
  };

  const screens = {
    home:     <HomeScreen     state={state} dispatch={dispatch} onNav={onNav} dk={dk}/>,
    words:    <WordsScreen    state={state} dispatch={dispatch} dk={dk}/>,
    add:      <AddScreen      state={state} dispatch={dispatch} dk={dk}/>,
    stats:    <StatsScreen    state={state} dk={dk}/>,
    settings: <SettingsScreen state={state} dispatch={dispatch} dk={dk} onToast={(n)=>setToast(n)}/>,
  };

  if (showReview) return (
    <ReviewScreen state={state} dispatch={dispatch} dk={dk} onComplete={()=>setShowReview(false)}/>
  );

  return (
    <View style={[s.container, { backgroundColor: th.bg }]}>
      {/* All screens layered — active one fades/scales in */}
      <View style={{ flex: 1, overflow: 'hidden' }}>
        {TABS.map(tb => (
          <ScreenSlide key={tb.id} active={tab === tb.id}>
            {screens[tb.id]}
          </ScreenSlide>
        ))}
      </View>

      {/* Bottom nav */}
      <View style={[s.nav, { backgroundColor: th.card, borderTopColor: th.border,
        flexDirection: rtl ? 'row-reverse' : 'row' }]}>
        {TABS.map(tb => (
          <TabIcon
            key={tb.id}
            icon={tb.icon}
            labelKey={tb.labelKey}
            active={tab === tb.id}
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(()=>{}); setTab(tb.id); }}
            th={th}
          />
        ))}
      </View>

      {/* Toast */}
      <Animated.View style={[s.toast, { transform: [{ translateY: toastAnim }] }]}
        pointerEvents="none">
        {toast && (
          <TouchableOpacity style={s.toastInner} activeOpacity={0.9}>
            <Text style={{ fontSize: 24 }}>{toast.icon}</Text>
            <View style={{ flex: 1 }}>
              <Text style={s.toastTitle}>{toast.title}</Text>
              {toast.body && <Text style={s.toastBody}>{toast.body}</Text>}
            </View>
          </TouchableOpacity>
        )}
      </Animated.View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex:1 },
  nav:       { borderTopWidth:1, paddingBottom:10, paddingTop:4,
               shadowColor:'#000', shadowOffset:{width:0,height:-2},
               shadowOpacity:0.06, shadowRadius:8, elevation:10 },
  navBtn:    { flex:1, alignItems:'center', gap:2, paddingVertical:4, position:'relative' },
  navIcon:   { fontSize:24 },
  navLabel:  { fontSize:10 },
  activeDot: { position:'absolute', bottom:0, width:4, height:4,
               borderRadius:2, backgroundColor:'#7C3AED' },
  toast:     { position:'absolute', top:0, left:'5%', width:'90%', zIndex:999 },
  toastInner:{ backgroundColor:'#7C3AED', borderRadius:16, padding:14,
               flexDirection:'row', alignItems:'center', gap:10,
               shadowColor:'#7C3AED', shadowOffset:{width:0,height:8},
               shadowOpacity:0.5, shadowRadius:20, elevation:16 },
  toastTitle:{ color:'#fff', fontWeight:'800', fontSize:13 },
  toastBody: { color:'rgba(255,255,255,.9)', fontSize:12, marginTop:2 },
});
