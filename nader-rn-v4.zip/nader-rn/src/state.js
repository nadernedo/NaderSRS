// ══════════════════════════════════════════════════════════════════════════════
// CONSTANTS (same as web)
// ══════════════════════════════════════════════════════════════════════════════
export const LANGUAGES = [
  { code:"en", name:"English",  flag:"🇺🇸" },
  { code:"ar", name:"Arabic",   flag:"🇸🇦" },
  { code:"fr", name:"French",   flag:"🇫🇷" },
  { code:"de", name:"German",   flag:"🇩🇪" },
  { code:"es", name:"Spanish",  flag:"🇪🇸" },
  { code:"ja", name:"Japanese", flag:"🇯🇵" },
  { code:"zh", name:"Chinese",  flag:"🇨🇳" },
  { code:"ko", name:"Korean",   flag:"🇰🇷" },
];
export const LEVELS = [
  { name:"مبتدئ",       icon:"🌱", minXP:0    },
  { name:"كاتب",        icon:"✍️", minXP:200  },
  { name:"محترف",       icon:"🎓", minXP:500  },
  { name:"متحدث أصلي", icon:"🌟", minXP:1000 },
];
export const GROQ_MODELS = [
  { id:"compound-beta",           label:"Compound Beta",        desc:"موصى به — ذكي وسريع" },
  { id:"llama-3.3-70b-versatile", label:"LLaMA 3.3 70B",        desc:"أفضل جودة"            },
  { id:"llama-3.1-8b-instant",    label:"LLaMA 3.1 8B Instant", desc:"الأسرع"               },
  { id:"gemma2-9b-it",            label:"Gemma 2 9B",           desc:"بديل خفيف"            },
];
export const NOTIF_MESSAGES = [
  { id:"streak",   icon:"🔥", text:"لا تطفئ شعلتك! راجع كلماتك اليوم وحافظ على Streak تاعك!" },
  { id:"elephant", icon:"🐘", text:"نادر ينادي! الفيل جاهز لمساعدتك في المراجعة اليومية." },
  { id:"xp",       icon:"⭐", text:"7 بطاقات فقط وتكسب +50 XP اليوم — لا تضيّع الفرصة!" },
  { id:"words",    icon:"📚", text:"كلماتك الجديدة تنتظرك! خصص 5 دقائق فقط للمراجعة." },
  { id:"custom",   icon:"💬", text:"" },
];
export const DAILY_CARDS       = 7;
export const MASTERED_THRESHOLD = 3;
export const HARD_THRESHOLD     = 3;
export const LOADING_MSGS = [
  "الفيل يبحث في القاموس... 📚",
  "الذكاء الاصطناعي يقرأ أفكارك... 🧠",
  "جاري توليد المحتوى السحري... ✨",
  "لحظة صبر... الفيل يشرب الماء 🐘",
  "جاري معالجة الكلمة... 🔄",
];

// ══════════════════════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════════════════════
export const todayStr     = () => new Date().toISOString().split("T")[0];
export const yesterdayStr = () => new Date(Date.now()-86400000).toISOString().split("T")[0];
export const randMsg      = () => LOADING_MSGS[Math.floor(Math.random()*LOADING_MSGS.length)];
export const nDaysAgo     = (n) => { const d=new Date(); d.setDate(d.getDate()-n); return d.toISOString().split("T")[0]; };
export const dayLabel     = (iso) => { const d=new Date(iso); return `${d.getDate()}/${d.getMonth()+1}`; };
export const weekDayAr    = (iso) => ["أحد","إثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت"][new Date(iso).getDay()];
export const getLevelFromXP = (xp) => { let l=0; LEVELS.forEach((_,i)=>{ if(xp>=LEVELS[i].minXP) l=i; }); return l; };

export const levenshtein = (a,b) => {
  const m=a.length,n=b.length;
  const dp=Array.from({length:m+1},(_,i)=>Array.from({length:n+1},(_,j)=>i===0?j:j===0?i:0));
  for(let i=1;i<=m;i++) for(let j=1;j<=n;j++) dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]:1+Math.min(dp[i-1][j],dp[i][j-1],dp[i-1][j-1]);
  return dp[m][n];
};
export const similarity = (a,b) => {
  a=a.toLowerCase().trim(); b=b.toLowerCase().trim();
  if(a===b) return 1;
  const L=Math.max(a.length,b.length);
  return (L-levenshtein(a,b))/L;
};
export const nextReviewDate = (diff,streak) => {
  const ivs={easy:[1,3,7,14,30],medium:[1,2,4,8,16],hard:[1,1,2,3,5]};
  const d=new Date(); d.setDate(d.getDate()+(ivs[diff]||ivs.medium)[Math.min(streak,4)]);
  return d.toISOString().split("T")[0];
};
// Fix #4: respect nextReview — never surface a word before its scheduled date
export const getDueWords = (words) => {
  const today = todayStr();
  return words.filter(w => {
    if (!w.nextReview) return true;          // brand new word, always due
    return w.nextReview <= today;            // due today or overdue
  });
};
export const getStatus     = (w) => w.mastered?"mastered":w.hard?"hard":w.correctStreak>0?"learning":"new";
export const statusLabel   = (s) => ({mastered:"متقنة",hard:"صعبة",learning:"تعلم",new:"جديدة"}[s]||"جديدة");
export const statusColors  = (s,dk) => ({
  mastered:{ bg:dk?"#064E3B":"#ECFDF5", c:"#059669" },
  hard:    { bg:dk?"#7F1D1D":"#FEF2F2", c:"#EF4444" },
  learning:{ bg:dk?"#1E3A5F":"#EFF6FF", c:"#3B82F6" },
  new:     { bg:dk?"#312E81":"#F5F3FF", c:"#7C3AED" },
}[s]||{bg:dk?"#312E81":"#F5F3FF",c:"#7C3AED"});

export const getImageUrl = (word) => {
  const seed = Math.floor(Math.random() * 10000);
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(word)}?seed=${seed}&nologo=true&width=512&height=512`;
};

// ══════════════════════════════════════════════════════════════════════════════
// INITIAL STATE & REDUCER
// ══════════════════════════════════════════════════════════════════════════════
export const initState = () => ({
  onboarded: false,
  profile: { name:"", language:"en", xp:0, streak:0, lastActive:null, hintPoints:30 },
  words: [],
  sessions: [],
  notes: [],
  settings: {
    groqApiKey:"", aiModel:"compound-beta",
    darkMode:false,
    uiLanguage:"ar",
    outputLanguage:"ar",
    notifEnabled:false,
    notifTime:"20:00",
    notifMessage:"streak", notifCustom:"",
    smartModes:{ streak:true, review:true, motivational:false },
  },
});

export const reducer = (state, action) => {
  switch(action.type) {
    case "ONBOARD":
      return {
        ...state, onboarded:true,
        profile:  { ...state.profile, name:action.name, language:action.language },
        settings: { ...state.settings, uiLanguage: action.uiLanguage || 'ar',
                    notifEnabled: true },  // auto-enable notifications on first setup
      };
    case "ADD_WORDS":
      return {...state,words:[...state.words,...action.words],profile:{...state.profile,xp:state.profile.xp+action.words.length*5}};
    case "UPDATE_WORD":
      return {...state,words:state.words.map(w=>w.id===action.word.id?action.word:w)};
    case "DELETE_WORD":
      return {...state,words:state.words.filter(w=>w.id!==action.id)};
    case "SPEND_HINTS": {
      const cost=Math.abs(Number(action.cost??action.amount??5));
      const cur=Number(state.profile.hintPoints)||0;
      return {...state,profile:{...state.profile,hintPoints:Math.max(0,cur-cost)}};
    }
    case "AWARD_XP":
      return {...state,profile:{...state.profile,xp:state.profile.xp+action.amount}};
    case "LOG_SESSION":
      return {...state,sessions:[...state.sessions,action.session]};
    case "SAVE_NOTE":
      return {...state,notes:[...(state.notes||[]),action.note]};
    case "DELETE_NOTE":
      return {...state,notes:(state.notes||[]).filter((_,i)=>i!==action.index)};
    case "COMPLETE_SESSION": {
      const iYest=state.profile.lastActive===yesterdayStr();
      const iToday=state.profile.lastActive===todayStr();
      const streak=iToday?state.profile.streak:iYest?state.profile.streak+1:1;
      return {...state,profile:{...state.profile,xp:state.profile.xp+50,streak,lastActive:todayStr()}};
    }
    case "SAVE_SETTINGS":
      return {...state,settings:{...state.settings,...action.settings}};
    case "SAVE_PROFILE":
      return {...state,profile:{...state.profile,...action.profile}};
    case "_LOAD": return action.state;
    default: return state;
  }
};
