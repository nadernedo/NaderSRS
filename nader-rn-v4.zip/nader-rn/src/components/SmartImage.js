import React, { useState, useEffect, useRef } from 'react';
import { View, Image, Text, ActivityIndicator, StyleSheet } from 'react-native';

// ── Colour palette based on word's first char ────────────────────────────────
const PALETTES = [
  ['#7C3AED','#C4B5FD'], ['#10B981','#A7F3D0'], ['#F59E0B','#FDE68A'],
  ['#EF4444','#FECACA'], ['#3B82F6','#BFDBFE'], ['#EC4899','#FBCFE8'],
  ['#06B6D4','#A5F3FC'], ['#84CC16','#D9F99D'],
];
const palette = (word='?') => PALETTES[Math.abs((word.charCodeAt(0)||0) % PALETTES.length)];

// ── Fallback: coloured box with initial ──────────────────────────────────────
const Fallback = ({ word='?', style={} }) => {
  const [c1, c2] = palette(word);
  const letter = (word[0]||'?').toUpperCase();
  return (
    <View style={[sf.fallback, style, { backgroundColor: c1 }]}>
      <View style={[sf.circle, { backgroundColor: c2 + 'AA' }]}>
        <Text style={sf.letter}>{letter}</Text>
      </View>
      <Text style={sf.wordTxt} numberOfLines={1}>{word}</Text>
    </View>
  );
};

// ── Fetch image as Blob → Base64 ─────────────────────────────────────────────
const fetchAsBase64 = (url) =>
  new Promise((resolve, reject) => {
    fetch(url)
      .then(res => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.blob();
      })
      .then(blob => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result); // data:image/...;base64,...
        reader.onerror  = () => reject(new Error('FileReader failed'));
        reader.readAsDataURL(blob);
      })
      .catch(reject);
  });

// ── SmartImage ────────────────────────────────────────────────────────────────
// Strategy:
//  1. Build Pollinations URL from word (always fresh prompt, no stale seed)
//  2. Fetch as Blob → Base64 (avoids RN's broken redirect + CORS issues)
//  3. On success → show real image
//  4. On timeout (30s) or error → show coloured Fallback
//
export default function SmartImage({ word='', style={} }) {
  const [phase,   setPhase]   = useState('loading'); // loading | ok | fallback
  const [b64,     setB64]     = useState(null);
  const abortRef  = useRef(null);
  const timerRef  = useRef(null);

  useEffect(() => {
    if (!word) { setPhase('fallback'); return; }

    let cancelled = false;
    setPhase('loading');
    setB64(null);

    // 30-second hard timeout
    timerRef.current = setTimeout(() => {
      cancelled = true;
      setPhase('fallback');
    }, 30000);

    const prompt = encodeURIComponent(
      `${word}, minimalist flat illustration, bright colors, white background, no text`
    );
    const url = `https://image.pollinations.ai/prompt/${prompt}?model=turbo&nologo=true&width=512&height=512`;

    fetchAsBase64(url)
      .then(data64 => {
        clearTimeout(timerRef.current);
        if (cancelled) return;
        setB64(data64);
        setPhase('ok');
      })
      .catch(() => {
        clearTimeout(timerRef.current);
        if (!cancelled) setPhase('fallback');
      });

    return () => {
      cancelled = true;
      clearTimeout(timerRef.current);
    };
  }, [word]);

  if (phase === 'fallback' || (!b64 && phase !== 'loading')) {
    return <Fallback word={word} style={style}/>;
  }

  return (
    <View style={[style, { overflow:'hidden' }]}>
      {/* Fallback visible while fetching */}
      {phase === 'loading' && (
        <View style={[StyleSheet.absoluteFill]}>
          <Fallback word={word} style={StyleSheet.absoluteFill}/>
          <View style={sf.loadingOverlay}>
            <ActivityIndicator color="#fff" size="large"/>
            <Text style={sf.loadingTxt}>🎨</Text>
          </View>
        </View>
      )}
      {b64 && (
        <Image
          source={{ uri: b64 }}
          style={[style, phase !== 'ok' && { opacity:0 }]}
          resizeMode="cover"
        />
      )}
    </View>
  );
}

const sf = StyleSheet.create({
  fallback:      { justifyContent:'center', alignItems:'center', gap:6 },
  circle:        { width:64, height:64, borderRadius:32, alignItems:'center', justifyContent:'center' },
  letter:        { fontSize:30, fontWeight:'900', color:'#fff' },
  wordTxt:       { fontSize:12, fontWeight:'700', color:'rgba(255,255,255,.85)', maxWidth:'80%' },
  loadingOverlay:{ ...StyleSheet.absoluteFillObject, alignItems:'center', justifyContent:'center',
                   backgroundColor:'rgba(0,0,0,.25)', gap:6 },
  loadingTxt:    { fontSize:22 },
});
