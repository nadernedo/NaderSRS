/**
 * SmartImage — simple URL-based image with loading/error states.
 * No fetch/blob/FileReader. Just <Image uri={url}> as the user requested.
 */
import React, { useState, useRef } from 'react';
import { View, Image, Text, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';

// ── Colour palette from first char ───────────────────────────────────────────
const PALETTES = [
  ['#7C3AED','#C4B5FD'], ['#10B981','#A7F3D0'], ['#F59E0B','#FDE68A'],
  ['#EF4444','#FECACA'], ['#3B82F6','#BFDBFE'], ['#EC4899','#FBCFE8'],
  ['#06B6D4','#A5F3FC'], ['#84CC16','#D9F99D'],
];
const palette = (word = '?') =>
  PALETTES[Math.abs((word.charCodeAt(0) || 0) % PALETTES.length)];

// ── Coloured fallback box ─────────────────────────────────────────────────────
export const ImageFallback = ({ word = '?', style = {} }) => {
  const [c1, c2] = palette(word);
  return (
    <View style={[s.fallback, style, { backgroundColor: c1 }]}>
      <View style={[s.circle, { backgroundColor: c2 + 'AA' }]}>
        <Text style={s.letter}>{(word[0] || '?').toUpperCase()}</Text>
      </View>
      <Text style={s.wordTxt} numberOfLines={1}>{word}</Text>
    </View>
  );
};

// ── Generate fresh Pollinations URL (with random seed) ────────────────────────
export const makeImageUrl = (word) =>
  `https://image.pollinations.ai/prompt/${encodeURIComponent(word)}?seed=${Math.floor(Math.random() * 10000)}&nologo=true&width=512&height=512`;

// ── SmartImage ────────────────────────────────────────────────────────────────
export default function SmartImage({ src, word = '', style = {}, onNewUrl }) {
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState(false);
  const [imageUrl, setImageUrl] = useState(src || null);

  // When src prop changes, reset state
  React.useEffect(() => {
    setImageUrl(src || null);
    setLoading(!!src);
    setError(false);
  }, [src]);

  const handleLoadStart = () => { setLoading(true); setError(false); };
  const handleLoadEnd   = () => setLoading(false);
  const handleError     = () => { setLoading(false); setError(true); };

  const retry = () => {
    const newUrl = makeImageUrl(word);
    setImageUrl(newUrl);
    setLoading(true);
    setError(false);
    if (onNewUrl) onNewUrl(newUrl);
  };

  // No URL at all → fallback immediately
  if (!imageUrl) return <ImageFallback word={word} style={style}/>;

  // Error → fallback with retry button
  if (error) {
    return (
      <View style={[s.fallback, style, { backgroundColor: palette(word)[0] }]}>
        <ImageFallback word={word} style={StyleSheet.absoluteFill}/>
        <TouchableOpacity onPress={retry} style={s.retryBtn}>
          <Text style={s.retryTxt}>🔄</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[style, { overflow: 'hidden' }]}>
      {/* Show fallback under loading spinner */}
      {loading && (
        <View style={StyleSheet.absoluteFill}>
          <ImageFallback word={word} style={StyleSheet.absoluteFill}/>
          <View style={s.loadingOverlay}>
            <ActivityIndicator color="#fff" size="large"/>
            <Text style={s.loadingEmoji}>🎨</Text>
          </View>
        </View>
      )}

      {/* Actual image — invisible until loaded */}
      <Image
        source={{ uri: imageUrl }}
        style={[style, loading && { opacity: 0 }]}
        resizeMode="cover"
        onLoadStart={handleLoadStart}
        onLoadEnd={handleLoadEnd}
        onError={handleError}
      />
    </View>
  );
}

const s = StyleSheet.create({
  fallback:      { justifyContent: 'center', alignItems: 'center', gap: 6, overflow: 'hidden' },
  circle:        { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  letter:        { fontSize: 30, fontWeight: '900', color: '#fff' },
  wordTxt:       { fontSize: 12, fontWeight: '700', color: 'rgba(255,255,255,.85)', maxWidth: '80%' },
  loadingOverlay:{ ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center',
                   backgroundColor: 'rgba(0,0,0,.2)', gap: 6 },
  loadingEmoji:  { fontSize: 22 },
  retryBtn:      { position: 'absolute', bottom: 8, right: 8, backgroundColor: 'rgba(0,0,0,.4)',
                   borderRadius: 20, padding: 6 },
  retryTxt:      { fontSize: 18 },
});
