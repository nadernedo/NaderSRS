import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator,
} from 'react-native';
import { T } from '../theme';
import { statusColors, statusLabel } from '../state';

// ── Elephant mascot ───────────────────────────────────────────────────────────
export const Elephant = ({ size=68 }) => (
  <Text style={{ fontSize:size, lineHeight:size*1.2 }}>🐘</Text>
);

// ── Card ──────────────────────────────────────────────────────────────────────
export const Card = ({ children, style={}, onPress, dk }) => {
  const t = T(dk);
  const content = (
    <View style={[{
      backgroundColor:t.card, borderRadius:18, padding:16,
      borderWidth:1, borderColor:t.border,
      shadowColor:'#7C3AED', shadowOffset:{width:0,height:2},
      shadowOpacity:0.07, shadowRadius:8, elevation:3,
    }, style]}>
      {children}
    </View>
  );
  if (onPress) return <TouchableOpacity onPress={onPress} activeOpacity={0.85}>{content}</TouchableOpacity>;
  return content;
};

// ── Btn ───────────────────────────────────────────────────────────────────────
const VARIANTS = {
  primary:{ bg:['#8B5CF6','#7C3AED'], txt:'#fff' },
  green:  { bg:['#10B981','#059669'], txt:'#fff' },
  red:    { bg:['#EF4444','#DC2626'], txt:'#fff' },
  gold:   { bg:['#F59E0B','#D97706'], txt:'#fff' },
  ghost:  { bg:null,                  txt:'#7C3AED', border:'#7C3AED' },
  white:  { bg:null,                  txt:'#555',    border:'#E0DCFF'  },
};
const SIZES = {
  sm:{ py:7,  px:14, fs:13, r:10 },
  md:{ py:12, px:20, fs:15, r:13 },
  lg:{ py:15, px:28, fs:16, r:15 },
};
export const Btn = ({ children, onPress, variant='primary', disabled, full, size='md', style={}, dk }) => {
  const [pressed, setPressed] = useState(false);
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = SIZES[size] || SIZES.md;
  const bg = v.bg ? (pressed ? v.bg[1] : v.bg[0]) : (dk ? '#2D2D48' : '#fff');
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      onPressIn={()=>setPressed(true)}
      onPressOut={()=>setPressed(false)}
      activeOpacity={0.85}
      style={[{
        backgroundColor:bg,
        borderRadius:s.r,
        paddingVertical:s.py,
        paddingHorizontal:s.px,
        alignItems:'center',
        justifyContent:'center',
        opacity:disabled ? 0.5 : 1,
        borderWidth: v.border ? 2 : 0,
        borderColor: v.border || 'transparent',
        width: full ? '100%' : undefined,
        transform:[{ translateY: pressed ? 2 : 0 }],
        shadowColor:'#5B21B6',
        shadowOffset:{ width:0, height: pressed ? 1 : 4 },
        shadowOpacity: v.bg ? 0.3 : 0,
        shadowRadius:4, elevation: pressed ? 1 : 4,
      }, style]}
    >
      <Text style={{ color:v.txt||(dk?'#E8E8F0':'#555'), fontSize:s.fs, fontWeight:'800' }}>
        {children}
      </Text>
    </TouchableOpacity>
  );
};

// ── Inp (TextInput) ───────────────────────────────────────────────────────────
export const Inp = ({ value, onChange, placeholder, type='text', rows, style={}, onKeyPress, autoFocus, dk }) => {
  const t = T(dk);
  const [focused, setFocused] = useState(false);
  return (
    <TextInput
      value={value}
      onChangeText={onChange}
      placeholder={placeholder}
      placeholderTextColor={t.textMuted}
      secureTextEntry={type==='password'}
      multiline={!!rows}
      numberOfLines={rows}
      autoFocus={autoFocus}
      onKeyPress={onKeyPress}
      onFocus={()=>setFocused(true)}
      onBlur={()=>setFocused(false)}
      style={[{
        backgroundColor:t.card,
        color:t.text,
        borderRadius:12,
        borderWidth:2,
        borderColor:focused ? '#7C3AED' : t.border,
        paddingHorizontal:14,
        paddingVertical:12,
        fontSize:15,
        fontWeight:'500',
        textAlignVertical: rows ? 'top' : 'center',
        minHeight: rows ? rows*24+24 : undefined,
      }, style]}
    />
  );
};

// ── Toggle ────────────────────────────────────────────────────────────────────
export const Toggle = ({ value, onChange }) => (
  <TouchableOpacity
    onPress={()=>onChange(!value)}
    activeOpacity={0.8}
    style={{
      width:50, height:28, borderRadius:14,
      backgroundColor: value ? '#7C3AED' : '#CCC',
      justifyContent:'center',
      paddingHorizontal:3,
    }}
  >
    <View style={{
      width:22, height:22, borderRadius:11, backgroundColor:'#fff',
      alignSelf: value ? 'flex-end' : 'flex-start',
      shadowColor:'#000', shadowOffset:{width:0,height:1},
      shadowOpacity:0.2, shadowRadius:2, elevation:2,
    }}/>
  </TouchableOpacity>
);

// ── Badge ─────────────────────────────────────────────────────────────────────
export const Badge = ({ status, dk }) => {
  const sc = statusColors(status, dk);
  return (
    <View style={{ backgroundColor:sc.bg, paddingHorizontal:11, paddingVertical:4, borderRadius:20 }}>
      <Text style={{ color:sc.c, fontSize:12, fontWeight:'700' }}>{statusLabel(status)}</Text>
    </View>
  );
};

// ── SpeakBtn ──────────────────────────────────────────────────────────────────
export const SpeakBtn = ({ onPress, size=18, dk }) => {
  const t = T(dk);
  return (
    <TouchableOpacity
      onPress={onPress}
      style={{
        backgroundColor:t.gLight, borderRadius:999,
        width:size+14, height:size+14,
        alignItems:'center', justifyContent:'center',
      }}
    >
      <Text style={{ fontSize:size }}>🔊</Text>
    </TouchableOpacity>
  );
};

// ── Spinner ───────────────────────────────────────────────────────────────────
export const Spinner = ({ dk, message }) => {
  const t = T(dk);
  return (
    <View style={{ alignItems:'center', padding:36, backgroundColor:t.pLight, borderRadius:16 }}>
      <Text style={{ fontSize:56 }}>🐘</Text>
      <ActivityIndicator color='#7C3AED' size='large' style={{ marginTop:8 }}/>
      <Text style={{ color:'#7C3AED', fontWeight:'700', marginTop:10, fontSize:14, textAlign:'center' }}>
        {message}
      </Text>
    </View>
  );
};

// ── ErrBox ────────────────────────────────────────────────────────────────────
export const ErrBox = ({ msg, dk }) => {
  const t = T(dk);
  if (!msg) return null;
  return (
    <View style={{
      backgroundColor:t.rLight, borderRadius:10, padding:12,
      borderWidth:1, borderColor:t.red+'30', marginBottom:10,
    }}>
      <Text style={{ color:t.red, fontSize:13 }}>{msg}</Text>
    </View>
  );
};

// ── Section label ─────────────────────────────────────────────────────────────
export const SectionLabel = ({ children, dk }) => {
  const t = T(dk);
  return (
    <Text style={{
      color:t.textMuted, fontSize:12, fontWeight:'700',
      textTransform:'uppercase', letterSpacing:1,
      marginBottom:8, marginTop:4,
    }}>
      {children}
    </Text>
  );
};

// ── Row (flex row helper) ─────────────────────────────────────────────────────
export const Row = ({ children, style={} }) => (
  <View style={[{ flexDirection:'row', alignItems:'center' }, style]}>
    {children}
  </View>
);
