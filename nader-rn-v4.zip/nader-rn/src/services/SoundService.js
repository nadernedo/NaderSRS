import { Audio } from 'expo-av';

// Cache loaded sounds
const cache = {};

const SOUNDS = {
  correct:   require('../../assets/correct.mp3'),
  wrong:     require('../../assets/wrong.mp3'),
  completed: require('../../assets/completed.mp3'),
};

// Pre-load all sounds once
export const preloadSounds = async () => {
  try {
    await Audio.setAudioModeAsync({ playsInSilentModeIOS: true });
    for (const [key, src] of Object.entries(SOUNDS)) {
      const { sound } = await Audio.Sound.createAsync(src, { shouldPlay: false });
      cache[key] = sound;
    }
  } catch (e) {
    console.log('Sound preload error:', e);
  }
};

export const playSound = async (key) => {
  try {
    const sound = cache[key];
    if (!sound) return;
    await sound.setPositionAsync(0);
    await sound.playAsync();
  } catch (e) {
    console.log('Sound play error:', e);
  }
};

export const unloadSounds = async () => {
  for (const sound of Object.values(cache)) {
    try { await sound.unloadAsync(); } catch {}
  }
};
