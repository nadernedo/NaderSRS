/**
 * SoundService — generates WAV tones in pure JS (no external audio files needed).
 * Tones are built once → cached in /tmp → played via expo-av.
 */
import { Audio }        from 'expo-av';
import * as FileSystem  from 'expo-file-system';

const SR = 22050; // sample rate

// ── Base64 encoder for Uint8Array ─────────────────────────────────────────────
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const toB64 = (bytes) => {
  let r = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const a = bytes[i], b = bytes[i+1]??0, c = bytes[i+2]??0;
    r += B64[a>>2] + B64[((a&3)<<4)|(b>>4)]
       + (i+1<bytes.length ? B64[((b&15)<<2)|(c>>6)] : '=')
       + (i+2<bytes.length ? B64[c&63]              : '=');
  }
  return r;
};

// ── WAV builder from Int16Array samples ───────────────────────────────────────
const buildWAV = (samples) => {
  const n   = samples.length;
  const buf = new ArrayBuffer(44 + n * 2);
  const v   = new DataView(buf);
  const w   = (o, s) => s.split('').forEach((c, i) => v.setUint8(o+i, c.charCodeAt(0)));
  w(0,  'RIFF'); v.setUint32(4,  36 + n*2, true);
  w(8,  'WAVE'); w(12, 'fmt '); v.setUint32(16, 16,   true);
  v.setUint16(20, 1,    true);  // PCM
  v.setUint16(22, 1,    true);  // mono
  v.setUint32(24, SR,   true);  // sample rate
  v.setUint32(28, SR*2, true);  // byte rate
  v.setUint16(32, 2,    true);  // block align
  v.setUint16(34, 16,   true);  // bits per sample
  w(36, 'data'); v.setUint32(40, n*2, true);
  for (let i = 0; i < n; i++) v.setInt16(44 + i*2, samples[i], true);
  return toB64(new Uint8Array(buf));
};

// ── Sine wave generator ────────────────────────────────────────────────────────
const sine = (freq, dur, vol = 0.9, atk = 0.01, rel = 0.08) => {
  const n  = Math.floor(SR * dur);
  const s  = new Int16Array(n);
  for (let i = 0; i < n; i++) {
    const t   = i / SR;
    let env   = 1;
    if (t < atk)          env = t / atk;
    else if (t > dur-rel) env = Math.max(0, (dur-t) / rel);
    s[i] = Math.round(Math.sin(2 * Math.PI * freq * t) * env * vol * 32000);
  }
  return s;
};

// ── Multi-tone concatenation ───────────────────────────────────────────────────
const concat = (...arrs) => {
  const total = arrs.reduce((s, a) => s + a.length, 0);
  const out   = new Int16Array(total);
  let off = 0;
  for (const a of arrs) { out.set(a, off); off += a.length; }
  return out;
};

// ── Sound definitions ─────────────────────────────────────────────────────────
const SOUNDS = {
  //  name         freq    dur   vol  atk   rel
  correct:   buildWAV(sine(880,  0.18, 0.9, 0.005, 0.12)),
  wrong:     buildWAV(concat(sine(220, 0.10, 0.7), sine(196, 0.12, 0.5))),
  completed: buildWAV(concat(
               sine(523, 0.12, 0.8),
               sine(659, 0.12, 0.8),
               sine(784, 0.18, 0.85),
             )),
};

// ── Runtime state ─────────────────────────────────────────────────────────────
const soundObjects = {};
let audioReady     = false;

// ── Write base64 WAV to tmp file, return uri ──────────────────────────────────
const writeSound = async (name, b64) => {
  const uri = `${FileSystem.cacheDirectory}nader_${name}.wav`;
  await FileSystem.writeAsStringAsync(uri, b64, { encoding: FileSystem.EncodingType.Base64 });
  return uri;
};

// ── Preload all sounds ────────────────────────────────────────────────────────
export const preloadSounds = async () => {
  try {
    await Audio.setAudioModeAsync({
      playsInSilentModeIOS:    true,
      staysActiveInBackground: false,
    });
    audioReady = true;

    for (const [name, b64] of Object.entries(SOUNDS)) {
      const uri          = await writeSound(name, b64);
      const { sound }    = await Audio.Sound.createAsync(
        { uri },
        { shouldPlay: false, volume: 1 },
      );
      soundObjects[name] = sound;
    }
  } catch (e) {
    console.log('[SoundService] preload error:', e.message);
  }
};

// ── Play a sound ──────────────────────────────────────────────────────────────
export const playSound = async (name) => {
  try {
    const sound = soundObjects[name];
    if (!sound) return;
    await sound.setPositionAsync(0);
    await sound.playAsync();
  } catch (e) {
    console.log('[SoundService] play error:', e.message);
  }
};

// ── Cleanup ───────────────────────────────────────────────────────────────────
export const unloadSounds = async () => {
  for (const s of Object.values(soundObjects)) {
    try { await s.unloadAsync(); } catch {}
  }
};
