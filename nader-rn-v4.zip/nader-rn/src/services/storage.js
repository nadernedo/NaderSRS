import AsyncStorage from '@react-native-async-storage/async-storage';
import { initState } from '../state';

const KEY = 'nader_app_v4';

export const loadState = async () => {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return initState();
    const saved = JSON.parse(raw);
    const fresh = initState();
    return {
      ...fresh, ...saved,
      profile:  { ...fresh.profile,  ...saved.profile  },
      settings: { ...fresh.settings, ...saved.settings },
      words:    Array.isArray(saved.words)    ? saved.words    : [],
      sessions: Array.isArray(saved.sessions) ? saved.sessions : [],
      notes:    Array.isArray(saved.notes)    ? saved.notes    : [],
    };
  } catch { return initState(); }
};

export const saveState = async (state) => {
  try { await AsyncStorage.setItem(KEY, JSON.stringify(state)); } catch {}
};
