const callGroq = async (apiKey, model, messages) => {
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method:"POST",
    headers:{"Content-Type":"application/json","Authorization":`Bearer ${apiKey}`},
    body:JSON.stringify({model, max_tokens:1000, temperature:0.7, messages}),
  });
  if (!res.ok) { const e=await res.json().catch(()=>({})); throw new Error(e.error?.message||`HTTP ${res.status}`); }
  const d=await res.json();
  return d.choices?.[0]?.message?.content||"";
};

const parseJSON = (raw) => {
  const clean=raw.replace(/```json\s*/gi,"").replace(/```\s*/g,"").trim();
  const m=clean.match(/\{[\s\S]*\}/);
  if(!m) throw new Error("لم يُعَد JSON صالح");
  return JSON.parse(m[0]);
};

export const callAI = (settings, messages) => callGroq(settings.groqApiKey, settings.aiModel, messages);

export const aiGenerateWord = async (word, lang, settings) => {
  const raw = await callAI(settings, [{role:"user",content:
    `You're a friendly language tutor helping someone learn ${lang}.\n`+
    `Give me a clear, natural breakdown of the word "${word}".\n`+
    `Return ONLY a raw JSON object — no markdown, no extra text:\n`+
    `{"definition":"One plain sentence that nails what the word means","examples":["A real-sounding everyday sentence using ${word}","Another natural sentence using ${word} in a different context"]}`
  }]);
  return parseJSON(raw);
};

export const aiReviewContent = async (word, lang, settings) => {
  const raw = await callAI(settings, [{role:"user",content:
    `You're making a fill-in-the-blank flashcard for the ${lang} word "${word}".\n`+
    `Replace every single occurrence of "${word}" with ___ (three underscores).\n`+
    `Return ONLY a raw JSON object — no markdown, no extra text:\n`+
    `{"definition":"The definition with ___ where the word belongs","examples":["A natural sentence with ___ in place of the word","Another everyday sentence with ___ in place of the word"]}`
  }]);
  return parseJSON(raw);
};

export const aiEvaluateParagraph = async (paragraph, words, lang, settings) => {
  const raw = await callAI(settings, [{role:"user",content:
    `You're a chill but thorough ${lang} writing coach.\n`+
    `Target vocab words: ${words.join(", ")}\n`+
    `Student's paragraph: "${paragraph}"\n\n`+
    `Wild stories and creative writing are totally fine — judge grammar and word usage, not realism.\n`+
    `Return ONLY a raw JSON object — no markdown:\n`+
    `{"score":7,"feedback":"One honest sentence summing up their writing","corrections":["Specific fix with before/after if possible","Another concrete correction"],"encouragement":"One punchy motivational line"}`
  }]);
  return parseJSON(raw);
};

export const testGroqConnection = async (apiKey, model) => {
  try {
    const r = await callGroq(apiKey, model, [{role:"user",content:"Reply with one word: OK"}]);
    return { ok:true, msg:`✅ ناجح! رد النموذج: "${r.trim().slice(0,30)}"` };
  } catch(e) {
    return { ok:false, msg:`❌ فشل: ${e.message}` };
  }
};

// Fix #5: generate improved version of paragraph based on corrections
export const aiImprovedParagraph = async (paragraph, corrections, lang, settings) => {
  const raw = await callAI(settings, [{role:"user", content:
    `You are a ${lang} writing coach. Here is a student's paragraph:\n"${paragraph}"\n\n`+
    `These corrections were given:\n${corrections.map((c,i)=>`${i+1}. ${c}`).join('\n')}\n\n`+
    `Rewrite the paragraph applying ALL corrections while keeping the student's original ideas and style.\n`+
    `Return ONLY a raw JSON object:\n`+
    `{"improved":"The fully corrected paragraph here","changes":["Brief description of change 1","Brief description of change 2"]}`
  }]);
  return parseJSON(raw);
};
