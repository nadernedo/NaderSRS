// Maps language codes to full names for AI prompts
const LANG_NAMES = {
  en:'English', ar:'Arabic', fr:'French', de:'German',
  es:'Spanish', ja:'Japanese', zh:'Chinese', ko:'Korean',
};
const getOutputLang = (settings) => LANG_NAMES[settings.outputLanguage || 'ar'] || 'Arabic';

const callGroq = async (apiKey, model, messages) => {
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method:"POST",
    headers:{"Content-Type":"application/json","Authorization":`Bearer ${apiKey}`},
    body:JSON.stringify({model, max_tokens:1000, temperature:0.7, messages}),
  });
  if (!res.ok) { const e=await res.json().catch(()=>({})); throw new Error(e.error?.message||`HTTP ${res.status}`); }
  const d=await res.json();
  return d.choices?.[0]?.message?.content||"";
};

const parseJSON = (raw) => {
  const clean=raw.replace(/```jsons*/gi,"").replace(/```s*/g,"").trim();
  const m=clean.match(/{[sS]*}/);
  if(!m) throw new Error("لم يُعَد JSON صالح");
  return JSON.parse(m[0]);
};

export const callAI = (settings, messages) => callGroq(settings.groqApiKey, settings.aiModel, messages);

export const aiGenerateWord = async (word, lang, settings) => {
  const outLang = getOutputLang(settings);
  const raw = await callAI(settings, [{role:"user",content:
    `You're a friendly language tutor helping someone learn ${lang}.
`+
    `Give me a clear, natural breakdown of the word "${word}".
`+
    `IMPORTANT: Write BOTH the definition AND examples in ${outLang}.
`+
    `Return ONLY a raw JSON object — no markdown, no extra text:
`+
    `{"definition":"One plain ${outLang} sentence that nails what the word means","examples":["A real-sounding ${lang} sentence using ${word}","Another natural ${lang} sentence using ${word} in a different context"]}`
  }]);
  return parseJSON(raw);
};

export const aiReviewContent = async (word, lang, settings) => {
  const outLang = getOutputLang(settings);
  const raw = await callAI(settings, [{role:"user",content:
    `You're making a fill-in-the-blank flashcard for the ${lang} word "${word}".
`+
    `Replace every single occurrence of "${word}" with ___ (three underscores).
`+
    `IMPORTANT: Write the definition and examples in ${outLang}.
`+
    `Return ONLY a raw JSON object — no markdown, no extra text:
`+
    `{"definition":"The ${outLang} definition with ___ where the word belongs","examples":["A natural ${outLang} sentence with ___ in place of the word","Another ${outLang} sentence with ___ in place of the word"]}`
  }]);
  return parseJSON(raw);
};

export const aiEvaluateParagraph = async (paragraph, words, lang, settings) => {
  const outLang = getOutputLang(settings);
  const raw = await callAI(settings, [{role:"user",content:
    `You're a chill but thorough ${lang} writing coach.
`+
    `Target vocab words: ${words.join(", ")}
`+
    `Student's paragraph: "${paragraph}"

`+
    `Wild stories and creative writing are totally fine — judge grammar and word usage, not realism.
`+
    `IMPORTANT: Write all feedback, corrections and encouragement in ${outLang}.
`+
    `Return ONLY a raw JSON object — no markdown:
`+
    `{"score":7,"feedback":"One honest ${outLang} sentence summing up their writing","corrections":["Specific fix in ${outLang} with before/after if possible","Another concrete ${outLang} correction"],"encouragement":"One punchy motivational line in ${outLang}"}`
  }]);
  return parseJSON(raw);
};

export const testGroqConnection = async (apiKey, model) => {
  try {
    const r = await callGroq(apiKey, model, [{role:"user",content:"Reply with one word: OK"}]);
    return { ok:true, msg:`✅ ناجح! رد النموذج: "${r.trim().slice(0,30)}"` };
  } catch(e) {
    return { ok:false, msg:`❌ فشل: ${e.message}` };
  }
};

export const aiImprovedParagraph = async (paragraph, corrections, lang, settings) => {
  const outLang = getOutputLang(settings);
  const raw = await callAI(settings, [{role:"user", content:
    `You are a ${lang} writing coach. Here is a student's paragraph:
"${paragraph}"

`+
    `These corrections were given:
${corrections.map((c,i)=>`${i+1}. ${c}`).join('\n')}

`+
    `Rewrite the paragraph applying ALL corrections while keeping the student's original ideas and style.
`+
    `IMPORTANT: Write change descriptions in ${outLang}.
`+
    `Return ONLY a raw JSON object:
`+
    `{"improved":"The fully corrected paragraph here","changes":["Brief description of change 1 in ${outLang}","Brief description of change 2 in ${outLang}"]}`
  }]);
  return parseJSON(raw);
};
