// Language code → full name mapping
const LANG_NAMES = {
  en:'English', ar:'Arabic', fr:'French', de:'German',
  es:'Spanish', ja:'Japanese', zh:'Chinese', ko:'Korean',
};
const getOutputLang = (s) => LANG_NAMES[s.outputLanguage || 'ar'] || 'Arabic';

const callGroq = async (apiKey, model, messages) => {
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method:'POST',
    headers:{'Content-Type':'application/json','Authorization':'Bearer ' + apiKey},
    body:JSON.stringify({model, max_tokens:1200, temperature:0.7, messages}),
  });
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error((e.error && e.error.message) || 'HTTP ' + res.status);
  }
  const d = await res.json();
  return (d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content) || '';
};

// Robust JSON extractor: strips code fences then finds outermost { }
const parseJSON = (raw) => {
  // Use charCode to avoid literal backticks in this file
  const BT = String.fromCharCode(96);
  const fence = BT + BT + BT;
  let text = raw;
  while (text.indexOf(fence) !== -1) {
    const a = text.indexOf(fence);
    const b = text.indexOf(fence, a + 3);
    if (b === -1) break;
    text = text.slice(0, a) + text.slice(b + 3);
  }
  text = text.trim();
  const first = text.indexOf('{');
  const last  = text.lastIndexOf('}');
  if (first === -1 || last === -1 || last <= first) {
    throw new Error('لم يُعَد JSON صالح');
  }
  try {
    return JSON.parse(text.slice(first, last + 1));
  } catch (e) {
    // Try to fix common issues: trailing commas
    try {
      const fixed = text.slice(first, last + 1).replace(/,s*([}]])/g, '$1');
      return JSON.parse(fixed);
    } catch (_) {
      throw new Error('لم يُعَد JSON صالح');
    }
  }
};

export const callAI = (s, messages) => callGroq(s.groqApiKey, s.aiModel, messages);

export const aiGenerateWord = async (word, lang, settings) => {
  const outLang = getOutputLang(settings);
  const prompt =
    'You are a language tutor. The student is learning ' + lang + '.
' +
    'Define the word: ' + word + '
' +
    'Write the definition and BOTH example sentences in ' + outLang + '.
' +
    'Return ONLY raw JSON — no markdown, no code block, no extra text:
' +
    '{"definition":"<one sentence in ' + outLang + '>","examples":["<sentence using ' + word + '>","<another sentence using ' + word + '>"]}';
  const raw = await callAI(settings, [{role:'user', content: prompt}]);
  return parseJSON(raw);
};

export const aiReviewContent = async (word, lang, settings) => {
  const outLang = getOutputLang(settings);
  const prompt =
    'Make a fill-in-the-blank flashcard for the ' + lang + ' word "' + word + '".
' +
    'Replace EVERY occurrence of "' + word + '" with ___ (three underscores).
' +
    'Write the definition and examples in ' + outLang + '.
' +
    'Return ONLY raw JSON — no markdown, no code block:
' +
    '{"definition":"<' + outLang + ' def with ___ for the word>","examples":["<' + outLang + ' sentence with ___>","<another ' + outLang + ' sentence with ___>"]}';
  const raw = await callAI(settings, [{role:'user', content: prompt}]);
  return parseJSON(raw);
};

export const aiEvaluateParagraph = async (paragraph, words, lang, settings) => {
  const outLang = getOutputLang(settings);
  const wordList = words.join(', ');
  const prompt =
    'You are a ' + lang + ' writing coach. Give ALL feedback in ' + outLang + '.
' +
    'Target vocab words: ' + wordList + '
' +
    'Student paragraph: "' + paragraph + '"

' +
    'Creative writing is OK — judge grammar and vocab usage.
' +
    'Return ONLY raw JSON — no markdown:
' +
    '{"score":7,"feedback":"<one sentence in ' + outLang + '>","corrections":["<fix 1 in ' + outLang + '>","<fix 2>"],"encouragement":"<short line in ' + outLang + '>"}';
  const raw = await callAI(settings, [{role:'user', content: prompt}]);
  return parseJSON(raw);
};

export const testGroqConnection = async (apiKey, model) => {
  try {
    const r = await callGroq(apiKey, model, [{role:'user', content:'Reply with one word: OK'}]);
    return { ok:true, msg:'✅ Connected! Reply: "' + r.trim().slice(0, 30) + '"' };
  } catch(e) {
    return { ok:false, msg:'❌ Failed: ' + e.message };
  }
};

export const aiImprovedParagraph = async (paragraph, corrections, lang, settings) => {
  const outLang = getOutputLang(settings);
  const corrList = corrections.map(function(c, i){ return (i + 1) + '. ' + c; }).join('
');
  const prompt =
    'You are a ' + lang + ' writing coach. Rewrite applying ALL corrections, keep original ideas.
' +
    'Original: "' + paragraph + '"

Corrections:
' + corrList + '

' +
    'Describe changes in ' + outLang + '.
' +
    'Return ONLY raw JSON:
' +
    '{"improved":"<corrected paragraph>","changes":["<change 1 in ' + outLang + '>","<change 2>"]}';
  const raw = await callAI(settings, [{role:'user', content: prompt}]);
  return parseJSON(raw);
};
