import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import * as Haptics from 'expo-haptics';
import { T } from '../theme';
import { t, isRTL } from '../i18n';
import HomeScreen     from '../screens/HomeScreen';
import WordsScreen    from '../screens/WordsScreen';
import AddScreen      from '../screens/AddScreen';
import ReviewScreen   from '../screens/ReviewScreen';
import StatsScreen    from '../screens/StatsScreen';
import SettingsScreen from '../screens/SettingsScreen';

const TABS = [
  { id:'home',     icon:'🏠', labelKey:'home'     },
  { id:'words',    icon:'📝', labelKey:'words'    },
  { id:'add',      icon:'➕', labelKey:'add'      },
  { id:'stats',    icon:'📊', labelKey:'stats'    },
  { id:'settings', icon:'⚙️', labelKey:'settings' },
];

// Animated tab icon
const TabIcon = ({ icon, label, active, onPress }) => {
  const scale = useRef(new Animated.Value(1)).current;
  const color = active ? '#7C3AED' : '#9999BB';

  const press = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.spring(scale, { toValue: 1.3, useNativeDriver: true, speed: 60 }),
      Animated.spring(scale, { toValue: 1,   useNativeDriver: true, speed: 40 }),
    ]).start();
    onPress();
  };

  return (
    <TouchableOpacity onPress={press} style={s.navBtn} activeOpacity={1}>
      <Animated.Text style={[s.navIcon, { transform: [{ scale }] }]}>{icon}</Animated.Text>
      <Text style={[s.navLabel, { color, fontWeight: active ? '800' : '600' }]}>{label}</Text>
      {active && <View style={s.activeDot}/>}
    </TouchableOpacity>
  );
};

export default function AppNavigator({ state, dispatch, rtl }) {
  const [tab,        setTab]        = useState('home');
  const [showReview, setShowReview] = useState(false);
  const [toast,      setToast]      = useState(null);

  // Screen fade animation
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const dk  = state.settings.darkMode;
  const T_  = T(dk);

  const switchTab = (id) => {
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 80, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
    ]).start();
    setTab(id);
  };

  const onNav = (id) => {
    if (id === 'review') setShowReview(true);
    else switchTab(id);
  };

  // Auto-dismiss toast
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  if (showReview) return (
    <ReviewScreen state={state} dispatch={dispatch} dk={dk} onComplete={()=>setShowReview(false)}/>
  );

  const screens = {
    home:     <HomeScreen     state={state} dispatch={dispatch} onNav={onNav} dk={dk}/>,
    words:    <WordsScreen    state={state} dispatch={dispatch} dk={dk}/>,
    add:      <AddScreen      state={state} dispatch={dispatch} dk={dk}/>,
    stats:    <StatsScreen    state={state} dk={dk}/>,
    settings: <SettingsScreen state={state} dispatch={dispatch} dk={dk} onToast={setToast}/>,
  };

  return (
    <View style={{ flex:1, backgroundColor:T_.bg }}>
      {/* Animated screen */}
      <Animated.View style={{ flex:1, opacity:fadeAnim }}>
        {screens[tab] || screens.home}
      </Animated.View>

      {/* Bottom Nav */}
      <View style={[s.nav, {
        backgroundColor: T_.card,
        borderTopColor:  T_.border,
        flexDirection:   rtl ? 'row-reverse' : 'row',
      }]}>
        {TABS.map(tb => (
          <TabIcon
            key={tb.id}
            icon={tb.icon}
            label={t(tb.labelKey)}
            active={tab === tb.id}
            onPress={() => switchTab(tb.id)}
          />
        ))}
      </View>

      {/* Toast */}
      {toast && (
        <TouchableOpacity style={s.toast} onPress={()=>setToast(null)} activeOpacity={0.9}>
          <Text style={{ fontSize:26 }}>{toast.icon}</Text>
          <View style={{ flex:1 }}>
            <Text style={s.toastTitle}>{toast.title}</Text>
            {toast.body && <Text style={s.toastBody}>{toast.body}</Text>}
          </View>
        </TouchableOpacity>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  nav:       { borderTopWidth:1, paddingBottom:8, paddingTop:6,
               shadowColor:'#000', shadowOffset:{width:0,height:-2},
               shadowOpacity:0.06, shadowRadius:8, elevation:8 },
  navBtn:    { flex:1, alignItems:'center', gap:2, paddingVertical:4, position:'relative' },
  navIcon:   { fontSize:22 },
  navLabel:  { fontSize:10 },
  activeDot: { position:'absolute', bottom:-2, width:4, height:4, borderRadius:2, backgroundColor:'#7C3AED' },
  toast:     { position:'absolute', top:12, left:'5%', width:'90%',
               backgroundColor:'#7C3AED', borderRadius:16, padding:14,
               flexDirection:'row', alignItems:'center', gap:10,
               shadowColor:'#7C3AED', shadowOffset:{width:0,height:8},
               shadowOpacity:0.5, shadowRadius:20, elevation:16, zIndex:500 },
  toastTitle:{ color:'#fff', fontWeight:'800', fontSize:13 },
  toastBody: { color:'rgba(255,255,255,.9)', fontSize:12, marginTop:2 },
});
