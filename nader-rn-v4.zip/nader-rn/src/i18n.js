// ══════════════════════════════════════════════════════════════════════════════
// i18n — Arabic (RTL) / English (LTR)
// ══════════════════════════════════════════════════════════════════════════════

const AR = {
  // Nav
  home:'الرئيسية', words:'كلماتي', add:'إضافة',
  stats:'إحصائيات', settings:'إعدادات',

  // Home
  hey:'مرحباً', dailyMission:'مهمة اليوم! 📚',
  crushedIt:'أتقنت كل شيء! ✅', cardsReady:'بطاقة جاهزة للمراجعة',
  allDone:'أنهيت كل شيء اليوم 🎉', startReview:'ابدأ المراجعة! ⚡',
  words_:'كلمات', mastered:'متقن', hard:'صعبة',
  hintPoints:'نقاط التلميح', refreshesDaily:'تتجدد يومياً',
  addFirstWord:'أضف أول كلمة!', addWord:'أضف كلمة ➜',
  level:'المستوى',

  // Add
  addNewWords:'➕ إضافة كلمات جديدة',
  elephantTip:'أدخل الكلمات وسأولّد التعريفات والأمثلة والصور تلقائياً! 🧠',
  wordOrMany:'الكلمة أو عدة كلمات مفصولة بفاصلة',
  wordPlaceholder:'مثال: apple, curious, ephemeral',
  autoImage:'توليد صورة تلقائياً',
  autoImageSub:'✨ مجاني — Pollinations.ai',
  generating:'⏳ جاري التوليد...', generate:'✦ توليد بالذكاء الاصطناعي',
  definition:'التعريف', example:'مثال', saveWords:'💾 حفظ',
  newImage:'🔄 صورة جديدة', uploadImage:'📤 رفع من الجهاز',
  noApiKey:'أضف مفتاح Groq API في الإعدادات أولاً',

  // Review
  card:'البطاقة', correct:'صحيح! 🎉', close:'قريب جداً! 🤏',
  wrong:'خطأ 😅', nailedIt:'أحسنت!', soClose:'قريب جداً!', notQuite:'ليس بعد!',
  typeHidden:'اكتب الكلمة المخفية...', check:'التحقق ✅',
  howHard:'كيف كان التذكر؟', easy:'سهل', medium:'متوسط', hard2:'صعب',
  firstLetter:'💡 أول حرف (-5 نقطة)', wordLength:'📏 عدد الحروف (-3 نقاط)',
  ptsLeft:'نقطة متبقية', generatingCard:'الفيل يولّد محتوى جديداً...',
  nothingToReview:'لا شيء للمراجعة اليوم!', backHome:'العودة للرئيسية',

  // Paragraph
  paragraphChallenge:'تحدي الفقرة!',
  useAllWords:'استخدم جميع الكلمات في فقرة واحدة',
  useFourWords:'استخدم 4 كلمات على الأقل في فقرة واحدة',
  addMoreWords:'أضف كلمات أخرى',
  evaluateParagraph:'🤖 تقييم الفقرة', evaluating:'🐘 الفيل يقيّم...',
  used:'مستخدمة', wordCount:'كلمة',
  corrections:'📝 التصحيحات:', saveCorrections:'💾 احفظ التصحيحات كملاحظة',
  saved_:'✅ تم حفظ الملاحظات!', endSession:'🎊 إنهاء الجلسة! (+50 XP)',
  needFive:'تحتاج 5/10 للاجتياز. عدّل فقرتك وحاول مجدداً! 💪',
  improvedVersion:'✨ النسخة المحسّنة', improveBtn:'✨ أرني النسخة المحسّنة',
  improving:'🤖 يولّد النسخة المحسّنة...',
  improvedLabel:'النسخة المحسّنة التي ولّدها AI:',
  copyImproved:'📋 نسخ', usedImproved:'✅ تم النسخ!',

  // Words
  myWords:'📝 كلماتي', myNotes:'📓 ملاحظاتي',
  searchWord:'ابحث عن كلمة...',
  all:'الكل', learning:'تعلم', new2:'جديدة',
  noWords:'لا كلمات هنا', noNotes:'لا ملاحظات بعد',
  notesHint:'ستظهر هنا تصحيحات الفقرة التي تحفظها بعد كل جلسة',
  nextReview:'المراجعة القادمة:', reviews:'مراجعة',
  correct2:'صحيحة', difficulty:'الصعوبة',
  deleteWord:'حذف الكلمة؟', deleteNote:'حذف الملاحظة؟',
  cancel:'إلغاء', delete:'حذف', save:'💾 حفظ', edit:'✏️',
  regenerate:'🔄 توليد صورة جديدة',

  // Stats
  statistics:'📊 الإحصائيات', streakDays:'سلسلة الأيام',
  totalWords:'إجمالي الكلمات', accuracy:'دقة الإجابة',
  avgSession:'متوسط الجلسة', weeklyActivity:'📅 النشاط خلال 7 أيام',
  wordDistribution:'توزيع الكلمات', dailyAdded:'➕ الكلمات المضافة يومياً',
  lastSessions:'⏱️ آخر الجلسات', hardestWords:'💪 الكلمات الأصعب',
  noStats:'لا إحصائيات بعد — أضف كلمات وابدأ المراجعة!',
  reviewed:'مراجعة', correct3:'صحيحة',
  seconds:'ث',

  // Settings
  settingsTitle:'⚙️ الإعدادات', profile:'👤 الملف الشخصي',
  yourName:'الاسم', saveName:'💾 حفظ الاسم', nameSaved:'✅ تم الحفظ!',
  appearance:'🎨 المظهر', darkMode:'الوضع المظلم', lightMode:'الوضع الفاتح',
  tapToToggle:'اضغط لتبديل المظهر',
  uiLanguage:'🌐 لغة الواجهة',
  studyLanguage:'🌍 لغة الدراسة',
  notifications:'🔔 الإشعارات', dailyReminder:'تذكير يومي',
  enabled:'مفعّل', disabled:'معطّل',
  reminderTime:'وقت التذكير', messageType:'💬 نوع الرسالة',
  notifPreview:'معاينة الإشعار:', testNotif:'🧪 إرسال إشعار تجريبي',
  hello:'مرحباً',
  groqSection:'🤖 الذكاء الاصطناعي — Groq',
  groqAdded:'🟢 مفتاح مُضاف', groqMissing:'🔴 يحتاج مفتاح API',
  chooseModel:'اختر الموديل', apiKey:'مفتاح API', getFree:'📤 احصل مجاناً',
  securityNote:'مفتاحك يُحفظ على جهازك فقط ولا يُرسَل لأي طرف ثالث.',
  testConnection:'📶 اختبر الاتصال', testing:'⏳ جاري الاختبار...',
  saveSettings:'💾 حفظ الإعدادات',
  aboutTitle:'Nader', aboutSub:'تعلّم المفردات بذكاء — v4.0',
  permGranted:'الإشعارات مسموح بها', permDenied:'الإشعارات محجوبة',
  permPending:'في انتظار الإذن',
  notifPermBlocked:'يرجى السماح بالإشعارات من إعدادات الجهاز.',
  customMessage:'رسالة مخصصة', writeCustom:'اكتب رسالتك المخصصة...',

  // Onboarding
  welcome:'Hey, welcome to Nader! 🎉',
  welcomeSub:"Your AI-powered vocab buddy — let's build your word game 🚀",
  letsGo:"Let's go! 🐘",
  whatsYourName:"ما اسمك؟",
  typeName:'اكتب اسمك...',
  next:'التالي ➜',
  whatLang:'ما اللغة التي تريد تعلمها؟',
  chooseUiLang:'اختر لغة الواجهة',
  arabic:'العربية 🇸🇦', english:'English 🇺🇸',
  allSet:'أنت جاهز تماماً',
  startLearning:'ابدأ التعلم! 🚀',
};

const EN = {
  // Nav
  home:'Home', words:'My Words', add:'Add',
  stats:'Stats', settings:'Settings',

  // Home
  hey:'Hey', dailyMission:'Daily mission! 📚',
  crushedIt:'You crushed it! ✅', cardsReady:'cards ready for review',
  allDone:'All done for today 🎉', startReview:'Start review! ⚡',
  words_:'Words', mastered:'Mastered', hard:'Hard',
  hintPoints:'Hint points', refreshesDaily:'Refreshes daily',
  addFirstWord:'Add your first word!', addWord:'Add a word ➜',
  level:'Level',

  // Add
  addNewWords:'➕ Add New Words',
  elephantTip:"Drop in your words and I'll generate definitions, examples, and images automatically! 🧠",
  wordOrMany:'Word or multiple words separated by comma',
  wordPlaceholder:'e.g. apple, curious, ephemeral',
  autoImage:'Generate image automatically',
  autoImageSub:'✨ Free — Pollinations.ai',
  generating:'⏳ Generating...', generate:'✦ Generate with AI',
  definition:'Definition', example:'Example', saveWords:'💾 Save',
  newImage:'🔄 New image', uploadImage:'📤 Upload from device',
  noApiKey:'Add your Groq API key in Settings first',

  // Review
  card:'Card', correct:'Correct! 🎉', close:'So close! 🤏',
  wrong:'Wrong 😅', nailedIt:'Nailed it!', soClose:'So close!', notQuite:'Not quite!',
  typeHidden:'Type the hidden word...', check:'Check ✅',
  howHard:'How hard was that to remember?', easy:'Easy', medium:'Medium', hard2:'Hard',
  firstLetter:'💡 First letter (-5 pts)', wordLength:'📏 Word length (-3 pts)',
  ptsLeft:'pts left', generatingCard:'Elephant is generating new content...',
  nothingToReview:'Nothing to review today!', backHome:'Back home',

  // Paragraph
  paragraphChallenge:'Paragraph Challenge!',
  useAllWords:'Use all words in one paragraph',
  useFourWords:'Use at least 4 words in one paragraph',
  addMoreWords:'Add more words',
  evaluateParagraph:'🤖 Evaluate paragraph', evaluating:'🐘 Evaluating...',
  used:'used', wordCount:'words',
  corrections:'📝 Corrections:', saveCorrections:'💾 Save corrections as note',
  saved_:'✅ Note saved!', endSession:'🎊 End session! (+50 XP)',
  needFive:'Need 5/10 to pass. Edit your paragraph and try again! 💪',
  improvedVersion:'✨ Improved Version', improveBtn:'✨ Show me the improved version',
  improving:'🤖 Generating improved version...',
  improvedLabel:'AI-improved version:',
  copyImproved:'📋 Copy', usedImproved:'✅ Copied!',

  // Words
  myWords:'📝 My Words', myNotes:'📓 My Notes',
  searchWord:'Search for a word...',
  all:'All', learning:'Learning', new2:'New',
  noWords:'No words here', noNotes:'No notes yet',
  notesHint:'Paragraph corrections you save will appear here after each session',
  nextReview:'Next review:', reviews:'Reviews',
  correct2:'Correct', difficulty:'Difficulty',
  deleteWord:'Delete this word?', deleteNote:'Delete this note?',
  cancel:'Cancel', delete:'Delete', save:'💾 Save', edit:'✏️',
  regenerate:'🔄 Regenerate image',

  // Stats
  statistics:'📊 Statistics', streakDays:'Day streak',
  totalWords:'Total words', accuracy:'Answer accuracy',
  avgSession:'Avg session', weeklyActivity:'📅 Activity — last 7 days',
  wordDistribution:'Word distribution', dailyAdded:'➕ Words added daily',
  lastSessions:'⏱️ Recent sessions', hardestWords:'💪 Hardest words',
  noStats:'No stats yet — add words and start reviewing!',
  reviewed:'reviewed', correct3:'correct',
  seconds:'s',

  // Settings
  settingsTitle:'⚙️ Settings', profile:'👤 Profile',
  yourName:'Your name', saveName:'💾 Save name', nameSaved:'✅ Saved!',
  appearance:'🎨 Appearance', darkMode:'Dark mode', lightMode:'Light mode',
  tapToToggle:'Tap to toggle theme',
  uiLanguage:'🌐 Interface Language',
  studyLanguage:'🌍 Study Language',
  notifications:'🔔 Notifications', dailyReminder:'Daily reminder',
  enabled:'Enabled', disabled:'Disabled',
  reminderTime:'Reminder time', messageType:'💬 Message type',
  notifPreview:'Notification preview:', testNotif:'🧪 Send test notification',
  hello:'Hello',
  groqSection:'🤖 AI — Groq',
  groqAdded:'🟢 Key added', groqMissing:'🔴 API key needed',
  chooseModel:'Choose model', apiKey:'API Key', getFree:'📤 Get free key',
  securityNote:'Your key is stored on your device only and never sent to any third party.',
  testConnection:'📶 Test connection', testing:'⏳ Testing...',
  saveSettings:'💾 Save settings',
  aboutTitle:'Nader', aboutSub:'Smart vocabulary learning — v4.0',
  permGranted:'Notifications allowed', permDenied:'Notifications blocked',
  permPending:'Waiting for permission',
  notifPermBlocked:'Please allow notifications in device settings.',
  customMessage:'Custom message', writeCustom:'Write your custom message...',

  // Onboarding
  welcome:'Hey, welcome to Nader! 🎉',
  welcomeSub:"Your AI-powered vocab buddy — let's build your word game 🚀",
  letsGo:"Let's go! 🐘",
  whatsYourName:"What's your name?",
  typeName:'Type your name...',
  next:'Next ➜',
  whatLang:'What language are you learning?',
  chooseUiLang:'Choose interface language',
  arabic:'العربية 🇸🇦', english:'English 🇺🇸',
  allSet:"You're all set",
  startLearning:'Start learning! 🚀',
};

let _lang = 'ar';

export const setUILang = (lang) => { _lang = lang; };
export const getUILang = () => _lang;
export const isRTL     = () => _lang === 'ar';
export const t         = (key) => (_lang === 'ar' ? AR : EN)[key] ?? EN[key] ?? key;

// ── Weekday labels ─────────────────────────────────────────────────────────
export const weekDays = {
  ar: ['أحد','إثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'],
  en: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
};
export const weekDayLabel = (iso) => {
  const day = new Date(iso).getDay();
  return weekDays[_lang]?.[day] ?? weekDays.en[day];
};

// ── Level names ────────────────────────────────────────────────────────────
export const levelNames = {
  ar: ['مبتدئ','كاتب','محترف','متحدث أصلي'],
  en: ['Beginner','Writer','Pro','Native'],
};
export const levelName = (idx) => (levelNames[_lang] ?? levelNames.en)[idx] ?? '';
