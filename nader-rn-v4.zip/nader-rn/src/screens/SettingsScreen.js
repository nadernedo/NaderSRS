import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Alert, TextInput, Modal, Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { T } from '../theme';
import { GROQ_MODELS, NOTIF_MESSAGES, LANGUAGES } from '../state';
import { testGroqConnection } from '../services/ai';
import { requestPermission, getPermission, scheduleDaily, cancelAll, sendNow } from '../services/notifications';
import { Card, Btn, Inp, Toggle, Row } from '../components';
import { t, isRTL, setUILang } from '../i18n';

const UI_LANGS = [
  { code:'ar', label:'العربية', flag:'🇸🇦' },
  { code:'en', label:'English', flag:'🇺🇸' },
];

const AVATARS = ['🐘','🦁','🐯','🦊','🐺','🦅','🦋','🐬','🦄','🌟','🎓','🏆'];

// ─── Shared Modal Shell ───────────────────────────────────────────────────────
const ModalShell = ({ visible, onClose, title, dk, children }) => {
  const th = T(dk);
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={ms.overlay}>
        <View style={[ms.sheet, { backgroundColor:th.card }]}>
          <Row style={ms.header}>
            <Text style={[ms.title, { color:th.text }]}>{title}</Text>
            <TouchableOpacity onPress={onClose}>
              <Text style={{ fontSize:20, color:th.textSub }}>✕</Text>
            </TouchableOpacity>
          </Row>
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            {children}
            <View style={{ height:32 }}/>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

// ─── Profile Modal ────────────────────────────────────────────────────────────
const ProfileModal = ({ state, dispatch, dk, onClose }) => {
  const th   = T(dk);
  const rtl  = isRTL();
  const [name,      setName]      = useState(state.profile.name);
  const [avatar,    setAvatar]    = useState(state.profile.avatar || '🐘');
  const [uiLang,    setUiLang_]   = useState(state.settings.uiLanguage || 'ar');
  const [studyLang, setStudyLang] = useState(state.profile.language || 'en');
  const [avatarImg, setAvatarImg] = useState(state.profile.avatarImage || null);

  const pickPhoto = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, aspect:[1,1], quality:0.6,
    });
    if (!res.canceled && res.assets[0]) setAvatarImg(res.assets[0].uri);
  };

  const save = () => {
    setUILang(uiLang);
    dispatch({ type:'SAVE_SETTINGS', settings:{ uiLanguage: uiLang } });
    dispatch({ type:'SAVE_PROFILE',  profile:{ name, avatar, avatarImage:avatarImg, language:studyLang } });
    onClose();
  };

  const ta = rtl ? 'right' : 'left';

  return (
    <ModalShell visible title={t('profile')} dk={dk} onClose={onClose}>
      {/* Avatar */}
      <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>
        {t('avatar') || 'Avatar'}
      </Text>
      <View style={{ alignItems:'center', marginBottom:16 }}>
        <TouchableOpacity onPress={pickPhoto} style={[ms.avatarCircle, { backgroundColor:th.pLight }]}>
          {avatarImg
            ? <Image source={{ uri:avatarImg }} style={ms.avatarImg}/>
            : <Text style={{ fontSize:56 }}>{avatar}</Text>
          }
          <View style={ms.avatarEditBadge}>
            <Text style={{ fontSize:14 }}>📷</Text>
          </View>
        </TouchableOpacity>
        {avatarImg && (
          <TouchableOpacity onPress={()=>setAvatarImg(null)} style={{ marginTop:6 }}>
            <Text style={{ color:th.red, fontSize:12 }}>✕ {t('cancel') || 'Remove'}</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Emoji avatars */}
      <View style={ms.avatarGrid}>
        {AVATARS.map(a=>(
          <TouchableOpacity key={a} onPress={()=>{ setAvatar(a); setAvatarImg(null); }}
            style={[ms.avatarBtn, { backgroundColor: avatar===a&&!avatarImg ? th.pLight : th.cardAlt,
              borderColor: avatar===a&&!avatarImg ? '#7C3AED' : th.border }]}>
            <Text style={{ fontSize:24 }}>{a}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Name */}
      <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>{t('yourName')}</Text>
      <Inp value={name} onChange={setName} placeholder={t('yourName')} dk={dk}
        style={{ marginBottom:16, textAlign:ta }}/>

      {/* UI Language */}
      <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>{t('uiLanguage')}</Text>
      <Row style={{ gap:10, marginBottom:16 }}>
        {UI_LANGS.map(l=>(
          <TouchableOpacity key={l.code} onPress={()=>setUiLang_(l.code)}
            style={[ms.langBtn, { borderColor:uiLang===l.code?'#7C3AED':th.border,
              backgroundColor:uiLang===l.code?th.pLight:th.cardAlt }]}>
            <Text style={{ fontSize:24 }}>{l.flag}</Text>
            <Text style={[ms.langBtnTxt, { color:uiLang===l.code?th.primary:th.textMuted }]}>{l.label}</Text>
            {uiLang===l.code && <Text style={{ color:th.primary }}>✓</Text>}
          </TouchableOpacity>
        ))}
      </Row>

      {/* Study Language */}
      <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>{t('studyLanguage')}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom:16 }}>
        <View style={{ flexDirection:'row', gap:8 }}>
          {LANGUAGES.map(l=>(
            <TouchableOpacity key={l.code} onPress={()=>setStudyLang(l.code)}
              style={[ms.studyChip, { borderColor:studyLang===l.code?'#7C3AED':th.border,
                backgroundColor:studyLang===l.code?th.pLight:th.cardAlt }]}>
              <Text style={{ fontSize:20 }}>{l.flag}</Text>
              <Text style={[ms.studyChipTxt, { color:studyLang===l.code?th.primary:th.textMuted }]}>{l.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Save */}
      <Btn onPress={save} full size="lg">💾 {t('saveName').replace('💾 ','')}</Btn>
    </ModalShell>
  );
};

// ─── Smart Notifications Modal ────────────────────────────────────────────────
const SMART_SCHEDULES = [
  {
    id:'streak',
    icon:'🔥',
    titleKey:'notifStreak',
    title_ar:'حماية الاستمرارية',
    title_en:'Streak Protection',
    desc_ar:'إشعار تلقائي عند اقتراب انقطاع السلسلة اليومية',
    desc_en:'Auto notification when daily streak is at risk',
  },
  {
    id:'review',
    icon:'📚',
    titleKey:'notifReview',
    title_ar:'وقت المراجعة',
    title_en:'Review Time',
    desc_ar:'تذكير يومي عند حلول موعد مراجعة البطاقات',
    desc_en:'Daily reminder when cards are due for review',
  },
  {
    id:'motivational',
    icon:'💪',
    titleKey:'notifMotiv',
    title_ar:'رسائل تحفيزية',
    title_en:'Motivational Messages',
    desc_ar:'رسائل تشجيعية عشوائية طوال اليوم',
    desc_en:'Random encouraging messages throughout the day',
  },
];

const NotificationsModal = ({ state, dispatch, dk, onClose }) => {
  const th  = T(dk);
  const rtl = isRTL();
  const S   = state.settings;

  const [perm,        setPerm]        = useState('default');
  const [notifEnabled,setNotifEnabled]= useState(!!S.notifEnabled);
  const [notifTime,   setNotifTime]   = useState(S.notifTime || '20:00');
  const [notifType,   setNotifType]   = useState(S.notifMessage || 'streak');
  const [customText,  setCustomText]  = useState(S.notifCustom || '');
  const [smartModes,  setSmartModes]  = useState(
    S.smartModes || { streak:true, review:true, motivational:false }
  );

  useEffect(()=>{ getPermission().then(setPerm); },[]);

  const toggleSmart = (id) =>
    setSmartModes(p=>({ ...p, [id]:!p[id] }));

  const enableNotifs = async () => {
    const p = await requestPermission();
    setPerm(p);
    if (p === 'granted') setNotifEnabled(true);
    else Alert.alert('', isRTL() ? 'يرجى السماح بالإشعارات من إعدادات الجهاز.' : 'Please allow notifications in device settings.');
  };

  const save = async () => {
    const settings = {
      notifEnabled, notifTime, notifMessage: notifType,
      notifCustom: customText, smartModes,
    };
    dispatch({ type:'SAVE_SETTINGS', settings });
    if (notifEnabled && perm === 'granted') {
      await scheduleDaily(true, notifTime, notifType, customText, state.profile);
    } else if (!notifEnabled) {
      await cancelAll();
    }
    onClose();
  };

  const testNow = () => {
    const msgs = {
      streak:  isRTL() ? 'لا تطفئ شعلتك! 🔥 راجع كلماتك اليوم' : "Don't break your streak! 🔥 Review today",
      review:  isRTL() ? 'بطاقاتك جاهزة للمراجعة! 📚' : 'Your cards are ready for review! 📚',
      motivational: isRTL() ? 'أنت رائع! استمر في التعلم 💪' : "You're amazing! Keep learning 💪",
      custom: customText,
    };
    sendNow(`${isRTL()?'مرحباً':'Hello'} ${state.profile.name}! 🐘`, msgs[notifType] || msgs.streak);
  };

  const ta = rtl ? 'right' : 'left';

  return (
    <ModalShell visible title={t('notifications')} dk={dk} onClose={onClose}>

      {/* Permission status */}
      <View style={[ms.permRow, {
        backgroundColor: perm==='granted'?th.gLight : perm==='denied'?th.rLight : th.goLight,
        borderColor: (perm==='granted'?th.green:perm==='denied'?th.red:th.gold)+'40',
      }]}>
        <Text style={{ fontSize:20 }}>{perm==='granted'?'✅':perm==='denied'?'❌':'⏳'}</Text>
        <Text style={[ms.permTxt, {
          color: perm==='granted'?th.green:perm==='denied'?th.red:th.gold
        }]}>
          {perm==='granted' ? (rtl?'الإشعارات مسموح بها':'Notifications allowed')
           : perm==='denied'? (rtl?'الإشعارات محجوبة':'Notifications blocked')
           :                  (rtl?'في انتظار الإذن':'Waiting for permission')}
        </Text>
      </View>

      {/* Main toggle */}
      <View style={[ms.settingRow, { marginBottom:16 }]}>
        <View style={{ flexDirection: rtl?'row-reverse':'row', alignItems:'center', gap:12, flex:1 }}>
          <View style={[ms.icon, { backgroundColor:th.pLight }]}><Text style={{ fontSize:20 }}>🔔</Text></View>
          <View>
            <Text style={[ms.settingLabel, { color:th.text }]}>{t('dailyReminder')}</Text>
            <Text style={[ms.settingSub, { color:th.textSub }]}>
              {notifEnabled ? (rtl?'مفعّل':'Enabled') : (rtl?'معطّل':'Disabled')}
            </Text>
          </View>
        </View>
        <Toggle value={notifEnabled} onChange={v => v ? enableNotifs() : setNotifEnabled(false)}/>
      </View>

      {notifEnabled && perm === 'granted' && (
        <View style={{ gap:16 }}>

          {/* Time picker */}
          <View style={[ms.settingRow]}>
            <View style={{ flexDirection: rtl?'row-reverse':'row', alignItems:'center', gap:8, flex:1 }}>
              <Text style={{ fontSize:22 }}>🕐</Text>
              <Text style={[ms.settingLabel, { color:th.text }]}>
                {rtl ? 'وقت الإشعار الأساسي' : 'Base reminder time'}
              </Text>
            </View>
            <TextInput
              value={notifTime} onChangeText={setNotifTime}
              placeholder="20:00" keyboardType="numbers-and-punctuation"
              style={[ms.timeInput, { borderColor:th.border, backgroundColor:th.card, color:th.text }]}
            />
          </View>

          {/* Smart modes */}
          <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>
            {rtl ? '🤖 الإشعارات الذكية' : '🤖 Smart Notifications'}
          </Text>
          {SMART_SCHEDULES.map(sc=>(
            <View key={sc.id} style={[ms.smartRow, { backgroundColor:th.cardAlt, borderColor:th.border }]}>
              <Text style={{ fontSize:28 }}>{sc.icon}</Text>
              <View style={{ flex:1 }}>
                <Text style={[ms.smartTitle, { color:th.text, textAlign:ta }]}>
                  {rtl ? sc.title_ar : sc.title_en}
                </Text>
                <Text style={[ms.smartDesc, { color:th.textSub, textAlign:ta }]}>
                  {rtl ? sc.desc_ar : sc.desc_en}
                </Text>
              </View>
              <Toggle value={!!smartModes[sc.id]} onChange={()=>toggleSmart(sc.id)}/>
            </View>
          ))}

          {/* Notification type */}
          <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>
            {t('messageType')}
          </Text>
          {NOTIF_MESSAGES.map(m=>(
            <TouchableOpacity key={m.id} onPress={()=>setNotifType(m.id)}
              style={[ms.msgRow, {
                borderColor: notifType===m.id?'#7C3AED':th.border,
                backgroundColor: notifType===m.id?th.pLight:th.cardAlt,
              }]}>
              <View style={[ms.radio, {
                borderColor: notifType===m.id?'#7C3AED':th.border,
                backgroundColor: notifType===m.id?'#7C3AED':'transparent',
              }]}>
                {notifType===m.id && <View style={ms.radioDot}/>}
              </View>
              <View style={{ flex:1 }}>
                <Row style={{ gap:6 }}>
                  <Text style={{ fontSize:16 }}>{m.icon}</Text>
                  <Text style={[ms.msgLabel, { color:th.text }]}>
                    {m.id==='custom'?(rtl?'رسالة مخصصة':'Custom message'):m.text.slice(0,35)+'...'}
                  </Text>
                </Row>
                {m.id==='custom' && notifType==='custom' && (
                  <TextInput value={customText} onChangeText={setCustomText}
                    placeholder={rtl?'اكتب رسالتك...':'Write your message...'}
                    placeholderTextColor={th.textMuted}
                    style={[ms.customInput, { borderColor:th.border, backgroundColor:th.card, color:th.text, textAlign:ta }]}/>
                )}
              </View>
            </TouchableOpacity>
          ))}

          {/* Preview + test */}
          <View style={[ms.preview, { backgroundColor:th.cardAlt, borderColor:th.border }]}>
            <Text style={[ms.previewLabel, { color:th.textMuted, textAlign:ta }]}>
              {rtl?'معاينة:':'Preview:'}
            </Text>
            <Row style={{ gap:10 }}>
              <Text style={{ fontSize:22 }}>🐘</Text>
              <View style={{ flex:1 }}>
                <Text style={[{ fontWeight:'800', fontSize:13, color:th.text, textAlign:ta }]}>
                  {rtl?'مرحباً':'Hello'} {state.profile.name}!
                </Text>
                <Text style={[{ fontSize:12, color:th.textSub, marginTop:2, lineHeight:18, textAlign:ta }]}>
                  {notifType==='custom'&&customText
                    ? customText
                    : (NOTIF_MESSAGES.find(m=>m.id===notifType)||NOTIF_MESSAGES[0]).text}
                </Text>
              </View>
            </Row>
          </View>

          <Btn onPress={testNow} variant="ghost" full dk={dk}>{t('testNotif')}</Btn>
        </View>
      )}

      <View style={{ height:12 }}/>
      <Btn onPress={save} full size="lg">💾 {rtl?'حفظ الإشعارات':'Save Notifications'}</Btn>
    </ModalShell>
  );
};

// ─── Groq API Modal ───────────────────────────────────────────────────────────
const OUTPUT_LANGS = [
  { code:'ar', flag:'🇸🇦', name:'العربية', nameEn:'Arabic' },
  { code:'en', flag:'🇺🇸', name:'English', nameEn:'English' },
  { code:'fr', flag:'🇫🇷', name:'Français', nameEn:'French' },
  { code:'de', flag:'🇩🇪', name:'Deutsch', nameEn:'German' },
  { code:'es', flag:'🇪🇸', name:'Español', nameEn:'Spanish' },
  { code:'ja', flag:'🇯🇵', name:'日本語', nameEn:'Japanese' },
  { code:'zh', flag:'🇨🇳', name:'中文', nameEn:'Chinese' },
  { code:'ko', flag:'🇰🇷', name:'한국어', nameEn:'Korean' },
];

const GroqModal = ({ settings, dk, onClose, onSave, onToast }) => {
  const th = T(dk);
  const rtl = isRTL();
  const [model,      setModel]      = useState(settings.aiModel || 'compound-beta');
  const [key,        setKey]        = useState(settings.groqApiKey || '');
  const [outLang,    setOutLang]    = useState(settings.outputLanguage || 'ar');
  const [showKey,    setShowKey]    = useState(false);
  const [testing,    setTesting]    = useState(false);
  const [result,     setResult]     = useState(null);

  const runTest = async () => {
    if (!key.trim()) return;
    setTesting(true); setResult(null);
    const r = await testGroqConnection(key.trim(), model);
    setResult(r);
    if (r.ok) onToast({ icon:'✅', title:'Groq API ✅', body: model });
    setTesting(false);
  };

  const ta = rtl ? 'right' : 'left';

  return (
    <ModalShell visible title="⚡ Groq API" dk={dk} onClose={onClose}>
      <Row style={[ms.tipRow, { flexDirection: rtl?'row-reverse':'row' }]}>
        <Text style={{ fontSize:48 }}>🐘</Text>
        <View style={[ms.tipBubble, { backgroundColor:th.pLight, borderColor:th.borderPurple||th.border }]}>
          <Text style={[{ fontSize:13, fontWeight:'700', lineHeight:22, color:th.primary, textAlign:ta }]}>
            {rtl
              ? 'احصل على مفتاحك المجاني من console.groq.com — لا يحتاج بطاقة ائتمانية! 🎉'
              : 'Get your free key at console.groq.com — no credit card needed! 🎉'}
          </Text>
        </View>
      </Row>

      <Text style={[ms.sectionLabel, { color:th.text, textAlign:ta }]}>{t('chooseModel')}</Text>
      {GROQ_MODELS.map(m=>(
        <TouchableOpacity key={m.id} onPress={()=>setModel(m.id)}
          style={[ms.modelRow, { borderColor:model===m.id?'#7C3AED':th.border, backgroundColor:model===m.id?th.pLight:th.card }]}>
          <View style={[ms.radio, { borderColor:model===m.id?'#7C3AED':th.border, backgroundColor:model===m.id?'#7C3AED':'transparent' }]}>
            {model===m.id && <View style={ms.radioDot}/>}
          </View>
          <View style={{ flex:1 }}>
            <Text style={[ms.modelLabel, { color:th.text, textAlign:ta }]}>{m.label}{model===m.id?' ✓':''}</Text>
            <Text style={[ms.modelDesc, { color:th.primary, textAlign:ta }]}>{m.desc}</Text>
          </View>
        </TouchableOpacity>
      ))}

      <Text style={[ms.sectionLabel, { color:th.text, marginTop:16, textAlign:ta }]}>{t('apiKey')}</Text>
      <Row style={{ gap:8, marginBottom:14 }}>
        <Inp value={key} onChange={setKey} type={showKey?'text':'password'} placeholder="gsk_..." dk={dk} style={{ flex:1 }}/>
        <TouchableOpacity onPress={()=>setShowKey(v=>!v)} style={[ms.eyeBtn, { backgroundColor:th.pLight }]}>
          <Text style={{ fontSize:18 }}>👁</Text>
        </TouchableOpacity>
      </Row>

      <Row style={[ms.secRow, { backgroundColor:th.gLight, borderColor:th.green+'40' }]}>
        <Text style={{ fontSize:16 }}>🔒</Text>
        <Text style={[{ flex:1, fontSize:12, lineHeight:20, color:th.textSub, textAlign:ta }]}>{t('securityNote')}</Text>
      </Row>

      {result && (
        <View style={[ms.resultBox, { backgroundColor:result.ok?th.gLight:th.rLight, borderColor:result.ok?th.green:th.red }]}>
          <Text style={{ color:result.ok?th.green:th.red, fontSize:13, fontWeight:'600', textAlign:ta }}>{result.msg}</Text>
        </View>
      )}

      <Btn onPress={runTest} disabled={testing||!key.trim()} variant="ghost" full dk={dk} style={{ marginBottom:10 }}>
        {testing ? t('testing') : t('testConnection')}
      </Btn>

      {/* ── Output Language ── */}
      <Text style={[ms.sectionLabel, { color:th.text, textAlign:ta, marginTop:8 }]}>
        {rtl ? '🌐 لغة مخرجات الذكاء الاصطناعي' : '🌐 AI Output Language'}
      </Text>
      <Text style={{ fontSize:12, color:th.textMuted, textAlign:ta, marginBottom:10 }}>
        {rtl ? 'سيكتب الـ AI التعريفات والأمثلة بهذه اللغة' : 'AI will write definitions & examples in this language'}
      </Text>
      <View style={{ flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:16 }}>
        {OUTPUT_LANGS.map(l => (
          <TouchableOpacity key={l.code} onPress={() => setOutLang(l.code)}
            style={[ms.langBtn, {
              borderColor: outLang===l.code ? '#7C3AED' : th.border,
              backgroundColor: outLang===l.code ? th.pLight : th.cardAlt,
              flex:undefined, paddingHorizontal:12, paddingVertical:8,
            }]}>
            <Text style={{ fontSize:18 }}>{l.flag}</Text>
            <Text style={{ fontSize:12, fontWeight:'700', color: outLang===l.code ? th.primary : th.textMuted }}>
              {l.name}
            </Text>
            {outLang===l.code && <Text style={{ color:th.primary, fontSize:12 }}>✓</Text>}
          </TouchableOpacity>
        ))}
      </View>

      <Btn onPress={()=>{ onSave({ groqApiKey:key.trim(), aiModel:model, outputLanguage:outLang }); onClose(); }} full size="lg">
        {t('saveSettings')}
      </Btn>
    </ModalShell>
  );
};

// ─── Main Settings Screen ─────────────────────────────────────────────────────
export default function SettingsScreen({ state, dispatch, dk, onToast }) {
  const th  = T(dk);
  const rtl = isRTL();
  const S   = state.settings;

  const [modal, setModal] = useState(null); // 'profile' | 'notifications' | 'groq' | null

  const toggle = (key) => dispatch({ type:'SAVE_SETTINGS', settings:{ [key]:!S[key] } });
  const groqLabel = GROQ_MODELS.find(m=>m.id===S.aiModel)?.label || S.aiModel;
  const ta = rtl ? 'right' : 'left';
  const rowDir = rtl ? 'row-reverse' : 'row';

  const profile = state.profile;
  const avatarEl = profile.avatarImage
    ? <Image source={{ uri:profile.avatarImage }} style={{ width:56, height:56, borderRadius:28 }}/>
    : <Text style={{ fontSize:40 }}>{profile.avatar || '🐘'}</Text>;

  const SectionBtn = ({ icon, title, subtitle, badge, onPress }) => (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8}>
      <Card dk={dk} style={{ marginBottom:12 }}>
        <View style={[{ flexDirection:rowDir, alignItems:'center', gap:12 }]}>
          <View style={[ms.icon, { backgroundColor:th.pLight }]}>
            <Text style={{ fontSize:22 }}>{icon}</Text>
          </View>
          <View style={{ flex:1 }}>
            <Text style={[{ fontSize:15, fontWeight:'700', color:th.text, textAlign:ta }]}>{title}</Text>
            {subtitle ? <Text style={[{ fontSize:12, color:th.textSub, marginTop:2, textAlign:ta }]}>{subtitle}</Text> : null}
          </View>
          {badge && (
            <View style={[ms.badge, { backgroundColor:badge.ok?th.gLight:th.rLight }]}>
              <Text style={{ fontSize:11, fontWeight:'700', color:badge.ok?th.green:th.red }}>
                {badge.label}
              </Text>
            </View>
          )}
          <Text style={{ color:th.textMuted, fontSize:18 }}>›</Text>
        </View>
      </Card>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={[{ flex:1, backgroundColor:th.bg }]} contentContainerStyle={{ padding:16, paddingBottom:32 }}>
      <Text style={[{ fontSize:22, fontWeight:'900', color:th.text, marginBottom:20, textAlign:ta }]}>
        {t('settingsTitle')}
      </Text>

      {/* Profile preview */}
      <TouchableOpacity onPress={()=>setModal('profile')} activeOpacity={0.85}>
        <Card dk={dk} style={[ms.profilePreview, { flexDirection:rowDir }]}>
          <View style={ms.profileAvatar}>{avatarEl}</View>
          <View style={{ flex:1 }}>
            <Text style={[{ fontSize:18, fontWeight:'900', color:th.text, textAlign:ta }]}>{profile.name}</Text>
            <Text style={[{ fontSize:13, color:th.primary, marginTop:2, textAlign:ta }]}>
              {S.uiLanguage==='ar'?'🇸🇦 العربية':'🇺🇸 English'} · {LANGUAGES.find(l=>l.code===profile.language)?.flag} {LANGUAGES.find(l=>l.code===profile.language)?.name}
            </Text>
          </View>
          <Text style={{ color:th.textMuted, fontSize:18 }}>✏️</Text>
        </Card>
      </TouchableOpacity>

      {/* Appearance */}
      <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>{t('appearance')}</Text>
      <Card dk={dk} style={{ marginBottom:12 }}>
        <View style={[{ flexDirection:rowDir, alignItems:'center', justifyContent:'space-between' }]}>
          <View style={[{ flexDirection:rowDir, alignItems:'center', gap:10 }]}>
            <View style={[ms.icon, { backgroundColor:dk?'#2D2D48':'#FFF7ED' }]}>
              <Text style={{ fontSize:20 }}>{dk?'🌙':'☀️'}</Text>
            </View>
            <View>
              <Text style={[{ fontSize:14, fontWeight:'700', color:th.text }]}>{dk?t('darkMode'):t('lightMode')}</Text>
              <Text style={[{ fontSize:12, color:th.textSub }]}>{t('tapToToggle')}</Text>
            </View>
          </View>
          <Toggle value={dk} onChange={()=>toggle('darkMode')}/>
        </View>
      </Card>

      {/* Sections */}
      <Text style={[ms.sectionLabel, { color:th.textMuted, textAlign:ta }]}>
        {rtl ? 'الميزات' : 'Features'}
      </Text>

      <SectionBtn
        icon="🔔"
        title={t('notifications')}
        subtitle={S.notifEnabled ? (rtl?`تذكير يومي — ${S.notifTime||'20:00'}`:`Daily at ${S.notifTime||'20:00'}`) : (rtl?'معطّل':'Disabled')}
        badge={S.notifEnabled ? { ok:true, label:rtl?'مفعّل':'On' } : { ok:false, label:rtl?'معطّل':'Off' }}
        onPress={()=>setModal('notifications')}
      />

      <SectionBtn
        icon="⚡"
        title="Groq API"
        subtitle={S.groqApiKey ? `${rtl?'موديل:':'Model:'} ${groqLabel}` : (rtl?'لم يُضَف مفتاح بعد':'No key added yet')}
        badge={S.groqApiKey ? { ok:true, label:'✅' } : { ok:false, label:'❌' }}
        onPress={()=>setModal('groq')}
      />

      {/* About */}
      <Card dk={dk} style={{ alignItems:'center', padding:24, marginTop:8 }}>
        <Text style={{ fontSize:48 }}>🐘</Text>
        <Text style={[{ fontWeight:'900', fontSize:18, color:th.text, marginTop:8, marginBottom:2 }]}>{t('aboutTitle')}</Text>
        <Text style={[{ color:th.textMuted, fontSize:12 }]}>{t('aboutSub')}</Text>
      </Card>

      {/* Modals */}
      {modal==='profile' && (
        <ProfileModal state={state} dispatch={dispatch} dk={dk} onClose={()=>setModal(null)}/>
      )}
      {modal==='notifications' && (
        <NotificationsModal state={state} dispatch={dispatch} dk={dk} onClose={()=>setModal(null)}/>
      )}
      {modal==='groq' && (
        <GroqModal settings={S} dk={dk}
          onClose={()=>setModal(null)}
          onSave={s=>dispatch({type:'SAVE_SETTINGS',settings:s})}
          onToast={onToast}
        />
      )}
    </ScrollView>
  );
}

const ms = StyleSheet.create({
  overlay:      { flex:1, backgroundColor:'rgba(0,0,0,.55)', justifyContent:'flex-end' },
  sheet:        { borderTopLeftRadius:28, borderTopRightRadius:28, padding:20, maxHeight:'92%' },
  header:       { justifyContent:'space-between', alignItems:'center', marginBottom:20 },
  title:        { fontSize:20, fontWeight:'900' },
  sectionLabel: { fontSize:12, fontWeight:'700', textTransform:'uppercase', letterSpacing:0.8, marginBottom:10, marginTop:4 },
  // Avatar
  avatarCircle: { width:96, height:96, borderRadius:48, alignItems:'center', justifyContent:'center', marginBottom:12 },
  avatarImg:    { width:96, height:96, borderRadius:48 },
  avatarEditBadge:{ position:'absolute', bottom:0, right:0, backgroundColor:'#7C3AED', borderRadius:12, padding:4 },
  avatarGrid:   { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:16, justifyContent:'center' },
  avatarBtn:    { width:50, height:50, borderRadius:14, alignItems:'center', justifyContent:'center', borderWidth:2 },
  // Langs
  langBtn:      { flex:1, flexDirection:'row', alignItems:'center', justifyContent:'center', gap:6, padding:12, borderRadius:14, borderWidth:2 },
  langBtnTxt:   { fontSize:14, fontWeight:'700' },
  studyChip:    { alignItems:'center', gap:4, paddingVertical:8, paddingHorizontal:12, borderRadius:12, borderWidth:2 },
  studyChipTxt: { fontSize:12, fontWeight:'700' },
  // Notifications
  permRow:      { flexDirection:'row', alignItems:'center', gap:10, padding:12, borderRadius:12, marginBottom:16, borderWidth:1 },
  permTxt:      { fontSize:13, fontWeight:'700', flex:1 },
  settingRow:   { flexDirection:'row', alignItems:'center', justifyContent:'space-between' },
  settingLabel: { fontSize:14, fontWeight:'700' },
  settingSub:   { fontSize:12, marginTop:1 },
  icon:         { width:42, height:42, borderRadius:11, alignItems:'center', justifyContent:'center' },
  timeInput:    { borderWidth:2, borderRadius:10, paddingHorizontal:10, paddingVertical:6, fontSize:15, fontWeight:'700', width:80, textAlign:'center' },
  smartRow:     { flexDirection:'row', alignItems:'center', gap:12, padding:12, borderRadius:14, borderWidth:1, marginBottom:8 },
  smartTitle:   { fontSize:14, fontWeight:'700', marginBottom:2 },
  smartDesc:    { fontSize:12, lineHeight:18 },
  msgRow:       { flexDirection:'row', alignItems:'flex-start', gap:10, padding:10, borderRadius:12, borderWidth:1.5, marginBottom:6 },
  msgLabel:     { fontSize:13, fontWeight:'600', flex:1 },
  customInput:  { marginTop:6, padding:8, borderRadius:8, borderWidth:1.5, fontSize:13 },
  preview:      { borderRadius:12, padding:12, borderWidth:1, marginBottom:12 },
  previewLabel: { fontSize:12, fontWeight:'700', marginBottom:6 },
  radio:        { width:18, height:18, borderRadius:9, borderWidth:2, alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:2 },
  radioDot:     { width:8, height:8, borderRadius:4, backgroundColor:'#fff' },
  // Groq
  tipRow:       { gap:12, alignItems:'flex-start', marginBottom:18 },
  tipBubble:    { flex:1, borderRadius:14, borderBottomLeftRadius:4, padding:12, borderWidth:1.5 },
  modelRow:     { flexDirection:'row', alignItems:'center', gap:12, padding:11, borderRadius:12, borderWidth:1.5, marginBottom:8 },
  modelLabel:   { fontSize:13, fontWeight:'700' },
  modelDesc:    { fontSize:11 },
  eyeBtn:       { width:46, height:46, borderRadius:12, alignItems:'center', justifyContent:'center' },
  secRow:       { gap:8, padding:10, borderRadius:10, marginBottom:14, borderWidth:1 },
  resultBox:    { padding:10, borderRadius:10, marginBottom:12, borderWidth:1 },
  // Profile card
  profilePreview:{ alignItems:'center', gap:14, padding:16, marginBottom:20 },
  profileAvatar: { width:64, height:64, alignItems:'center', justifyContent:'center' },
  badge:         { paddingHorizontal:10, paddingVertical:3, borderRadius:20 },
});
