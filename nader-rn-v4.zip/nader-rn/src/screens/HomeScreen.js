import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { T } from '../theme';
import { LEVELS, getLevelFromXP, getDueWords, DAILY_CARDS } from '../state';
import { t, isRTL, levelName } from '../i18n';
import { Card, Btn, Elephant } from '../components';

export default function HomeScreen({ state, dispatch, onNav, dk }) {
  const th = T(dk);
  const rtl = isRTL();
  const { profile, words } = state;
  const due = getDueWords(words);
  const lv  = getLevelFromXP(profile.xp);
  const lvl = LEVELS[lv] || LEVELS[0];
  const thr = [0, 200, 500, 1000, 2000];
  const cur = thr[lv]||0, nxt = thr[lv+1]||cur+500;
  const pct = Math.min(((profile.xp-cur)/(nxt-cur))*100, 100);
  const textAlign = rtl ? 'right' : 'left';
  const rowDir    = rtl ? 'row-reverse' : 'row';

  const stats = [
    { l: t('words_'),   v: words.length,                       icon:'📝', c:th.blue  },
    { l: t('mastered'), v: words.filter(w=>w.mastered).length, icon:'🏅', c:th.green },
    { l: t('hard'),     v: words.filter(w=>w.hard).length,     icon:'💪', c:th.red   },
  ];

  return (
    <ScrollView style={[s.container,{backgroundColor:th.bg}]} contentContainerStyle={s.content} showsVerticalScrollIndicator={false}>

      {/* Header */}
      <LinearGradient colors={['#7C3AED','#5B21B6']} style={s.header}>
        <View style={[s.headerRow,{flexDirection:rowDir}]}>
          <View>
            <Text style={[s.headerName,{textAlign}]}>{t('hey')} {profile.name}! 👋</Text>
            <Text style={[s.headerLevel,{textAlign}]}>{lvl.icon} {levelName(lv)}</Text>
          </View>
          <Text style={s.streak}>🔥 {profile.streak}</Text>
        </View>
      </LinearGradient>

      <View style={s.body}>
        {/* XP Bar */}
        <Card dk={dk} style={{marginBottom:12}}>
          <View style={[s.xpRow,{flexDirection:rowDir}]}>
            <Text style={[s.xpTxt,{color:th.textMuted}]}>⭐ {profile.xp} XP</Text>
            <Text style={[s.xpTxt,{color:th.textMuted}]}>{t('level')} {lv+1}/4</Text>
          </View>
          <View style={[s.barBg,{backgroundColor:th.border}]}>
            <View style={[s.barFill,{width:`${pct}%`}]}/>
          </View>
        </Card>

        {/* Daily mission */}
        <LinearGradient
          colors={due.length>0 ? ['#7C3AED','#5B21B6'] : ['#10B981','#059669']}
          style={s.missionCard}
        >
          <View style={[s.missionRow,{flexDirection:rowDir}]}>
            <View style={{flex:1}}>
              <Text style={[s.missionTitle,{textAlign}]}>
                {due.length>0 ? t('dailyMission') : t('crushedIt')}
              </Text>
              <Text style={[s.missionSub,{textAlign}]}>
                {due.length>0
                  ? `${Math.min(due.length,DAILY_CARDS)} ${t('cardsReady')}`
                  : t('allDone')}
              </Text>
            </View>
            <Elephant size={52}/>
          </View>
          {due.length>0 && (
            <Btn onPress={()=>onNav('review')} variant="white" full size="md" dk={dk} style={{marginTop:14}}>
              {t('startReview')}
            </Btn>
          )}
        </LinearGradient>

        {/* Stats row */}
        <View style={[s.statsRow,{flexDirection:rowDir}]}>
          {stats.map(stat=>(
            <Card key={stat.l} dk={dk} style={{flex:1,alignItems:'center',padding:14}}>
              <Text style={{fontSize:22,marginBottom:4}}>{stat.icon}</Text>
              <Text style={{fontSize:20,fontWeight:'900',color:stat.c}}>{stat.v}</Text>
              <Text style={{fontSize:11,color:th.textMuted,marginTop:2}}>{stat.l}</Text>
            </Card>
          ))}
        </View>

        {/* Hint points */}
        <Card dk={dk} style={[s.hintCard,{flexDirection:rowDir}]}>
          <View>
            <Text style={[s.hintLabel,{color:th.textSub,textAlign}]}>💡 {t('hintPoints')}</Text>
            <Text style={[s.hintVal,{color:th.gold}]}>{profile.hintPoints}</Text>
          </View>
          <Text style={[s.hintSub,{color:th.textMuted}]}>{t('refreshesDaily')}</Text>
        </Card>

        {/* Empty state */}
        {words.length===0 && (
          <Card dk={dk} style={[s.emptyCard,{borderColor:th.gold,backgroundColor:th.goLight}]}>
            <Text style={{fontSize:44,marginBottom:8,textAlign:'center'}}>✨</Text>
            <Text style={[s.emptyTitle,{color:th.gold}]}>{t('addFirstWord')}</Text>
            <Btn onPress={()=>onNav('add')} variant="gold" size="sm" style={{marginTop:12}}>
              {t('addWord')}
            </Btn>
          </Card>
        )}
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:  {flex:1},
  content:    {paddingBottom:24},
  header:     {paddingTop:56,paddingBottom:24,paddingHorizontal:20},
  headerRow:  {justifyContent:'space-between',alignItems:'center'},
  headerName: {fontSize:21,fontWeight:'900',color:'#fff'},
  headerLevel:{fontSize:13,color:'rgba(255,255,255,.85)',marginTop:2},
  streak:     {fontSize:20,fontWeight:'900',color:'#FFD700'},
  body:       {padding:16,gap:12},
  xpRow:      {justifyContent:'space-between',marginBottom:6},
  xpTxt:      {fontSize:12,fontWeight:'600'},
  barBg:      {height:10,borderRadius:10,overflow:'hidden'},
  barFill:    {height:'100%',backgroundColor:'#7C3AED',borderRadius:10},
  missionCard:{borderRadius:18,padding:16,marginBottom:0},
  missionRow: {alignItems:'center'},
  missionTitle:{fontSize:17,fontWeight:'900',color:'#fff',marginBottom:6},
  missionSub: {fontSize:14,color:'rgba(255,255,255,.9)'},
  statsRow:   {gap:10},
  hintCard:   {alignItems:'center',justifyContent:'space-between'},
  hintLabel:  {fontSize:13,fontWeight:'700'},
  hintVal:    {fontSize:22,fontWeight:'900',marginTop:2},
  hintSub:    {fontSize:12},
  emptyCard:  {borderWidth:2,borderStyle:'dashed',alignItems:'center',padding:20},
  emptyTitle: {fontSize:18,fontWeight:'900',textAlign:'center'},
});
