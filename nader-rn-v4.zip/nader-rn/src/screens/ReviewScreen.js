import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, Animated, Easing,
} from 'react-native';
import * as Speech   from 'expo-speech';
import * as Haptics  from 'expo-haptics';
import { T }         from '../theme';
import { t, isRTL }  from '../i18n';
import {
  getDueWords, DAILY_CARDS, MASTERED_THRESHOLD, HARD_THRESHOLD,
  nextReviewDate, similarity, todayStr,
} from '../state';
import { aiReviewContent }     from '../services/ai';
import { playSound, preloadSounds } from '../services/SoundService';
import { Card, Btn, Inp, Spinner, Elephant } from '../components';
import SmartImage      from '../components/SmartImage';
import ParagraphChallenge from './ParagraphChallenge';

// ─── TTS helpers ──────────────────────────────────────────────────────────────
const speakWord = (text, lang) => Speech.speak(text, { language: lang, rate: 0.9 });

const speakWithPause = (text, lang) => {
  Speech.stop();
  const parts = text.split('___');
  if (parts.length === 1) { speakWord(text, lang); return; }
  let i = 0;
  const next = () => {
    if (i >= parts.length) return;
    const chunk = parts[i++];
    if (chunk.trim()) {
      Speech.speak(chunk, {
        language: lang, rate: 0.9,
        onDone: () => { if (i < parts.length) setTimeout(next, 800); else next(); },
      });
    } else {
      if (i < parts.length) setTimeout(next, 800); else next();
    }
  };
  next();
};

// ─── Animated card wrapper ────────────────────────────────────────────────────
const SlideCard = ({ children, style }) => {
  const slide = useRef(new Animated.Value(60)).current;
  const alpha = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.spring(slide, { toValue: 0, useNativeDriver: true, tension: 80, friction: 10 }),
      Animated.timing(alpha, { toValue: 1, duration: 250, useNativeDriver: true }),
    ]).start();
  }, []);
  return (
    <Animated.View style={[style, { transform: [{ translateY: slide }], opacity: alpha }]}>
      {children}
    </Animated.View>
  );
};

// ─── Confetti burst (simple emoji rain) ──────────────────────────────────────
const ConfettiBurst = ({ visible }) => {
  const items = ['🎉','⭐','✨','🌟','💫','🎊'];
  const anims = useRef(items.map(() => ({
    y: new Animated.Value(-20),
    x: new Animated.Value(0),
    o: new Animated.Value(1),
  }))).current;

  useEffect(() => {
    if (!visible) return;
    anims.forEach((a, i) => {
      a.y.setValue(-20); a.x.setValue(0); a.o.setValue(1);
      Animated.parallel([
        Animated.timing(a.y, { toValue: 120 + i*15, duration: 900, useNativeDriver: true, easing: Easing.out(Easing.quad) }),
        Animated.timing(a.x, { toValue: (i%2===0?1:-1)*(20+i*10), duration: 900, useNativeDriver: true }),
        Animated.timing(a.o, { toValue: 0, duration: 900, delay: 400, useNativeDriver: true }),
      ]).start();
    });
  }, [visible]);

  if (!visible) return null;
  return (
    <View style={cs.confettiWrap} pointerEvents="none">
      {items.map((em, i) => (
        <Animated.Text key={i} style={[cs.confettiItem, {
          transform: [{ translateY: anims[i].y }, { translateX: anims[i].x }],
          opacity: anims[i].o,
          left: `${10 + i * 14}%`,
        }]}>{em}</Animated.Text>
      ))}
    </View>
  );
};

const cs = StyleSheet.create({
  confettiWrap: { position:'absolute', top:0, left:0, right:0, height:160, zIndex:999, overflow:'hidden' },
  confettiItem: { position:'absolute', fontSize:28 },
});

// ─── Review Screen ────────────────────────────────────────────────────────────
export default function ReviewScreen({ state, dispatch, onComplete, dk }) {
  const th   = T(dk);
  const rtl  = isRTL();
  const ta   = rtl ? 'right' : 'left';
  const rowD = rtl ? 'row-reverse' : 'row';

  const [session,     setSession]    = useState([]);
  const [idx,         setIdx]        = useState(0);
  const [cardData,    setCardData]   = useState(null);
  const [loadingCard, setLoadingCard]= useState(false);
  const [answer,      setAnswer]     = useState('');
  const [revealed,    setRevealed]   = useState(false);
  const [verdict,     setVerdict]    = useState(null);
  const [hintLetter,  setHintLetter] = useState(false);
  const [hintLength,  setHintLength] = useState(false);
  const [phase,       setPhase]      = useState('review');
  const [showConfetti,setShowConfetti] = useState(false);

  const shakeAnim  = useRef(new Animated.Value(0)).current;
  const bounceAnim = useRef(new Animated.Value(1)).current;
  const cardKey    = useRef(0); // forces SlideCard remount on new card
  const hintUsed   = useRef({ letter: false, length: false });
  const sessionLog = useRef({ correct: 0, total: 0, startTime: Date.now() });

  // Pre-load sounds once
  useEffect(() => { preloadSounds(); }, []);

  const loadCard = useCallback(async (word, settings) => {
    setLoadingCard(true);
    setAnswer(''); setRevealed(false); setVerdict(null);
    setHintLetter(false); setHintLength(false);
    hintUsed.current = { letter: false, length: false };
    cardKey.current += 1;
    try {
      if (!settings.groqApiKey) throw new Error('no key');
      const c = await aiReviewContent(word.word, word.language, settings);
      setCardData(c);
    } catch {
      const blank = s => s.replace(new RegExp(word.word, 'gi'), '___');
      setCardData({
        definition: blank(word.definition || ''),
        examples:   (word.examples || []).map(blank),
      });
    }
    setLoadingCard(false);
  }, []);

  useEffect(() => {
    const due = getDueWords(state.words).slice(0, DAILY_CARDS);
    setSession(due);
    if (due.length > 0) loadCard(due[0], state.settings);
  }, []);

  // ── shake on wrong ──────────────────────────────────────────────────────────
  const shake = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 12,  duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -12, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8,   duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8,  duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0,   duration: 40, useNativeDriver: true }),
    ]).start();
  };

  // ── bounce on correct ───────────────────────────────────────────────────────
  const bounce = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Animated.sequence([
      Animated.spring(bounceAnim, { toValue: 1.08, useNativeDriver: true, speed: 40 }),
      Animated.spring(bounceAnim, { toValue: 1,    useNativeDriver: true, speed: 20 }),
    ]).start();
  };

  // ── check answer ────────────────────────────────────────────────────────────
  const checkAnswer = () => {
    const word = session[idx];
    const sim  = similarity(answer, word.word);
    const v    = sim >= 0.99 ? 'correct' : sim >= 0.8 ? 'close' : 'wrong';

    setVerdict(v); setRevealed(true);
    sessionLog.current.total++;

    if (v !== 'wrong') {
      sessionLog.current.correct++;
      playSound('correct');
      bounce();
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 1200);
    } else {
      playSound('wrong');
      shake();
    }
    setTimeout(() => speakWord(word.word, word.language), 700);
  };

  // ── rate difficulty + advance ───────────────────────────────────────────────
  const rate = async (difficulty) => {
    let w       = { ...session[idx] };
    const correct = verdict === 'correct' || verdict === 'close';
    if (correct) {
      w.correctStreak   = (w.correctStreak || 0) + 1;
      w.incorrectStreak = 0;
      if (w.correctStreak >= MASTERED_THRESHOLD) w.mastered = true;
    } else {
      w.incorrectStreak = (w.incorrectStreak || 0) + 1;
      w.correctStreak   = 0;
      if (w.incorrectStreak >= HARD_THRESHOLD) w.hard = true;
    }
    w.difficulty  = difficulty;
    w.nextReview  = nextReviewDate(difficulty, w.correctStreak);
    dispatch({ type: 'UPDATE_WORD', word: w });
    dispatch({ type: 'AWARD_XP',   amount: correct ? 10 : 2 });

    if (idx + 1 >= session.length) {
      dispatch({
        type: 'LOG_SESSION',
        session: {
          date:    todayStr(),
          wordIds: session.map(x => x.id),
          correct: sessionLog.current.correct,
          total:   sessionLog.current.total,
          duration: Math.round((Date.now() - sessionLog.current.startTime) / 1000),
        },
      });
      playSound('completed');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setPhase('paragraph');
    } else {
      const ni = idx + 1;
      setIdx(ni);
      loadCard(session[ni], state.settings);
    }
  };

  // ── hints ───────────────────────────────────────────────────────────────────
  const useLetterHint = () => {
    if (hintUsed.current.letter) return;
    if ((state.profile.hintPoints || 0) < 5) {
      Alert.alert('', rtl ? 'لا يوجد نقاط كافية! (تحتاج 5)' : 'Not enough hint points! (need 5)');
      return;
    }
    hintUsed.current.letter = true;
    dispatch({ type: 'SPEND_HINTS', amount: 5 });
    setHintLetter(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const useLengthHint = () => {
    if (hintUsed.current.length) return;
    if ((state.profile.hintPoints || 0) < 3) {
      Alert.alert('', rtl ? 'لا يوجد نقاط كافية! (تحتاج 3)' : 'Not enough hint points! (need 3)');
      return;
    }
    hintUsed.current.length = true;
    dispatch({ type: 'SPEND_HINTS', amount: 3 });
    setHintLength(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  // ─── Empty / Paragraph ────────────────────────────────────────────────────
  if (session.length === 0) return (
    <View style={[s.empty, { backgroundColor: th.bg }]}>
      <Text style={s.emptyEmoji}>🎉</Text>
      <Text style={[s.emptyTitle, { color: th.text }]}>{t('nothingToReview')}</Text>
      <Btn onPress={onComplete} style={{ marginTop: 16 }}>{t('backHome')}</Btn>
    </View>
  );

  if (phase === 'paragraph') return (
    <ParagraphChallenge session={session} state={state} dispatch={dispatch} onComplete={onComplete} dk={dk}/>
  );

  const word = session[idx];
  const prog = (idx / session.length) * 100;

  return (
    <View style={[s.outerContainer, { backgroundColor: th.bg }]}>
      <ScrollView style={{ flex: 1 }} keyboardShouldPersistTaps="handled">

        {/* Progress bar */}
        <View style={[s.progressArea, { flexDirection: rowD }]}>
          <TouchableOpacity onPress={onComplete}>
            <Text style={[s.backBtn, { color: th.textSub }]}>←</Text>
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <View style={[s.progRow, { flexDirection: rowD }]}>
              <Text style={[s.progTxt, { color: th.textSub }]}>
                {t('card')} {idx + 1}/{session.length}
              </Text>
              <Text style={[s.progTxt, { color: th.textSub }]}>+10 XP ⭐</Text>
            </View>
            <View style={[s.barBg, { backgroundColor: th.border }]}>
              <Animated.View style={[s.barFill, { width: `${prog}%` }]}/>
            </View>
          </View>
        </View>

        <View style={s.body}>
          {/* Flash card */}
          <SlideCard key={cardKey.current}>
            <Animated.View style={{ transform: [{ scale: bounceAnim }] }}>
              <Card dk={dk} style={s.flashcard}>
                {loadingCard ? (
                  <View style={s.loadingCard}>
                    <Elephant size={56}/>
                    <Text style={[s.loadingTxt, { color: th.primary }]}>
                      {rtl ? 'الفيل يولّد محتوى جديداً...' : 'Generating new content...'}
                    </Text>
                  </View>
                ) : cardData && (
                  <>
                    {word.imageUrl && (
                      <SmartImage word={word.word} style={s.cardImg}/>
                    )}

                    <TouchableOpacity
                      onPress={() => speakWithPause(cardData.definition, word.language)}
                      style={[s.textBox, { backgroundColor: th.cardAlt, borderColor: th.border }]}
                    >
                      <Text style={[s.defText, { color: th.text, textAlign: ta }]}>📖 {cardData.definition}</Text>
                      <Text style={s.speakIcon}>🔊</Text>
                    </TouchableOpacity>

                    {(cardData.examples || []).map((ex, i) => (
                      <TouchableOpacity key={i}
                        onPress={() => speakWithPause(ex, word.language)}
                        style={[s.textBox, { backgroundColor: th.cardAlt, borderColor: th.border }]}
                      >
                        <Text style={[s.exText, { color: th.text, textAlign: ta }]}>💡 {ex}</Text>
                        <Text style={s.speakIcon}>🔊</Text>
                      </TouchableOpacity>
                    ))}
                  </>
                )}
              </Card>
            </Animated.View>
          </SlideCard>

          {/* Hints */}
          {!revealed && (
            <View style={s.hintsSection}>
              <View style={[{ flexDirection: rowD, justifyContent: 'flex-end' }]}>
                <Text style={[s.hintPtsTxt, { color: th.gold, backgroundColor: th.goLight }]}>
                  💡 {state.profile.hintPoints} {t('ptsLeft')}
                </Text>
              </View>
              <View style={[s.hintsRow, { flexDirection: rowD }]}>
                <TouchableOpacity onPress={useLetterHint}
                  style={[s.hintBtn, { borderColor: th.primary, backgroundColor: th.pLight },
                    hintLetter && s.hintBtnUsed]}>
                  {hintLetter
                    ? <Text style={[s.hintBtnTxt, { color: th.primary }]}>
                        {rtl ? 'أول حرف:' : 'First:'} {word.word[0].toUpperCase()}
                      </Text>
                    : <Text style={[s.hintBtnTxt, { color: th.primary }]}>{t('firstLetter')}</Text>
                  }
                </TouchableOpacity>
                <TouchableOpacity onPress={useLengthHint}
                  style={[s.hintBtn, { borderColor: th.blue, backgroundColor: th.bLight },
                    hintLength && s.hintBtnUsed]}>
                  {hintLength
                    ? <Text style={[s.hintBtnTxt, { color: th.blue }]}>
                        {rtl ? 'الأحرف:' : 'Length:'} {word.word.length}
                      </Text>
                    : <Text style={[s.hintBtnTxt, { color: th.blue }]}>{t('wordLength')}</Text>
                  }
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Input / Result */}
          {!revealed ? (
            <Animated.View style={{ transform: [{ translateX: shakeAnim }] }}>
              <Card dk={dk}>
                <Inp
                  value={answer} onChange={setAnswer}
                  placeholder={t('typeHidden')} dk={dk}
                  style={{ textAlign: 'center', fontSize: 18, fontWeight: '700', marginBottom: 12 }}
                  autoFocus
                />
                <Btn onPress={checkAnswer} disabled={!answer} full>{t('check')}</Btn>
              </Card>
            </Animated.View>
          ) : (
            <Card dk={dk} style={[
              s.resultCard,
              verdict === 'correct' && { backgroundColor: th.gLight,  borderColor: th.green },
              verdict === 'close'   && { backgroundColor: th.goLight, borderColor: th.gold  },
              verdict === 'wrong'   && { backgroundColor: th.rLight,  borderColor: th.red   },
            ]}>
              <View style={s.resultTop}>
                <Text style={s.resultEmoji}>
                  {verdict === 'correct' ? '🎉' : verdict === 'close' ? '🤏' : '❌'}
                </Text>
                <Text style={[s.resultTitle, {
                  color: verdict === 'correct' ? th.green : verdict === 'close' ? th.gold : th.red
                }]}>
                  {verdict === 'correct' ? t('nailedIt') : verdict === 'close' ? t('soClose') : t('notQuite')}
                </Text>
                <TouchableOpacity onPress={() => speakWord(word.word, word.language)} style={[s.wordRow, { flexDirection: rowD }]}>
                  <Text style={[s.wordTxt, { color: th.text }]}>
                    {rtl ? 'الكلمة:' : 'Word:'} <Text style={{ fontWeight: '900' }}>{word.word}</Text>
                  </Text>
                  <Text style={{ fontSize: 16 }}>🔊</Text>
                </TouchableOpacity>
              </View>

              <Text style={[s.rateLabel, { color: th.textMuted }]}>{t('howHard')}</Text>
              <View style={[s.rateBtns, { flexDirection: rowD }]}>
                {[
                  { l: t('easy'),  v: 'easy',   c: th.green, e: '😄' },
                  { l: t('medium'),v: 'medium',  c: th.gold,  e: '😐' },
                  { l: t('hard2'), v: 'hard',    c: th.red,   e: '😓' },
                ].map(({ l, v, c, e }) => (
                  <TouchableOpacity key={v} onPress={() => rate(v)}
                    style={[s.rateBtn, { borderColor: c, backgroundColor: th.card }]}>
                    <Text style={{ fontSize: 20 }}>{e}</Text>
                    <Text style={{ color: c, fontWeight: '700', fontSize: 13 }}>{l}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </Card>
          )}
        </View>
        <View style={{ height: 32 }}/>
      </ScrollView>

      {/* Confetti overlay */}
      <ConfettiBurst visible={showConfetti}/>
    </View>
  );
}

const s = StyleSheet.create({
  outerContainer: { flex: 1 },
  progressArea:   { alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingTop: 56, paddingBottom: 16 },
  backBtn:        { fontSize: 20 },
  progRow:        { justifyContent: 'space-between', marginBottom: 5 },
  progTxt:        { fontSize: 13 },
  barBg:          { height: 10, borderRadius: 10, overflow: 'hidden' },
  barFill:        { height: '100%', backgroundColor: '#7C3AED', borderRadius: 10 },
  body:           { padding: 16, gap: 12 },
  flashcard:      { minHeight: 240 },
  loadingCard:    { alignItems: 'center', padding: 40, gap: 12 },
  loadingTxt:     { fontWeight: '700', fontSize: 14, textAlign: 'center' },
  cardImg:        { width: '100%', height: 150, borderRadius: 12, marginBottom: 12 },
  textBox:        { borderRadius: 12, padding: 13, marginBottom: 10, borderWidth: 1, flexDirection: 'row', alignItems: 'flex-start' },
  defText:        { fontSize: 15, lineHeight: 24, flex: 1 },
  exText:         { fontSize: 14, lineHeight: 22, flex: 1 },
  speakIcon:      { fontSize: 18, marginLeft: 8 },
  hintsSection:   { gap: 8 },
  hintPtsTxt:     { fontSize: 12, fontWeight: '700', paddingHorizontal: 10, paddingVertical: 3, borderRadius: 12 },
  hintsRow:       { gap: 8 },
  hintBtn:        { flex: 1, padding: 10, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', alignItems: 'center' },
  hintBtnUsed:    { borderStyle: 'solid' },
  hintBtnTxt:     { fontSize: 13, fontWeight: '700', textAlign: 'center' },
  resultCard:     { borderWidth: 2 },
  resultTop:      { alignItems: 'center', marginBottom: 16, gap: 4 },
  resultEmoji:    { fontSize: 44 },
  resultTitle:    { fontSize: 18, fontWeight: '900' },
  wordRow:        { alignItems: 'center', gap: 6, marginTop: 4 },
  wordTxt:        { fontSize: 17 },
  rateLabel:      { fontSize: 13, textAlign: 'center', marginBottom: 12 },
  rateBtns:       { gap: 8 },
  rateBtn:        { flex: 1, padding: 12, borderRadius: 12, borderWidth: 2, alignItems: 'center', gap: 4 },
  empty:          { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  emptyEmoji:     { fontSize: 72, marginBottom: 14 },
  emptyTitle:     { fontSize: 22, fontWeight: '900', textAlign: 'center' },
});
