import React, { useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { T } from '../theme';
import { LEVELS, getLevelFromXP, nDaysAgo } from '../state';
import { t, isRTL, weekDayLabel, levelName } from '../i18n';
import { Card } from '../components';

const W = Dimensions.get('window').width;

// ─── Custom Bar Chart (avoids react-native-chart-kit Arabic issues) ───────────
const CustomBarChart = ({ data, color = '#7C3AED', height = 180, dk }) => {
  const th     = T(dk);
  const maxVal = Math.max(...data.map(d => d.value), 1);
  // Compute clean Y axis ticks: max 5 ticks, always integers
  const tickCount = 4;
  const rawStep   = maxVal / tickCount;
  const step      = rawStep < 1 ? 1 : Math.ceil(rawStep);
  const yMax      = step * tickCount;
  const ticks     = Array.from({ length: tickCount + 1 }, (_, i) => i * step);

  const barW = Math.floor((W - 80) / data.length) - 4;

  return (
    <View style={{ flexDirection: 'row', height, paddingRight: 8 }}>
      {/* Y axis */}
      <View style={{ width: 28, height, justifyContent: 'space-between', alignItems: 'flex-end', paddingBottom: 20, paddingRight: 4 }}>
        {[...ticks].reverse().map((tick, i) => (
          <Text key={i} style={{ fontSize: 10, color: th.textMuted }}>{tick}</Text>
        ))}
      </View>

      {/* Bars + X labels */}
      <View style={{ flex: 1 }}>
        {/* Bar area */}
        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'flex-end', gap: 4, paddingBottom: 2 }}>
          {data.map((d, i) => {
            const pct = Math.max((d.value / yMax), 0);
            return (
              <View key={i} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end', height: '100%' }}>
                {d.value > 0 && (
                  <Text style={{ fontSize: 9, color, fontWeight: '700', marginBottom: 2 }}>{d.value}</Text>
                )}
                <View style={{
                  width: '80%', height: `${Math.max(pct * 100, d.value > 0 ? 4 : 0)}%`,
                  backgroundColor: color, borderRadius: 4, opacity: 0.9,
                  minHeight: d.value > 0 ? 4 : 0,
                }}/>
              </View>
            );
          })}
        </View>
        {/* X labels — no Arabic shaping issues */}
        <View style={{ flexDirection: 'row', gap: 4, paddingTop: 4 }}>
          {data.map((d, i) => (
            <Text key={i} style={{ flex: 1, fontSize: 9, color: th.textMuted, textAlign: 'center' }} numberOfLines={1}>
              {d.label}
            </Text>
          ))}
        </View>
      </View>
    </View>
  );
};

// ─── Custom Pie Chart (simple, RTL-safe) ─────────────────────────────────────
const CustomPie = ({ data, size = 140, dk }) => {
  const th    = T(dk);
  const total = data.reduce((s, d) => s + d.value, 0);
  if (!total) return null;

  // Build SVG-like arcs with View rotations
  let cumPct = 0;
  const slices = data.map(d => {
    const pct = d.value / total;
    const start = cumPct;
    cumPct += pct;
    return { ...d, pct, start };
  });

  const r = size / 2;

  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
      {/* Simple coloured squares legend */}
      <View style={{ gap: 8 }}>
        {data.map((d, i) => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <View style={{ width: 14, height: 14, borderRadius: 4, backgroundColor: d.color }}/>
            <Text style={{ fontSize: 13, color: th.text, fontWeight: '600' }}>
              {Math.round((d.value / total) * 100)}% {d.label}
            </Text>
          </View>
        ))}
      </View>

      {/* Visual proportional bars as pie substitute — works perfectly with Arabic */}
      <View style={{ flex: 1, minWidth: 80, gap: 6 }}>
        {data.map((d, i) => {
          const pct = (d.value / total) * 100;
          return (
            <View key={i}>
              <View style={{ height: 18, backgroundColor: th.border, borderRadius: 9, overflow: 'hidden' }}>
                <View style={{
                  width: `${pct}%`, height: '100%',
                  backgroundColor: d.color, borderRadius: 9,
                }}/>
              </View>
            </View>
          );
        })}
      </View>
    </View>
  );
};

// ─── Stats Screen ─────────────────────────────────────────────────────────────
export default function StatsScreen({ state, dk }) {
  const th  = T(dk);
  const rtl = isRTL();
  const { profile, words, sessions = [] } = state;
  const lv       = getLevelFromXP(profile.xp);
  const lvl      = LEVELS[lv] || LEVELS[0];
  const mastered = words.filter(w => w.mastered);
  const hard     = words.filter(w => w.hard);
  const learning = words.filter(w => !w.mastered && !w.hard && w.correctStreak > 0);
  const newW     = words.filter(w => !w.mastered && !w.hard && !w.correctStreak);

  const totalReviews = sessions.reduce((a, s) => a + (s.total || 0), 0);
  const totalCorrect = sessions.reduce((a, s) => a + (s.correct || 0), 0);
  const accuracy    = totalReviews > 0 ? Math.round((totalCorrect / totalReviews) * 100) : 0;
  const avgDuration = sessions.length > 0
    ? Math.round(sessions.reduce((a, s) => a + (s.duration || 0), 0) / sessions.length) : 0;

  // Last 7 days — short 3-char labels work fine in both languages
  const last7 = useMemo(() => Array.from({ length: 7 }, (_, i) => {
    const d  = nDaysAgo(6 - i);
    const ds = sessions.filter(s => s.date === d);
    return {
      label:    weekDayLabel(d),
      reviewed: ds.reduce((a, s) => a + (s.total || 0), 0),
      correct:  ds.reduce((a, s) => a + (s.correct || 0), 0),
      added:    words.filter(w => w.addedDate?.startsWith(d)).length,
    };
  }), [sessions, words]);

  const pieData = [
    { label: t('mastered'), value: mastered.length, color: '#10B981' },
    { label: t('learning'), value: learning.length, color: '#7C3AED' },
    { label: t('hard'),     value: hard.length,     color: '#EF4444' },
    { label: t('new2'),     value: newW.length,     color: '#F59E0B' },
  ].filter(d => d.value > 0);

  const thr = [0, 200, 500, 1000, 2000];
  const cur = thr[lv] || 0, nxt = thr[lv + 1] || cur + 500;
  const xpPct = Math.min(((profile.xp - cur) / (nxt - cur)) * 100, 100) || 0;
  const ta  = rtl ? 'right' : 'left';
  const row = rtl ? 'row-reverse' : 'row';

  const KPI = ({ label, value, color, bg }) => (
    <View style={[s.kpi, { backgroundColor: bg }]}>
      <Text style={[s.kpiVal, { color }]}>{value}</Text>
      <Text style={[s.kpiLbl, { color, textAlign: 'center' }]}>{label}</Text>
    </View>
  );

  const ChartCard = ({ title, children }) => (
    <Card dk={dk} style={s.chartCard}>
      <Text style={[s.chartTitle, { color: th.text, textAlign: ta }]}>{title}</Text>
      {children}
    </Card>
  );

  return (
    <ScrollView style={[s.container, { backgroundColor: th.bg }]} contentContainerStyle={s.content}>
      <Text style={[s.pageTitle, { color: th.text, textAlign: ta }]}>{t('statistics')}</Text>

      {/* Level hero */}
      <LinearGradient colors={['#7C3AED', '#5B21B6']} style={s.levelCard}>
        <View style={{ flexDirection: row, alignItems: 'center', gap: 16 }}>
          <Text style={{ fontSize: 52, lineHeight: 60 }}>{lvl.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={[s.levelName, { textAlign: ta }]}>{levelName(lv)}</Text>
            <Text style={[s.levelXP,   { textAlign: ta }]}>{profile.xp} XP · {t('level')} {lv + 1}/4</Text>
            <View style={s.xpBarBg}>
              <View style={[s.xpBarFill, { width: `${xpPct}%` }]}/>
            </View>
          </View>
        </View>
      </LinearGradient>

      {/* KPI row 1 */}
      <View style={[s.kpiRow, { flexDirection: row }]}>
        <View style={[s.kpiHero, { backgroundColor: '#FF6B6B' }]}>
          <Text style={{ fontSize: 32 }}>🔥</Text>
          <Text style={s.kpiHeroVal}>{profile.streak}</Text>
          <Text style={s.kpiHeroLbl}>{t('streakDays')}</Text>
        </View>
        <View style={[s.kpiHero, { backgroundColor: '#7C3AED' }]}>
          <Text style={{ fontSize: 32 }}>📝</Text>
          <Text style={s.kpiHeroVal}>{words.length}</Text>
          <Text style={s.kpiHeroLbl}>{t('totalWords')}</Text>
        </View>
      </View>

      {/* KPI row 2 */}
      <View style={[s.kpiRow, { flexDirection: row }]}>
        <KPI label={t('mastered')}  value={mastered.length} color="#10B981" bg={th.gLight}/>
        <KPI label={t('accuracy')}  value={`${accuracy}%`} color="#7C3AED" bg={th.pLight}/>
        <KPI label={t('avgSession')}value={`${avgDuration}${t('seconds')}`} color="#F59E0B" bg={th.goLight}/>
      </View>

      {/* Hint points */}
      <Card dk={dk} style={{ flexDirection: row, justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <Text style={{ fontSize: 14, fontWeight: '700', color: th.textSub }}>💡 {t('hintPoints')}</Text>
        <Text style={{ fontSize: 22, fontWeight: '900', color: th.gold }}>{profile.hintPoints}</Text>
      </Card>

      {/* Weekly activity bar chart — CUSTOM (RTL-safe, no repeated Y) */}
      <ChartCard title={t('weeklyActivity')}>
        <CustomBarChart
          data={last7.map(d => ({ label: d.label, value: d.reviewed }))}
          color="#7C3AED" height={160} dk={dk}
        />
        <View style={{ flexDirection: row, gap: 16, justifyContent: 'center', marginTop: 8 }}>
          <View style={{ flexDirection: row, alignItems: 'center', gap: 5 }}>
            <View style={{ width: 10, height: 10, borderRadius: 2, backgroundColor: '#7C3AED' }}/>
            <Text style={{ fontSize: 12, color: th.textSub }}>{t('reviewed')}</Text>
          </View>
        </View>
      </ChartCard>

      {/* Word distribution — CUSTOM pie */}
      {pieData.length > 0 && (
        <ChartCard title={t('wordDistribution')}>
          <CustomPie data={pieData} dk={dk}/>
        </ChartCard>
      )}

      {/* Daily additions */}
      {last7.some(d => d.added > 0) && (
        <ChartCard title={t('dailyAdded')}>
          <CustomBarChart
            data={last7.map(d => ({ label: d.label, value: d.added }))}
            color="#F59E0B" height={140} dk={dk}
          />
        </ChartCard>
      )}

      {/* Session history */}
      {sessions.length > 0 && (
        <ChartCard title={t('lastSessions')}>
          {sessions.slice(-5).reverse().map((ss, i) => (
            <View key={i} style={[{ flexDirection: row, justifyContent: 'space-between', paddingVertical: 10 },
              i > 0 && { borderTopWidth: 1, borderTopColor: th.border }]}>
              <View>
                <Text style={{ fontWeight: '700', fontSize: 14, color: th.text }}>{ss.date}</Text>
                <Text style={{ fontSize: 12, color: th.textSub, marginTop: 2 }}>
                  {ss.total} {t('reviewed')} · {ss.duration}{t('seconds')}
                </Text>
              </View>
              <View style={{ alignItems: rtl ? 'flex-start' : 'flex-end' }}>
                <Text style={{ fontWeight: '900', fontSize: 16, color: th.green }}>✅ {ss.correct}/{ss.total}</Text>
                <Text style={{ fontSize: 11, color: th.textMuted }}>
                  {ss.total > 0 ? Math.round((ss.correct / ss.total) * 100) : 0}%
                </Text>
              </View>
            </View>
          ))}
        </ChartCard>
      )}

      {/* Hardest words */}
      {hard.length > 0 && (
        <ChartCard title={t('hardestWords')}>
          {hard.slice(0, 5).map((w) => {
            const pct = Math.min(((w.incorrectStreak || 0) / 5) * 100, 100);
            return (
              <View key={w.id} style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: row, justifyContent: 'space-between', marginBottom: 4 }}>
                  <Text style={{ color: th.text, fontWeight: '700', fontSize: 13 }}>{w.word}</Text>
                  <Text style={{ color: th.red, fontSize: 12 }}>×{w.incorrectStreak || 0}</Text>
                </View>
                <View style={{ height: 6, backgroundColor: th.border, borderRadius: 4, overflow: 'hidden' }}>
                  <View style={{ height: '100%', width: `${pct}%`, backgroundColor: th.red, borderRadius: 4 }}/>
                </View>
              </View>
            );
          })}
        </ChartCard>
      )}

      {words.length === 0 && (
        <Card dk={dk} style={{ alignItems: 'center', padding: 44 }}>
          <Text style={{ fontSize: 52, marginBottom: 10 }}>📭</Text>
          <Text style={{ color: th.textMuted, textAlign: 'center' }}>{t('noStats')}</Text>
        </Card>
      )}

      <View style={{ height: 32 }}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:  { flex: 1 },
  content:    { padding: 16 },
  pageTitle:  { fontSize: 22, fontWeight: '900', marginBottom: 18 },
  levelCard:  { borderRadius: 18, padding: 16, marginBottom: 14 },
  levelName:  { fontSize: 18, fontWeight: '900', color: '#fff' },
  levelXP:    { fontSize: 13, color: 'rgba(255,255,255,.85)', marginVertical: 4 },
  xpBarBg:    { height: 8, backgroundColor: 'rgba(255,255,255,.25)', borderRadius: 6, overflow: 'hidden', marginTop: 6 },
  xpBarFill:  { height: '100%', backgroundColor: 'rgba(255,255,255,.85)', borderRadius: 6 },
  kpiRow:     { gap: 10, marginBottom: 10 },
  kpiHero:    { flex: 1, borderRadius: 16, padding: 16, alignItems: 'center', gap: 4 },
  kpiHeroVal: { fontSize: 26, fontWeight: '900', color: '#fff' },
  kpiHeroLbl: { fontSize: 12, color: 'rgba(255,255,255,.85)', textAlign: 'center' },
  kpi:        { flex: 1, borderRadius: 13, padding: 12, alignItems: 'center' },
  kpiVal:     { fontSize: 22, fontWeight: '900' },
  kpiLbl:     { fontSize: 11, marginTop: 2 },
  chartCard:  { marginBottom: 14, padding: 16 },
  chartTitle: { fontSize: 14, fontWeight: '900', marginBottom: 14 },
});
