import React, { useMemo } from 'react';
import { View, Text, ScrollView, StyleSheet, Dimensions } from 'react-native';
import { BarChart, PieChart } from 'react-native-chart-kit';
import { LinearGradient } from 'expo-linear-gradient';
import { T } from '../theme';
import { LEVELS, getLevelFromXP, nDaysAgo } from '../state';
import { t, isRTL, levelName } from '../i18n';
import { Card } from '../components';

const W       = Dimensions.get('window').width;
const CHART_W = W - 32;

// English-only chart labels (Arabic breaks in SVG renderer)
const CHART_DAY    = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const chartDayLbl  = (iso) => CHART_DAY[new Date(iso).getDay()];
const PIE_LABELS   = { mastered:'Mastered', learning:'Learning', hard:'Hard', new:'New' };

// Chart config — creates a fresh 'shown' set per chart to deduplicate Y labels
const makeCfg = (th, maxVal = 10) => {
  const safeMax   = Math.max(1, Math.ceil(maxVal));
  const tickCount = Math.min(safeMax, 5);
  const shown     = new Set();
  return {
    backgroundColor:        th.card,
    backgroundGradientFrom: th.card,
    backgroundGradientTo:   th.card,
    color:        (op = 1) => `rgba(124,58,237,${op})`,
    labelColor:   ()        => th.textMuted,
    decimalPlaces: 0,
    formatYLabel: (raw) => {
      const n   = Math.round(Number(raw));
      const key = String(n);
      if (shown.has(key)) return '';   // suppress duplicate label
      shown.add(key);
      return key;
    },
    propsForLabels: { fontSize: 10 },
    barPercentage:  0.55,
    count: tickCount,
  };
};

export default function StatsScreen({ state, dk }) {
  const th  = T(dk);
  const rtl = isRTL();
  const { profile, words, sessions = [] } = state;

  const lv       = getLevelFromXP(profile.xp);
  const lvl      = LEVELS[lv] || LEVELS[0];
  const mastered = words.filter(w => w.mastered);
  const hard     = words.filter(w => w.hard);
  const learning = words.filter(w => !w.mastered && !w.hard && w.correctStreak > 0);
  const newW     = words.filter(w => !w.mastered && !w.hard && !w.correctStreak);

  const totalReviews = sessions.reduce((a, s) => a + (s.total || 0), 0);
  const totalCorrect = sessions.reduce((a, s) => a + (s.correct || 0), 0);
  const accuracy     = totalReviews > 0 ? Math.round((totalCorrect / totalReviews) * 100) : 0;
  const avgDuration  = sessions.length > 0
    ? Math.round(sessions.reduce((a, s) => a + (s.duration || 0), 0) / sessions.length) : 0;

  const last7 = useMemo(() => Array.from({ length: 7 }, (_, i) => {
    const d  = nDaysAgo(6 - i);
    const ds = sessions.filter(s => s.date === d);
    return {
      chartDay: chartDayLbl(d),
      reviewed: ds.reduce((a, s) => a + (s.total  || 0), 0),
      correct:  ds.reduce((a, s) => a + (s.correct || 0), 0),
      added:    words.filter(w => w.addedDate?.startsWith(d)).length,
    };
  }), [sessions, words]);

  const maxReviewed = Math.max(...last7.map(d => d.reviewed), 1);
  const maxAdded    = Math.max(...last7.map(d => d.added), 1);

  const barData   = { labels: last7.map(d => d.chartDay), datasets: [{ data: last7.map(d => d.reviewed) }] };
  const addedData = {
    labels: last7.map(d => d.chartDay),
    datasets: [{ data: last7.map(d => d.added), color: (o = 1) => `rgba(245,158,11,${o})` }],
  };

  // Pie: ENGLISH-ONLY names (SVG can't render Arabic correctly)
  const pieData = [
    { name: PIE_LABELS.mastered, population: mastered.length || 0, color: '#10B981', legendFontColor: th.text, legendFontSize: 11 },
    { name: PIE_LABELS.learning, population: learning.length || 0, color: '#7C3AED', legendFontColor: th.text, legendFontSize: 11 },
    { name: PIE_LABELS.hard,     population: hard.length     || 0, color: '#EF4444', legendFontColor: th.text, legendFontSize: 11 },
    { name: PIE_LABELS.new,      population: newW.length     || 0, color: '#F59E0B', legendFontColor: th.text, legendFontSize: 11 },
  ].filter(d => d.population > 0);

  const thr  = [0, 200, 500, 1000, 2000];
  const cur  = thr[lv] || 0;
  const nxt  = thr[lv + 1] || cur + 500;
  const xpPct = Math.min(((profile.xp - cur) / (nxt - cur)) * 100, 100) || 0;

  const ta     = rtl ? 'right' : 'left';
  const rowDir = rtl ? 'row-reverse' : 'row';

  const KPI = ({ label, value, color, bg }) => (
    <View style={[s.kpi, { backgroundColor: bg }]}>
      <Text style={[s.kpiVal, { color }]}>{value}</Text>
      <Text style={[s.kpiLbl, { color, textAlign: 'center' }]}>{label}</Text>
    </View>
  );
  const ChartCard = ({ title, children }) => (
    <Card dk={dk} style={s.chartCard}>
      <Text style={[s.chartTitle, { color: th.text, textAlign: ta }]}>{title}</Text>
      {children}
    </Card>
  );

  return (
    <ScrollView style={[s.container, { backgroundColor: th.bg }]} contentContainerStyle={s.content}>
      <Text style={[s.pageTitle, { color: th.text, textAlign: ta }]}>{t('statistics')}</Text>

      <LinearGradient colors={['#7C3AED', '#5B21B6']} style={s.levelCard}>
        <View style={{ flexDirection: rowDir, alignItems: 'center', gap: 16 }}>
          <Text style={{ fontSize: 52, lineHeight: 60 }}>{lvl.icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={[s.levelName, { textAlign: ta }]}>{levelName(lv)}</Text>
            <Text style={[s.levelXP, { textAlign: ta }]}>{profile.xp} XP · {t('level')} {lv + 1}/4</Text>
            <View style={s.xpBarBg}><View style={[s.xpBarFill, { width: `${xpPct}%` }]}/></View>
          </View>
        </View>
      </LinearGradient>

      <View style={[s.kpiRow, { flexDirection: rowDir }]}>
        <View style={[s.kpiHero, { backgroundColor: '#FF6B6B' }]}>
          <Text style={{ fontSize: 32 }}>🔥</Text>
          <Text style={s.kpiHeroVal}>{profile.streak}</Text>
          <Text style={s.kpiHeroLbl}>{t('streakDays')}</Text>
        </View>
        <View style={[s.kpiHero, { backgroundColor: '#7C3AED' }]}>
          <Text style={{ fontSize: 32 }}>📝</Text>
          <Text style={s.kpiHeroVal}>{words.length}</Text>
          <Text style={s.kpiHeroLbl}>{t('totalWords')}</Text>
        </View>
      </View>

      <View style={[s.kpiRow, { flexDirection: rowDir }]}>
        <KPI label={t('mastered')}   value={mastered.length}          color="#10B981" bg={th.gLight}/>
        <KPI label={t('accuracy')}   value={`${accuracy}%`}           color="#7C3AED" bg={th.pLight}/>
        <KPI label={t('avgSession')} value={`${avgDuration}${t('seconds')}`} color="#F59E0B" bg={th.goLight}/>
      </View>

      <Card dk={dk} style={{ flexDirection: rowDir, justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <Text style={{ fontSize: 14, fontWeight: '700', color: th.textSub }}>💡 {t('hintPoints')}</Text>
        <Text style={{ fontSize: 22, fontWeight: '900', color: th.gold }}>{profile.hintPoints}</Text>
      </Card>

      {last7.some(d => d.reviewed > 0) && (
        <ChartCard title={t('weeklyActivity')}>
          <BarChart
            data={barData}
            width={CHART_W - 32}
            height={180}
            chartConfig={makeCfg(th, maxReviewed)}
            style={s.chart}
            showValuesOnTopOfBars
            fromZero
            withInnerLines={false}
            segments={Math.min(maxReviewed, 5)}
          />
          <View style={[s.legend, { flexDirection: rowDir }]}>
            <View style={{ flexDirection: rowDir, alignItems: 'center', gap: 5 }}>
              <View style={[s.legendDot, { backgroundColor: '#7C3AED' }]}/>
              <Text style={[s.legendTxt, { color: th.textSub }]}>{t('reviewed')}</Text>
            </View>
          </View>
        </ChartCard>
      )}

      {pieData.length > 0 && (
        <ChartCard title={t('wordDistribution')}>
          <PieChart
            data={pieData}
            width={CHART_W - 32}
            height={160}
            chartConfig={makeCfg(th)}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="12"
            style={s.chart}
          />
        </ChartCard>
      )}

      {last7.some(d => d.added > 0) && (
        <ChartCard title={t('dailyAdded')}>
          <BarChart
            data={addedData}
            width={CHART_W - 32}
            height={150}
            chartConfig={{ ...makeCfg(th, maxAdded), color: (o = 1) => `rgba(245,158,11,${o})` }}
            style={s.chart}
            fromZero
            withInnerLines={false}
            segments={Math.min(maxAdded, 5)}
          />
        </ChartCard>
      )}

      {sessions.length > 0 && (
        <ChartCard title={t('lastSessions')}>
          {sessions.slice(-5).reverse().map((ss, i) => (
            <View key={i} style={[s.sessionRow, { flexDirection: rowDir },
              i > 0 && { borderTopWidth: 1, borderTopColor: th.border }]}>
              <View>
                <Text style={{ fontWeight: '700', fontSize: 14, color: th.text, textAlign: ta }}>{ss.date}</Text>
                <Text style={{ fontSize: 12, color: th.textSub, marginTop: 2, textAlign: ta }}>
                  {ss.total} {t('reviewed')} · {ss.duration}{t('seconds')}
                </Text>
              </View>
              <View style={{ alignItems: rtl ? 'flex-start' : 'flex-end' }}>
                <Text style={{ fontWeight: '900', fontSize: 16, color: th.green }}>✅ {ss.correct}/{ss.total}</Text>
                <Text style={{ fontSize: 11, color: th.textMuted }}>
                  {ss.total > 0 ? Math.round((ss.correct / ss.total) * 100) : 0}%
                </Text>
              </View>
            </View>
          ))}
        </ChartCard>
      )}

      {hard.length > 0 && (
        <ChartCard title={t('hardestWords')}>
          {hard.slice(0, 5).map((w) => {
            const pct = Math.min(((w.incorrectStreak || 0) / 5) * 100, 100);
            return (
              <View key={w.id} style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: rowDir, justifyContent: 'space-between', marginBottom: 4 }}>
                  <Text style={{ color: th.text, fontWeight: '700', fontSize: 13 }}>{w.word}</Text>
                  <Text style={{ color: th.red, fontSize: 12 }}>x{w.incorrectStreak || 0}</Text>
                </View>
                <View style={{ height: 6, backgroundColor: th.border, borderRadius: 4, overflow: 'hidden' }}>
                  <View style={{ height: '100%', width: `${pct}%`, backgroundColor: th.red, borderRadius: 4 }}/>
                </View>
              </View>
            );
          })}
        </ChartCard>
      )}

      {words.length === 0 && (
        <Card dk={dk} style={{ alignItems: 'center', padding: 44 }}>
          <Text style={{ fontSize: 52, marginBottom: 10 }}>📭</Text>
          <Text style={{ color: th.textMuted, textAlign: 'center' }}>{t('noStats')}</Text>
        </Card>
      )}
      <View style={{ height: 40 }}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:   { flex:1 },
  content:     { padding:16 },
  pageTitle:   { fontSize:24, fontWeight:'900', marginBottom:16, marginTop:52 },
  levelCard:   { borderRadius:18, padding:20, marginBottom:14 },
  levelName:   { fontSize:20, fontWeight:'900', color:'#fff' },
  levelXP:     { fontSize:13, color:'rgba(255,255,255,.85)', marginTop:2, marginBottom:8 },
  xpBarBg:     { height:8, backgroundColor:'rgba(255,255,255,.3)', borderRadius:8, overflow:'hidden' },
  xpBarFill:   { height:'100%', backgroundColor:'#fff', borderRadius:8 },
  kpiRow:      { gap:12, marginBottom:12 },
  kpiHero:     { flex:1, borderRadius:18, padding:18, alignItems:'center', gap:4 },
  kpiHeroVal:  { fontSize:30, fontWeight:'900', color:'#fff' },
  kpiHeroLbl:  { fontSize:12, color:'rgba(255,255,255,.85)', textAlign:'center' },
  kpi:         { flex:1, borderRadius:14, padding:14, alignItems:'center', gap:4 },
  kpiVal:      { fontSize:22, fontWeight:'900' },
  kpiLbl:      { fontSize:11 },
  chartCard:   { marginBottom:14 },
  chartTitle:  { fontSize:15, fontWeight:'800', marginBottom:10 },
  chart:       { borderRadius:12, alignSelf:'center' },
  legend:      { justifyContent:'center', gap:16, marginTop:6 },
  legendDot:   { width:10, height:10, borderRadius:5 },
  legendTxt:   { fontSize:12 },
  sessionRow:  { paddingVertical:10, justifyContent:'space-between' },
});
