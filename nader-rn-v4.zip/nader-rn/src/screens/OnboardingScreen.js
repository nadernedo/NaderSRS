import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  StyleSheet, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Btn, Inp, Elephant } from '../components';
import { LANGUAGES } from '../state';
import { t, setUILang } from '../i18n';

const UI_LANGS = [
  { code:'ar', label:'العربية', flag:'🇸🇦' },
  { code:'en', label:'English', flag:'🇺🇸' },
];

export default function OnboardingScreen({ onDone }) {
  const [step,      setStep]    = useState(0);
  const [name,      setName]    = useState('');
  const [studyLang, setStudyLang] = useState('en');
  const [uiLang,    setUiLang_]  = useState('ar');

  const pickUI = (code) => { setUiLang_(code); setUILang(code); };

  const finish = () => onDone({ name, language: studyLang, uiLanguage: uiLang });

  const steps = [
    <View key={0} style={s.stepCenter}>
      <Elephant size={90}/>
      <Text style={s.heroTitle}>Hey, welcome to Nader! 🎉</Text>
      <Text style={s.heroSub}>Your AI-powered vocab buddy — let's build your word game 🚀</Text>
      <Btn onPress={()=>setStep(1)} full size="lg">Let's go! 🐘</Btn>
    </View>,

    <View key={1} style={[s.stepCenter,{gap:16}]}>
      <Elephant size={60}/>
      <Text style={s.stepTitle}>{uiLang==='ar'?'اختر لغة الواجهة':'Choose interface language'}</Text>
      <View style={s.uiLangRow}>
        {UI_LANGS.map(l=>(
          <TouchableOpacity key={l.code} onPress={()=>pickUI(l.code)}
            style={[s.uiLangCard, uiLang===l.code && s.uiLangCardActive]}>
            <Text style={{fontSize:36}}>{l.flag}</Text>
            <Text style={[s.uiLangLabel, uiLang===l.code && {color:'#6D28D9'}]}>{l.label}</Text>
            {uiLang===l.code && <Text style={{fontSize:18}}>✓</Text>}
          </TouchableOpacity>
        ))}
      </View>
      <Btn onPress={()=>setStep(2)} full size="lg">{uiLang==='ar'?'التالي ➜':'Next ➜'}</Btn>
    </View>,

    <KeyboardAvoidingView key={2} behavior={Platform.OS==='ios'?'padding':undefined} style={s.stepCenter}>
      <Elephant size={60}/>
      <Text style={s.stepTitle}>{t('whatsYourName')}</Text>
      <Inp value={name} onChange={setName} placeholder={t('typeName')}
        style={{textAlign:'center',fontSize:18,fontWeight:'700',marginBottom:20,width:'100%'}} autoFocus/>
      <Btn onPress={()=>name.trim()&&setStep(3)} disabled={!name.trim()} full size="lg">{t('next')}</Btn>
    </KeyboardAvoidingView>,

    <View key={3} style={{width:'100%'}}>
      <Text style={[s.stepTitle,{marginBottom:16}]}>{t('whatLang')}</Text>
      <View style={s.langGrid}>
        {LANGUAGES.map(l=>(
          <TouchableOpacity key={l.code} onPress={()=>setStudyLang(l.code)}
            style={[s.langCard, studyLang===l.code && s.langCardActive]}>
            <Text style={{fontSize:26,marginBottom:4}}>{l.flag}</Text>
            <Text style={[s.langName, studyLang===l.code && {color:'#6D28D9'}]}>{l.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Btn onPress={()=>setStep(4)} full size="lg" style={{marginTop:16}}>{t('next')}</Btn>
    </View>,

    <View key={4} style={s.stepCenter}>
      <Text style={{fontSize:72,marginBottom:14}}>🎊</Text>
      <Text style={s.heroTitle}>{t('allSet')}, {name}! 🎉</Text>
      <Text style={s.heroSub}>
        {uiLang==='ar'?'فيلك 🐘 جاهز لمساعدتك في تعلم ':'Your elephant buddy 🐘 is ready to help you crush '}
        <Text style={{fontWeight:'900'}}>{LANGUAGES.find(l=>l.code===studyLang)?.name}</Text>!
      </Text>
      <Btn onPress={finish} full size="lg">{t('startLearning')}</Btn>
    </View>,
  ];

  return (
    <LinearGradient colors={['#7C3AED','#5B21B6','#4C1D95']} style={s.container}>
      <View style={s.card}>
        <View style={s.dots}>
          {steps.map((_,i)=>(
            <View key={i} style={[s.dot, i<=step&&s.dotActive, i===step&&s.dotCurrent]}/>
          ))}
        </View>
        <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {steps[step]}
        </ScrollView>
        {step>0 && (
          <TouchableOpacity onPress={()=>setStep(p=>p-1)} style={s.backBtn}>
            <Text style={s.backTxt}>← {uiLang==='ar'?'رجوع':'Back'}</Text>
          </TouchableOpacity>
        )}
      </View>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:       {flex:1,alignItems:'center',justifyContent:'center',padding:20},
  card:            {width:'100%',maxWidth:400,backgroundColor:'#fff',borderRadius:28,overflow:'hidden',maxHeight:'92%'},
  dots:            {flexDirection:'row',justifyContent:'center',gap:7,paddingTop:18},
  dot:             {height:7,width:7,borderRadius:4,backgroundColor:'#EEE'},
  dotActive:       {backgroundColor:'#C4B5FD'},
  dotCurrent:      {width:22,backgroundColor:'#7C3AED'},
  scroll:          {padding:28,paddingTop:20},
  stepCenter:      {alignItems:'center',gap:16,width:'100%'},
  heroTitle:       {fontSize:24,fontWeight:'900',color:'#1A1A2E',textAlign:'center',marginTop:10},
  heroSub:         {fontSize:15,color:'#888',textAlign:'center',lineHeight:26,marginBottom:16},
  stepTitle:       {fontSize:20,fontWeight:'900',color:'#1A1A2E',textAlign:'center'},
  uiLangRow:       {flexDirection:'row',gap:12,width:'100%'},
  uiLangCard:      {flex:1,alignItems:'center',gap:6,padding:18,borderRadius:16,borderWidth:2.5,borderColor:'#E8E4F8',backgroundColor:'#fff'},
  uiLangCardActive:{borderColor:'#7C3AED',backgroundColor:'#F5F3FF'},
  uiLangLabel:     {fontSize:15,fontWeight:'700',color:'#666'},
  langGrid:        {flexDirection:'row',flexWrap:'wrap',gap:10},
  langCard:        {width:'48%',padding:13,borderRadius:13,alignItems:'center',borderWidth:2.5,borderColor:'#E8E4F8',backgroundColor:'#fff'},
  langCardActive:  {borderColor:'#7C3AED',backgroundColor:'#F5F3FF'},
  langName:        {fontSize:13,fontWeight:'700',color:'#666'},
  backBtn:         {padding:14,alignItems:'center'},
  backTxt:         {color:'#9999BB',fontWeight:'600',fontSize:14},
});
