import React, { useState, useEffect, useReducer } from 'react';
import { View, StatusBar, ActivityIndicator, Text, StyleSheet, I18nManager } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts, Nunito_400Regular, Nunito_600SemiBold, Nunito_700Bold, Nunito_800ExtraBold, Nunito_900Black } from '@expo-google-fonts/nunito';

import { loadState, saveState }             from './src/services/storage';
import { reducer, todayStr }                from './src/state';
import { scheduleDaily, requestPermission } from './src/services/notifications';
import { setUILang }                        from './src/i18n';
import AppNavigator                         from './src/navigation/AppNavigator';
import OnboardingScreen                     from './src/screens/OnboardingScreen';

SplashScreen.preventAutoHideAsync();

export default function App() {
  const [appState, dispatch] = useReducer(reducer, null);
  const [ready, setReady]    = useState(false);
  const [rtl,   setRtl]      = useState(true);

  const [fontsLoaded] = useFonts({
    Nunito_400Regular, Nunito_600SemiBold,
    Nunito_700Bold, Nunito_800ExtraBold, Nunito_900Black,
  });

  const applyDirection = (lang) => {
    const shouldRTL = lang === 'ar';
    setRtl(shouldRTL);
    I18nManager.forceRTL(shouldRTL);
  };

  useEffect(() => {
    if (appState === null) {
      loadState().then(saved => {
        const lang = saved?.settings?.uiLanguage || 'ar';
        setUILang(lang);
        applyDirection(lang);
        dispatch({ type:'_LOAD', state: saved });
      });
    }
  }, []);

  useEffect(() => {
    if (!appState) return;
    saveState(appState);
    const lang = appState.settings?.uiLanguage || 'ar';
    setUILang(lang);
    applyDirection(lang);
  }, [appState]);

  useEffect(() => {
    if (!appState) return;
    const last = appState.profile.lastActive;
    if (last && last !== todayStr() && appState.profile.hintPoints < 30) {
      dispatch({ type:'SAVE_PROFILE', profile:{ hintPoints:30 } });
    }
  }, [appState?.profile?.lastActive]);

  useEffect(() => {
    if (!appState?.onboarded) return;
    const { notifEnabled, notifTime, notifMessage, notifCustom } = appState.settings;
    if (notifEnabled) {
      requestPermission().then(perm => {
        if (perm === 'granted') {
          scheduleDaily(true, notifTime || '20:00', notifMessage, notifCustom, appState.profile);
        }
      });
    }
  }, [!!appState?.onboarded]);

  useEffect(() => {
    if (fontsLoaded && appState !== null) {
      setReady(true);
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, appState]);

  if (!ready || appState === null) {
    return (
      <View style={s.splash}>
        <Text style={s.splashEmoji}>🐘</Text>
        <ActivityIndicator color="#fff" size="large" style={{ marginTop:16 }}/>
      </View>
    );
  }

  const dk = appState.settings.darkMode;

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor="#7C3AED"/>
      <SafeAreaView style={{ flex:1, backgroundColor: dk ? '#0F0F1A' : '#EDECF8' }} edges={['top']}>
        {!appState.onboarded
          ? <OnboardingScreen onDone={(data) => dispatch({ type:'ONBOARD', ...data })}/>
          : <AppNavigator state={appState} dispatch={dispatch} rtl={rtl}/>
        }
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  splash:      { flex:1, backgroundColor:'#7C3AED', alignItems:'center', justifyContent:'center' },
  splashEmoji: { fontSize:80 },
});
