import React, { useState, useEffect, useCallback, useReducer } from 'react';
import { View, StatusBar, ActivityIndicator, Text, StyleSheet } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts, Nunito_400Regular, Nunito_600SemiBold, Nunito_700Bold, Nunito_800ExtraBold, Nunito_900Black } from '@expo-google-fonts/nunito';

import { loadState, saveState } from './src/services/storage';
import { reducer, todayStr, initState } from './src/state';
import { scheduleDaily } from './src/services/notifications';
import AppNavigator     from './src/navigation/AppNavigator';
import OnboardingScreen from './src/screens/OnboardingScreen';

SplashScreen.preventAutoHideAsync();

export default function App() {
  const [appState, dispatch] = useReducer(reducer, null);
  const [ready, setReady]    = useState(false);

  const [fontsLoaded] = useFonts({
    Nunito_400Regular, Nunito_600SemiBold,
    Nunito_700Bold, Nunito_800ExtraBold, Nunito_900Black,
  });

  // Load state from AsyncStorage on boot
  useEffect(() => {
    if (appState === null) {
      loadState().then(saved => {
        dispatch({ type:'_LOAD', state: saved });
      });
    }
  }, []);

  // Save to AsyncStorage on every state change
  useEffect(() => {
    if (appState) saveState(appState);
  }, [appState]);

  // Daily hint refresh
  useEffect(() => {
    if (!appState) return;
    const last = appState.profile.lastActive;
    if (last && last !== todayStr() && appState.profile.hintPoints < 30) {
      dispatch({ type:'SAVE_PROFILE', profile:{ hintPoints:30 } });
    }
  }, [appState?.profile?.lastActive]);

  // Re-schedule notification on boot
  useEffect(() => {
    if (!appState) return;
    const { notifEnabled, notifTime, notifMessage, notifCustom } = appState.settings;
    if (notifEnabled) {
      scheduleDaily(notifEnabled, notifTime, notifMessage, notifCustom, appState.profile);
    }
  }, [!!appState]);

  // Hide splash when ready
  useEffect(() => {
    if (fontsLoaded && appState !== null) {
      setReady(true);
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, appState]);

  if (!ready || appState === null) {
    return (
      <View style={s.splash}>
        <Text style={s.splashEmoji}>🐘</Text>
        <ActivityIndicator color="#fff" size="large" style={{ marginTop:16 }}/>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar
        barStyle={appState.settings.darkMode ? 'light-content' : 'dark-content'}
        backgroundColor={appState.settings.darkMode ? '#0F0F1A' : '#7C3AED'}
      />
      <SafeAreaView style={{ flex:1, backgroundColor: appState.settings.darkMode ? '#0F0F1A' : '#EDECF8' }} edges={['top']}>
        {!appState.onboarded
          ? <OnboardingScreen onDone={({ name, language }) => dispatch({ type:'ONBOARD', name, language })}/>
          : <AppNavigator state={appState} dispatch={dispatch}/>
        }
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  splash: { flex:1, backgroundColor:'#7C3AED', alignItems:'center', justifyContent:'center' },
  splashEmoji: { fontSize:80 },
});
