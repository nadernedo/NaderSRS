import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView,
  StyleSheet, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Btn, Inp, Elephant } from '../components';
import { LANGUAGES } from '../state';

export default function OnboardingScreen({ onDone }) {
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [lang, setLang] = useState('en');

  const steps = [
    // Step 0 — Welcome
    <View key={0} style={s.stepCenter}>
      <Elephant size={90}/>
      <Text style={s.heroTitle}>Hey, welcome to Nader! 🎉</Text>
      <Text style={s.heroSub}>Your AI-powered vocab buddy — let's build your word game 🚀</Text>
      <Btn onPress={()=>setStep(1)} full size="lg">Let's go! 🐘</Btn>
    </View>,

    // Step 1 — Name
    <KeyboardAvoidingView key={1} behavior={Platform.OS==='ios'?'padding':undefined} style={s.stepCenter}>
      <Elephant size={60}/>
      <Text style={s.stepTitle}>What's your name?</Text>
      <Inp
        value={name} onChange={setName}
        placeholder="Type your name..."
        style={{ textAlign:'center', fontSize:18, fontWeight:'700', marginBottom:20, width:'100%' }}
        autoFocus
      />
      <Btn onPress={()=>setStep(2)} disabled={!name.trim()} full size="lg">Next ➜</Btn>
    </KeyboardAvoidingView>,

    // Step 2 — Language
    <View key={2} style={{ width:'100%' }}>
      <Text style={[s.stepTitle, { marginBottom:16 }]}>What language are you learning?</Text>
      <View style={s.langGrid}>
        {LANGUAGES.map(l=>(
          <TouchableOpacity
            key={l.code}
            onPress={()=>setLang(l.code)}
            style={[s.langCard, lang===l.code && s.langCardActive]}
          >
            <Text style={{ fontSize:26, marginBottom:4 }}>{l.flag}</Text>
            <Text style={[s.langName, lang===l.code && { color:'#6D28D9' }]}>{l.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
      <Btn onPress={()=>setStep(3)} full size="lg" style={{ marginTop:16 }}>Next ➜</Btn>
    </View>,

    // Step 3 — Done
    <View key={3} style={s.stepCenter}>
      <Text style={{ fontSize:72, marginBottom:14 }}>🎊</Text>
      <Text style={s.heroTitle}>You're all set, {name}! 🎉</Text>
      <Text style={s.heroSub}>
        Your elephant buddy 🐘 is ready to help you crush{' '}
        <Text style={{ fontWeight:'900' }}>{LANGUAGES.find(l=>l.code===lang)?.name}</Text>!
      </Text>
      <Btn onPress={()=>onDone({name,language:lang})} full size="lg">Start learning! 🚀</Btn>
    </View>,
  ];

  return (
    <LinearGradient colors={['#7C3AED','#5B21B6','#4C1D95']} style={s.container}>
      <View style={s.card}>
        {/* Progress dots */}
        <View style={s.dots}>
          {[0,1,2,3].map(i=>(
            <View key={i} style={[s.dot, i<=step && s.dotActive, i===step && s.dotCurrent]}/>
          ))}
        </View>
        <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {steps[step]}
        </ScrollView>
      </View>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:    { flex:1, alignItems:'center', justifyContent:'center', padding:20 },
  card:         { width:'100%', maxWidth:400, backgroundColor:'#fff', borderRadius:28, overflow:'hidden', maxHeight:'90%' },
  dots:         { flexDirection:'row', justifyContent:'center', gap:7, paddingTop:18, paddingBottom:0 },
  dot:          { height:7, width:7, borderRadius:4, backgroundColor:'#EEE' },
  dotActive:    { backgroundColor:'#C4B5FD' },
  dotCurrent:   { width:22, backgroundColor:'#7C3AED' },
  scroll:       { padding:28, paddingTop:20 },
  stepCenter:   { alignItems:'center', gap:16, width:'100%' },
  heroTitle:    { fontSize:26, fontWeight:'900', color:'#1A1A2E', textAlign:'center', marginTop:10 },
  heroSub:      { fontSize:15, color:'#888', textAlign:'center', lineHeight:26, marginBottom:16 },
  stepTitle:    { fontSize:20, fontWeight:'900', color:'#1A1A2E', textAlign:'center' },
  langGrid:     { flexDirection:'row', flexWrap:'wrap', gap:10 },
  langCard:     { width:'48%', padding:13, borderRadius:13, alignItems:'center', borderWidth:2.5, borderColor:'#E8E4F8', backgroundColor:'#fff' },
  langCardActive:{ borderColor:'#7C3AED', backgroundColor:'#F5F3FF' },
  langName:     { fontSize:13, fontWeight:'700', color:'#666' },
});
