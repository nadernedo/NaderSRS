import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { T } from '../theme';
import { todayStr } from '../state';
import { aiEvaluateParagraph } from '../services/ai';
import { Card, Btn, Inp, Spinner } from '../components';

export default function ParagraphChallenge({ session, state, dispatch, onComplete, dk }) {
  const t = T(dk);
  const [text, setText]       = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult]   = useState(null);
  const [noteSaved, setNoteSaved] = useState(false);

  const minWords = Math.min(4, session.length);
  const used = session.filter(w => text.toLowerCase().includes(w.word.toLowerCase()));
  const passed = result && result.score >= 5;

  const evaluate = async () => {
    setLoading(true);
    try {
      const r = await aiEvaluateParagraph(text, session.map(w=>w.word), state.profile.language, state.settings);
      setResult(r);
    } catch {
      setResult({ score:6, feedback:'تعذّر التقييم.', corrections:[], encouragement:'🎉 عمل رائع!' });
    }
    setLoading(false);
  };

  const saveNote = () => {
    dispatch({ type:'SAVE_NOTE', note:{ date:todayStr(), paragraph:text, score:result.score, feedback:result.feedback, corrections:result.corrections||[], words:session.map(w=>w.word) } });
    setNoteSaved(true);
  };

  const finish = () => { dispatch({ type:'COMPLETE_SESSION' }); onComplete(); };

  const needMore = minWords - used.length;
  const btnLabel = loading
    ? '🐘 الفيل يقيّم...'
    : needMore > 0
    ? `أضف ${needMore} كلمة أخرى`
    : '🤖 تقييم الفقرة';

  return (
    <ScrollView style={[s.container,{backgroundColor:t.bg}]} keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}>
      {/* Header */}
      <View style={s.headerArea}>
        <Text style={s.bossEmoji}>⚔️</Text>
        <Text style={[s.title,{color:t.text}]}>تحدي الفقرة!</Text>
        <Text style={[s.sub,{color:t.textSub}]}>
          {session.length <= 4 ? 'استخدم جميع الكلمات في فقرة واحدة' : 'استخدم 4 كلمات على الأقل في فقرة واحدة'}
        </Text>
      </View>

      {/* Word chips */}
      <View style={s.chips}>
        {session.map(w => {
          const isUsed = text.toLowerCase().includes(w.word.toLowerCase());
          return (
            <View key={w.id} style={[s.chip, isUsed && s.chipUsed]}>
              <Text style={[s.chipTxt, isUsed && s.chipTxtUsed]}>{isUsed ? '✓ ' : ''}{w.word}</Text>
            </View>
          );
        })}
      </View>

      {/* Text area */}
      <Card dk={dk} style={s.inputCard}>
        <Inp value={text} onChange={setText} rows={5} dk={dk}
          placeholder="اكتب فقرتك... القصص الخيالية مقبولة 🐉"
          style={{ marginBottom:8 }}
        />
        <View style={s.statsRow}>
          <Text style={[s.statTxt,{color:t.textMuted}]}>مستخدمة: {used.length}/{minWords}</Text>
          <Text style={[s.statTxt,{color:t.textMuted}]}>{text.trim().split(/\s+/).filter(Boolean).length} كلمة</Text>
        </View>
      </Card>

      {!passed && (
        <Btn onPress={evaluate} disabled={loading || used.length < minWords} full style={{ marginBottom:12 }}>
          {btnLabel}
        </Btn>
      )}

      {loading && <Spinner message="الفيل يقيّم القواعد النحوية... 🤓" dk={dk}/>}

      {result && (
        <Card dk={dk} style={[s.resultCard, passed ? {backgroundColor:t.gLight,borderColor:t.green} : {backgroundColor:t.rLight,borderColor:t.red}]}>
          <View style={s.resultTop}>
            <Text style={{fontSize:52}}>{passed ? '🏆' : '💪'}</Text>
            <Text style={[s.score, {color:passed?t.green:t.red}]}>{result.score}<Text style={[s.scoreOf,{color:t.textMuted}]}>/10</Text></Text>
            <Text style={[s.feedback,{color:t.text}]}>{result.feedback}</Text>
            <Text style={[s.encouragement,{color:passed?t.green:t.red,fontWeight:'700'}]}>{result.encouragement}</Text>
          </View>

          {(result.corrections||[]).length > 0 && (
            <View style={[s.corrections,{backgroundColor:'rgba(255,255,255,.55)'}]}>
              <Text style={[s.correctionsTitle,{color:t.text}]}>📝 التصحيحات:</Text>
              {result.corrections.map((c,i)=>(
                <Text key={i} style={[s.correctionItem,{color:t.text}]}>• {c}</Text>
              ))}
            </View>
          )}

          {(result.corrections||[]).length > 0 && (
            <Btn onPress={noteSaved ? undefined : saveNote} variant={noteSaved?'green':'white'} full size="sm" dk={dk}>
              {noteSaved ? '✅ تم حفظ الملاحظات!' : '💾 احفظ التصحيحات كملاحظة'}
            </Btn>
          )}
        </Card>
      )}

      {passed
        ? <Btn onPress={finish} full size="lg" variant="gold" style={{marginTop:12}}>🎊 إنهاء الجلسة! (+50 XP)</Btn>
        : result && !passed && (
          <Text style={[s.retryHint,{color:t.textMuted}]}>تحتاج 5/10 للاجتياز. عدّل فقرتك وحاول مجدداً! 💪</Text>
        )
      }

      <View style={{height:32}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:   { flex:1 },
  content:     { padding:20 },
  headerArea:  { alignItems:'center', marginBottom:18 },
  bossEmoji:   { fontSize:52, marginBottom:8 },
  title:       { fontSize:22, fontWeight:'900', textAlign:'center' },
  sub:         { fontSize:13, textAlign:'center', marginTop:4 },
  chips:       { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:14 },
  chip:        { paddingVertical:5, paddingHorizontal:13, borderRadius:20, backgroundColor:'#E8E4F8' },
  chipUsed:    { backgroundColor:'#7C3AED' },
  chipTxt:     { fontSize:13, fontWeight:'700', color:'#9999BB' },
  chipTxtUsed: { color:'#fff' },
  inputCard:   { marginBottom:12 },
  statsRow:    { flexDirection:'row', justifyContent:'space-between' },
  statTxt:     { fontSize:12 },
  resultCard:  { borderWidth:2, marginBottom:14 },
  resultTop:   { alignItems:'center', marginBottom:14, gap:6 },
  score:       { fontSize:36, fontWeight:'900' },
  scoreOf:     { fontSize:18, fontWeight:'600' },
  feedback:    { fontSize:15, textAlign:'center', marginTop:4 },
  encouragement:{ fontSize:14, textAlign:'center' },
  corrections: { borderRadius:12, padding:12, marginBottom:12 },
  correctionsTitle:{ fontSize:13, fontWeight:'800', marginBottom:8 },
  correctionItem:{ fontSize:13, marginTop:4, lineHeight:20 },
  retryHint:   { textAlign:'center', fontSize:13, marginTop:12 },
});
