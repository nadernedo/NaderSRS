import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, Switch, TextInput, Modal,
} from 'react-native';
import { T } from '../theme';
import { GROQ_MODELS, NOTIF_MESSAGES, LANGUAGES } from '../state';
import { testGroqConnection } from '../services/ai';
import { requestPermission, getPermission, scheduleDaily, cancelAll, sendNow } from '../services/notifications';
import { Card, Btn, Inp, Toggle, Row } from '../components';

// ── Groq Setup Modal ──────────────────────────────────────────────────────────
const GroqModal = ({ settings, dk, onClose, onSave, onToast }) => {
  const t = T(dk);
  const [model,   setModel]   = useState(settings.aiModel || 'compound-beta');
  const [key,     setKey]     = useState(settings.groqApiKey || '');
  const [showKey, setShowKey] = useState(false);
  const [testing, setTesting] = useState(false);
  const [result,  setResult]  = useState(null);

  const runTest = async () => {
    if (!key.trim()) { setResult({ok:false,msg:'أدخل المفتاح أولاً'}); return; }
    setTesting(true); setResult(null);
    const r = await testGroqConnection(key.trim(), model);
    setResult(r);
    if (r.ok) onToast({ icon:'✅', title:'Groq API يعمل!', body:'تم الاتصال بـ ' + model });
    setTesting(false);
  };

  const save = () => {
    onSave({ groqApiKey:key.trim(), aiModel:model });
    onClose();
  };

  return (
    <Modal visible animationType="slide" transparent onRequestClose={onClose}>
      <View style={ms.overlay}>
        <View style={[ms.sheet,{backgroundColor:t.card}]}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <Row style={ms.header}>
              <Text style={[ms.title,{color:t.text}]}>⚡ إعداد Groq API</Text>
              <TouchableOpacity onPress={onClose}><Text style={{fontSize:20,color:t.textSub}}>✕</Text></TouchableOpacity>
            </Row>

            {/* Elephant tip */}
            <Row style={ms.tipRow}>
              <Text style={{fontSize:48}}>🐘</Text>
              <View style={[ms.tipBubble,{backgroundColor:t.pLight,borderColor:dk?'#3D1F7A':'#DDD6FE'}]}>
                <Text style={[ms.tipTxt,{color:t.primary}]}>احصل على مفتاحك المجاني من <Text style={{fontWeight:'900'}}>console.groq.com</Text> — لا يحتاج بطاقة ائتمانية! 🎉</Text>
              </View>
            </Row>

            {/* Model picker */}
            <Text style={[ms.sectionLabel,{color:t.text}]}>اختر الموديل</Text>
            {GROQ_MODELS.map(m=>(
              <TouchableOpacity key={m.id} onPress={()=>setModel(m.id)}
                style={[ms.modelRow,{borderColor:model===m.id?'#7C3AED':t.border,backgroundColor:model===m.id?t.pLight:t.card}]}>
                <View style={[ms.radio,{borderColor:model===m.id?'#7C3AED':t.border,backgroundColor:model===m.id?'#7C3AED':'transparent'}]}>
                  {model===m.id && <View style={ms.radioDot}/>}
                </View>
                <View style={{flex:1}}>
                  <Text style={[ms.modelLabel,{color:t.text}]}>{m.label}{model===m.id?' ✓':''}</Text>
                  <Text style={[ms.modelDesc,{color:t.primary}]}>{m.desc}</Text>
                </View>
              </TouchableOpacity>
            ))}

            {/* API Key */}
            <Text style={[ms.sectionLabel,{color:t.text,marginTop:16}]}>مفتاح API</Text>
            <Row style={{gap:8,marginBottom:14}}>
              <Inp value={key} onChange={setKey} type={showKey?'text':'password'} placeholder="gsk_..." dk={dk} style={{flex:1}}/>
              <TouchableOpacity onPress={()=>setShowKey(v=>!v)}
                style={[ms.eyeBtn,{backgroundColor:t.pLight}]}>
                <Text style={{fontSize:18}}>👁</Text>
              </TouchableOpacity>
            </Row>

            {/* Security note */}
            <Row style={[ms.secRow,{backgroundColor:t.gLight,borderColor:t.green}]}>
              <Text style={{fontSize:16}}>🔒</Text>
              <Text style={[ms.secTxt,{color:t.textSub}]}>مفتاحك يُحفظ على جهازك فقط ولا يُرسَل لأي طرف ثالث.</Text>
            </Row>

            {result && (
              <View style={[ms.resultBox,{backgroundColor:result.ok?t.gLight:t.rLight,borderColor:result.ok?t.green:t.red}]}>
                <Text style={{color:result.ok?t.green:t.red,fontSize:13,fontWeight:'600'}}>{result.msg}</Text>
              </View>
            )}

            <Btn onPress={runTest} disabled={testing||!key.trim()} variant="ghost" full dk={dk} style={{marginBottom:10}}>
              {testing ? '⏳ جاري الاختبار...' : '📶 اختبر الاتصال'}
            </Btn>
            <Btn onPress={save} full size="lg">💾 حفظ الإعدادات</Btn>
            <View style={{height:24}}/>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

const ms = StyleSheet.create({
  overlay:    { flex:1, backgroundColor:'rgba(0,0,0,.58)', justifyContent:'flex-end' },
  sheet:      { borderTopLeftRadius:24, borderTopRightRadius:24, padding:20, maxHeight:'92%' },
  header:     { justifyContent:'space-between', marginBottom:18 },
  title:      { fontSize:20, fontWeight:'900' },
  tipRow:     { gap:12, alignItems:'flex-start', marginBottom:18 },
  tipBubble:  { flex:1, borderRadius:14, borderBottomLeftRadius:4, padding:12, borderWidth:1.5 },
  tipTxt:     { fontSize:13, fontWeight:'700', lineHeight:22 },
  sectionLabel:{ fontSize:14, fontWeight:'900', marginBottom:10 },
  modelRow:   { flexDirection:'row', alignItems:'center', gap:12, padding:11, borderRadius:12, borderWidth:1.5, marginBottom:8 },
  radio:      { width:18, height:18, borderRadius:9, borderWidth:2, alignItems:'center', justifyContent:'center' },
  radioDot:   { width:8, height:8, borderRadius:4, backgroundColor:'#fff' },
  modelLabel: { fontSize:13, fontWeight:'700' },
  modelDesc:  { fontSize:11 },
  eyeBtn:     { width:46, height:46, borderRadius:12, alignItems:'center', justifyContent:'center' },
  secRow:     { gap:8, padding:10, borderRadius:10, marginBottom:14, borderWidth:1 },
  secTxt:     { flex:1, fontSize:12, lineHeight:20 },
  resultBox:  { padding:10, borderRadius:10, marginBottom:12, borderWidth:1 },
});

// ── Settings Screen ───────────────────────────────────────────────────────────
export default function SettingsScreen({ state, dispatch, dk, onToast }) {
  const t = T(dk);
  const S = state.settings;
  const [name,    setName]    = useState(state.profile.name);
  const [saved,   setSaved]   = useState(false);
  const [showAI,  setShowAI]  = useState(false);
  const [perm,    setPerm]    = useState('default');

  useEffect(()=>{ getPermission().then(setPerm); },[]);

  const toggle = (key) => dispatch({ type:'SAVE_SETTINGS', settings:{ [key]:!S[key] } });

  const saveProfile = () => {
    dispatch({ type:'SAVE_PROFILE', profile:{ name } });
    setSaved(true); setTimeout(()=>setSaved(false), 2000);
  };

  const saveNotifSettings = async (updates) => {
    const merged = { ...S, ...updates };
    dispatch({ type:'SAVE_SETTINGS', settings:updates });
    if (merged.notifEnabled) {
      await scheduleDaily(true, merged.notifTime, merged.notifMessage, merged.notifCustom, state.profile);
    }
  };

  const enableNotifs = async () => {
    const p = await requestPermission();
    setPerm(p);
    if (p === 'granted') {
      dispatch({ type:'SAVE_SETTINGS', settings:{ notifEnabled:true } });
      await scheduleDaily(true, S.notifTime, S.notifMessage, S.notifCustom, state.profile);
    } else {
      Alert.alert('الإشعارات محجوبة','يرجى السماح بالإشعارات من إعدادات الجهاز.');
    }
  };

  const disableNotifs = async () => {
    dispatch({ type:'SAVE_SETTINGS', settings:{ notifEnabled:false } });
    await cancelAll();
  };

  const testNotif = () => sendNow(`مرحباً ${state.profile.name}! 🐘`,
    (NOTIF_MESSAGES.find(m=>m.id===S.notifMessage)||NOTIF_MESSAGES[0]).text);

  const groqLabel = GROQ_MODELS.find(m=>m.id===S.aiModel)?.label || S.aiModel;

  const SectionHeader = ({children}) => (
    <Text style={[s.sectionHeader,{color:t.textMuted}]}>{children}</Text>
  );

  return (
    <ScrollView style={[s.container,{backgroundColor:t.bg}]} contentContainerStyle={s.content}>
      <Text style={[s.pageTitle,{color:t.text}]}>⚙️ الإعدادات</Text>

      {/* Profile */}
      <SectionHeader>👤 الملف الشخصي</SectionHeader>
      <Card dk={dk} style={s.card}>
        <Text style={[s.label,{color:t.textMuted}]}>الاسم</Text>
        <Inp value={name} onChange={setName} placeholder="اسمك" dk={dk} style={{marginBottom:10}}/>
        <Btn onPress={saveProfile} full variant={saved?'green':'primary'}>
          {saved ? '✅ تم الحفظ!' : '💾 حفظ الاسم'}
        </Btn>
      </Card>

      {/* Appearance */}
      <SectionHeader>🎨 المظهر</SectionHeader>
      <Card dk={dk} style={s.card}>
        <Row style={s.settingRow}>
          <Row style={{gap:10,flex:1}}>
            <View style={[s.settingIcon,{backgroundColor:dk?'#2D2D48':'#FFF7ED'}]}>
              <Text style={{fontSize:20}}>{dk?'🌙':'☀️'}</Text>
            </View>
            <View>
              <Text style={[s.settingLabel,{color:t.text}]}>الوضع {dk?'المظلم':'الفاتح'}</Text>
              <Text style={[s.settingSub,{color:t.textSub}]}>اضغط لتبديل المظهر</Text>
            </View>
          </Row>
          <Toggle value={dk} onChange={()=>toggle('darkMode')}/>
        </Row>
      </Card>

      {/* Language */}
      <SectionHeader>🌍 لغة التعلم</SectionHeader>
      <Card dk={dk} style={s.card}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={{flexDirection:'row',gap:8}}>
            {LANGUAGES.map(l=>(
              <TouchableOpacity key={l.code}
                onPress={()=>dispatch({type:'SAVE_PROFILE',profile:{language:l.code}})}
                style={[s.langChip, state.profile.language===l.code && s.langChipActive, {borderColor:state.profile.language===l.code?'#7C3AED':t.border,backgroundColor:state.profile.language===l.code?t.pLight:t.cardAlt}]}>
                <Text style={{fontSize:20}}>{l.flag}</Text>
                <Text style={[s.langTxt,{color:state.profile.language===l.code?t.primary:t.textMuted}]}>{l.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </Card>

      {/* Notifications */}
      <SectionHeader>🔔 نظام الإشعارات</SectionHeader>
      <Card dk={dk} style={s.card}>
        {/* Permission status */}
        <View style={[s.permRow,{
          backgroundColor:perm==='granted'?t.gLight:perm==='denied'?t.rLight:t.goLight,
          borderColor:(perm==='granted'?t.green:perm==='denied'?t.red:t.gold)+'30',
        }]}>
          <Text style={{fontSize:18}}>{perm==='granted'?'✅':perm==='denied'?'❌':'⏳'}</Text>
          <Text style={[s.permTxt,{color:perm==='granted'?t.green:perm==='denied'?t.red:t.gold}]}>
            {perm==='granted'?'الإشعارات مسموح بها':perm==='denied'?'الإشعارات محجوبة':' في انتظار الإذن'}
          </Text>
        </View>

        {/* Enable toggle */}
        <Row style={[s.settingRow,{marginBottom:S.notifEnabled?16:0}]}>
          <Row style={{gap:10,flex:1}}>
            <View style={[s.settingIcon,{backgroundColor:t.pLight}]}>
              <Text style={{fontSize:20}}>🔔</Text>
            </View>
            <View>
              <Text style={[s.settingLabel,{color:t.text}]}>تذكير يومي</Text>
              <Text style={[s.settingSub,{color:t.textSub}]}>{S.notifEnabled?'مفعّل':'معطّل'}</Text>
            </View>
          </Row>
          <Toggle value={S.notifEnabled} onChange={v=>v?enableNotifs():disableNotifs()}/>
        </Row>

        {S.notifEnabled && (
          <View style={{borderTopWidth:1,borderTopColor:t.border,paddingTop:14,gap:14}}>
            {/* Time */}
            <Row style={{justifyContent:'space-between'}}>
              <Row style={{gap:8}}>
                <Text style={{fontSize:18}}>🕐</Text>
                <Text style={[s.settingLabel,{color:t.text}]}>وقت التذكير</Text>
              </Row>
              <TextInput
                value={S.notifTime}
                onChangeText={v=>saveNotifSettings({notifTime:v})}
                placeholder="20:00"
                keyboardType="numbers-and-punctuation"
                style={[s.timeInput,{borderColor:t.border,backgroundColor:t.card,color:t.text}]}
              />
            </Row>

            {/* Message template */}
            <Text style={[s.settingLabel,{color:t.text}]}>💬 نوع الرسالة</Text>
            {NOTIF_MESSAGES.map(m=>(
              <TouchableOpacity key={m.id} onPress={()=>saveNotifSettings({notifMessage:m.id})}
                style={[s.notifMsgRow,{borderColor:S.notifMessage===m.id?'#7C3AED':t.border,backgroundColor:S.notifMessage===m.id?t.pLight:t.cardAlt}]}>
                <View style={[s.radio2,{borderColor:S.notifMessage===m.id?'#7C3AED':t.border,backgroundColor:S.notifMessage===m.id?'#7C3AED':'transparent'}]}>
                  {S.notifMessage===m.id && <View style={ms.radioDot}/>}
                </View>
                <View style={{flex:1}}>
                  <Row style={{gap:6,marginBottom:2}}>
                    <Text style={{fontSize:16}}>{m.icon}</Text>
                    <Text style={[{fontWeight:'700',fontSize:13,color:t.text}]}>
                      {m.id==='custom'?'رسالة مخصصة':m.text.slice(0,30)+'...'}
                    </Text>
                  </Row>
                  {m.id==='custom' && S.notifMessage==='custom' && (
                    <TextInput
                      value={S.notifCustom}
                      onChangeText={v=>saveNotifSettings({notifCustom:v})}
                      placeholder="اكتب رسالتك المخصصة..."
                      placeholderTextColor={t.textMuted}
                      style={[s.customInput,{borderColor:t.border,backgroundColor:t.card,color:t.text}]}
                    />
                  )}
                </View>
              </TouchableOpacity>
            ))}

            {/* Preview */}
            <View style={[s.previewBox,{backgroundColor:t.cardAlt,borderColor:t.border}]}>
              <Text style={[{fontWeight:'700',fontSize:12,color:t.textMuted,marginBottom:6}]}>معاينة الإشعار:</Text>
              <Row style={{gap:10}}>
                <Text style={{fontSize:22}}>🐘</Text>
                <View style={{flex:1}}>
                  <Text style={[{fontWeight:'800',fontSize:13,color:t.text}]}>مرحباً {state.profile.name}!</Text>
                  <Text style={[{fontSize:12,color:t.textSub,marginTop:2,lineHeight:18}]}>
                    {S.notifMessage==='custom'&&S.notifCustom ? S.notifCustom : (NOTIF_MESSAGES.find(m=>m.id===S.notifMessage)||NOTIF_MESSAGES[0]).text}
                  </Text>
                </View>
              </Row>
            </View>

            {perm==='granted' && (
              <Btn onPress={testNotif} variant="ghost" full size="sm" dk={dk}>🧪 إرسال إشعار تجريبي الآن</Btn>
            )}
          </View>
        )}
      </Card>

      {/* AI */}
      <SectionHeader>🤖 الذكاء الاصطناعي — Groq</SectionHeader>
      <Card dk={dk} style={s.card} onPress={()=>setShowAI(true)}>
        <Row style={{justifyContent:'space-between',alignItems:'center'}}>
          <Row style={{gap:10}}>
            <View style={[s.settingIcon,{backgroundColor:t.pLight}]}><Text style={{fontSize:20}}>⚡</Text></View>
            <View>
              <Text style={[s.settingLabel,{color:t.text}]}>Groq API</Text>
              <Text style={[s.settingSub,{color:S.groqApiKey?t.green:t.red}]}>
                {S.groqApiKey ? '🟢 مفتاح مُضاف — '+groqLabel : '🔴 يحتاج مفتاح API'}
              </Text>
            </View>
          </Row>
          <Text style={{color:t.textMuted,fontSize:18}}>›</Text>
        </Row>
      </Card>

      {/* About */}
      <Card dk={dk} style={[s.card,{alignItems:'center',marginTop:4}]}>
        <Text style={{fontSize:42}}>🐘</Text>
        <Text style={[{fontWeight:'900',fontSize:18,color:t.text,marginTop:8,marginBottom:2}]}>Nader</Text>
        <Text style={[{color:t.textMuted,fontSize:12}]}>تعلّم المفردات بذكاء — v4.0</Text>
      </Card>

      <View style={{height:32}}/>

      {showAI && (
        <GroqModal
          settings={S} dk={dk}
          onClose={()=>setShowAI(false)}
          onSave={s=>dispatch({type:'SAVE_SETTINGS',settings:s})}
          onToast={onToast}
        />
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:     { flex:1 },
  content:       { padding:16 },
  pageTitle:     { fontSize:22, fontWeight:'900', marginBottom:18 },
  sectionHeader: { fontSize:12, fontWeight:'700', textTransform:'uppercase', letterSpacing:1, marginBottom:8, marginTop:4 },
  card:          { marginBottom:14 },
  label:         { fontSize:12, fontWeight:'700', textTransform:'uppercase', letterSpacing:1, marginBottom:6 },
  settingRow:    { justifyContent:'space-between', alignItems:'center' },
  settingIcon:   { width:40, height:40, borderRadius:10, alignItems:'center', justifyContent:'center' },
  settingLabel:  { fontSize:14, fontWeight:'700' },
  settingSub:    { fontSize:12, marginTop:1 },
  langChip:      { alignItems:'center', gap:4, paddingVertical:8, paddingHorizontal:12, borderRadius:12, borderWidth:2 },
  langTxt:       { fontSize:12, fontWeight:'700' },
  permRow:       { flexDirection:'row', alignItems:'center', gap:10, padding:10, borderRadius:12, marginBottom:12, borderWidth:1 },
  permTxt:       { fontSize:13, fontWeight:'700' },
  timeInput:     { borderWidth:2, borderRadius:10, paddingHorizontal:10, paddingVertical:6, fontSize:15, fontWeight:'700', width:80, textAlign:'center' },
  notifMsgRow:   { flexDirection:'row', alignItems:'flex-start', gap:10, padding:10, borderRadius:12, borderWidth:1.5, marginBottom:6 },
  radio2:        { width:18, height:18, borderRadius:9, borderWidth:2, alignItems:'center', justifyContent:'center', marginTop:1, flexShrink:0 },
  customInput:   { marginTop:6, padding:8, borderRadius:8, borderWidth:1.5, fontSize:13 },
  previewBox:    { borderRadius:12, padding:12, borderWidth:1 },
});
