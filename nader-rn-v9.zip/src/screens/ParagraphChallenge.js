import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Share } from 'react-native';
import { T } from '../theme';
import { todayStr } from '../state';
import { aiEvaluateParagraph, callAI } from '../services/ai';
import { Card, Btn, Inp, Spinner } from '../components';
import { t, isRTL } from '../i18n';
import { playSound } from '../services/SoundService';

const aiImproveVersion = async (paragraph, words, lang, settings) => {
  const raw = await callAI(settings, [{role:'user', content:
    `You are a professional \${lang} writing coach.\\n`+
    `Here is a student's paragraph that uses these vocabulary words: \${words.join(', ')}\\n\\n`+
    `Student's paragraph:\\n"\${paragraph}"\\n\\n`+
    `Please rewrite this paragraph to make it more natural, fluent, and native-like, `+
    `while keeping ALL the same vocabulary words and the same general meaning/story.\\n`+
    `Return ONLY the improved paragraph text — no explanation, no JSON, no extra text.`
  }]);
  return raw.trim();
};

export default function ParagraphChallenge({ session, state, dispatch, onComplete, dk }) {
  const t_ = (k) => t(k);
  const T_  = T(dk);
  const rtl = isRTL();

  const [text,      setText]      = useState('');
  const [loading,   setLoading]   = useState(false);
  const [result,    setResult]    = useState(null);
  const [noteSaved, setNoteSaved] = useState(false);

  // Improved version state
  const [improving,        setImproving]        = useState(false);
  const [improvedText,     setImprovedText]      = useState('');
  const [showImproved,     setShowImproved]      = useState(false);
  const [copiedImproved,   setCopiedImproved]    = useState(false);

  const minWords = Math.min(4, session.length);
  const used     = session.filter(w => text.toLowerCase().includes(w.word.toLowerCase()));
  const passed   = result && result.score >= 5;

  const evaluate = async () => {
    setLoading(true);
    try {
      const r = await aiEvaluateParagraph(text, session.map(w=>w.word), state.profile.language, state.settings);
      setResult(r);
    } catch {
      setResult({ score:6, feedback: t_('needFive'), corrections:[], encouragement:'🎉' });
    }
    setLoading(false);
  };

  const getImprovedVersion = async () => {
    if (!state.settings.groqApiKey) { Alert.alert('', t_('noApiKey')); return; }
    setImproving(true);
    try {
      const improved = await aiImproveVersion(text, session.map(w=>w.word), state.profile.language, state.settings);
      setImprovedText(improved);
      setShowImproved(true);
    } catch (e) {
      Alert.alert('خطأ', e.message);
    }
    setImproving(false);
  };

  const copyImproved = () => {
    Share.share({ message: improvedText });
    setCopiedImproved(true);
    setTimeout(() => setCopiedImproved(false), 2000);
  };

  const saveNote = () => {
    dispatch({ type:'SAVE_NOTE', note:{
      date: todayStr(), paragraph: text, score: result.score,
      feedback: result.feedback, corrections: result.corrections||[],
      words: session.map(w=>w.word),
    }});
    setNoteSaved(true);
  };

  const finish = async () => { await playSound("completed"); dispatch({ type:'COMPLETE_SESSION' }); onComplete(); };

  const needMore  = minWords - used.length;
  const btnLabel  = loading     ? t_('evaluating')
    : needMore > 0 ? `\${t_('addMoreWords')} (\${needMore})`
    : t_('evaluateParagraph');

  const textAlign = rtl ? 'right' : 'left';

  return (
    <ScrollView style={[s.container,{backgroundColor:T_.bg}]} keyboardShouldPersistTaps="handled" contentContainerStyle={s.content}>

      {/* Header */}
      <View style={s.headerArea}>
        <Text style={s.bossEmoji}>⚔️</Text>
        <Text style={[s.title,{color:T_.text}]}>{t_('paragraphChallenge')}</Text>
        <Text style={[s.sub,{color:T_.textSub}]}>
          {session.length<=4 ? t_('useAllWords') : t_('useFourWords')}
        </Text>
      </View>

      {/* Word chips */}
      <View style={s.chips}>
        {session.map(w=>{
          const isUsed = text.toLowerCase().includes(w.word.toLowerCase());
          return (
            <View key={w.id} style={[s.chip, isUsed && s.chipUsed]}>
              <Text style={[s.chipTxt, isUsed && s.chipTxtUsed]}>{isUsed?'✓ ':''}{w.word}</Text>
            </View>
          );
        })}
      </View>

      {/* Text area */}
      <Card dk={dk} style={s.inputCard}>
        <Inp value={text} onChange={setText} rows={5} dk={dk}
          placeholder={rtl ? 'اكتب فقرتك... القصص الخيالية مقبولة 🐉' : 'Write your paragraph... creative stories are fine 🐉'}
          style={{marginBottom:8, textAlign:rtl?'right':'left'}}
        />
        <View style={[s.statsRow, {flexDirection: rtl?'row-reverse':'row'}]}>
          <Text style={[s.statTxt,{color:T_.textMuted}]}>{t_('used')}: {used.length}/{minWords}</Text>
          <Text style={[s.statTxt,{color:T_.textMuted}]}>{text.trim().split(/\\s+/).filter(Boolean).length} {t_('wordCount')}</Text>
        </View>
      </Card>

      {/* Evaluate button */}
      {!passed && (
        <Btn onPress={evaluate} disabled={loading||used.length<minWords} full style={{marginBottom:12}}>
          {btnLabel}
        </Btn>
      )}

      {loading && <Spinner message={rtl ? 'الفيل يقيّم القواعد النحوية... 🤓' : 'Evaluating your writing... 🤓'} dk={dk}/>}

      {/* Result */}
      {result && (
        <Card dk={dk} style={[s.resultCard, passed
          ? {backgroundColor:T_.gLight, borderColor:T_.green}
          : {backgroundColor:T_.rLight, borderColor:T_.red}]}>
          <View style={s.resultTop}>
            <Text style={{fontSize:52}}>{passed?'🏆':'💪'}</Text>
            <Text style={[s.score,{color:passed?T_.green:T_.red}]}>{result.score}
              <Text style={[s.scoreOf,{color:T_.textMuted}]}>/10</Text>
            </Text>
            <Text style={[s.feedback,{color:T_.text, textAlign:'center'}]}>{result.feedback}</Text>
            <Text style={[{fontSize:14,textAlign:'center',fontWeight:'700',color:passed?T_.green:T_.red}]}>{result.encouragement}</Text>
          </View>

          {(result.corrections||[]).length>0 && (
            <View style={[s.corrections,{backgroundColor:'rgba(255,255,255,.55)'}]}>
              <Text style={[s.correctionsTitle,{color:T_.text, textAlign:textAlign}]}>{t_('corrections')}</Text>
              {result.corrections.map((c,i)=>(
                <Text key={i} style={[{color:T_.textSub,fontSize:13,marginTop:4,lineHeight:20,textAlign:textAlign}]}>• {c}</Text>
              ))}
            </View>
          )}

          {(result.corrections||[]).length>0 && (
            <Btn onPress={noteSaved?undefined:saveNote} variant={noteSaved?'green':'white'} full size="sm" dk={dk} style={{marginTop:8}}>
              {noteSaved ? t_('saved_') : t_('saveCorrections')}
            </Btn>
          )}
        </Card>
      )}

      {/* ── IMPROVED VERSION (Fix #5) ─────────────────────────────────────── */}
      {result && (
        <View style={s.improveSection}>
          <Btn
            onPress={showImproved ? undefined : getImprovedVersion}
            disabled={improving}
            variant={showImproved ? 'green' : 'ghost'}
            full dk={dk}
          >
            {improving ? t_('improving') : showImproved ? t_('improvedVersion') : t_('improveBtn')}
          </Btn>

          {improving && <Spinner message={rtl ? 'الفيل يكتب نسخة محسّنة... ✍️' : 'Writing improved version... ✍️'} dk={dk} style={{marginTop:12}}/>}

          {showImproved && improvedText ? (
            <Card dk={dk} style={[s.improvedCard, {borderColor:T_.green, backgroundColor:T_.gLight}]}>
              <View style={[s.improvedHeader, {flexDirection:rtl?'row-reverse':'row'}]}>
                <Text style={[s.improvedLabel, {color:T_.green}]}>✨ {t_('improvedLabel')}</Text>
                <TouchableOpacity onPress={copyImproved}
                  style={[s.copyBtn, {backgroundColor: copiedImproved ? T_.green : T_.primary}]}>
                  <Text style={s.copyBtnTxt}>{copiedImproved ? t_('usedImproved') : t_('copyImproved')}</Text>
                </TouchableOpacity>
              </View>
              <Text style={[s.improvedText, {color:T_.text, textAlign:textAlign}]}>{improvedText}</Text>

              {/* Show diff of vocabulary words */}
              <View style={[s.chips, {marginTop:10}]}>
                {session.map(w=>{
                  const inImproved = improvedText.toLowerCase().includes(w.word.toLowerCase());
                  return (
                    <View key={w.id} style={[s.chip, inImproved && s.chipUsed]}>
                      <Text style={[s.chipTxt, inImproved && s.chipTxtUsed]}>{inImproved?'✓ ':''}{w.word}</Text>
                    </View>
                  );
                })}
              </View>
            </Card>
          ) : null}
        </View>
      )}

      {/* End session / retry */}
      {passed
        ? <Btn onPress={finish} full size="lg" variant="gold" style={{marginTop:12}}>{t_('endSession')}</Btn>
        : result && !passed && (
          <Text style={[s.retryHint,{color:T_.textMuted, textAlign:'center'}]}>{t_('needFive')}</Text>
        )
      }

      <View style={{height:32}}/>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container:        {flex:1},
  content:          {padding:20},
  headerArea:       {alignItems:'center',marginBottom:18},
  bossEmoji:        {fontSize:52,marginBottom:8},
  title:            {fontSize:22,fontWeight:'900',textAlign:'center'},
  sub:              {fontSize:13,textAlign:'center',marginTop:4},
  chips:            {flexDirection:'row',flexWrap:'wrap',gap:8,marginBottom:14},
  chip:             {paddingVertical:5,paddingHorizontal:13,borderRadius:20,backgroundColor:'#E8E4F8'},
  chipUsed:         {backgroundColor:'#7C3AED'},
  chipTxt:          {fontSize:13,fontWeight:'700',color:'#9999BB'},
  chipTxtUsed:      {color:'#fff'},
  inputCard:        {marginBottom:12},
  statsRow:         {justifyContent:'space-between'},
  statTxt:          {fontSize:12},
  resultCard:       {borderWidth:2,marginBottom:14},
  resultTop:        {alignItems:'center',marginBottom:14,gap:6},
  score:            {fontSize:36,fontWeight:'900'},
  scoreOf:          {fontSize:18,fontWeight:'600'},
  feedback:         {fontSize:15,marginTop:4},
  corrections:      {borderRadius:12,padding:12,marginBottom:12},
  correctionsTitle: {fontSize:13,fontWeight:'800',marginBottom:4},
  retryHint:        {fontSize:13,marginTop:12},
  // Improved version
  improveSection:   {gap:12,marginBottom:14},
  improvedCard:     {borderWidth:2,marginTop:4},
  improvedHeader:   {justifyContent:'space-between',alignItems:'center',marginBottom:10,gap:8},
  improvedLabel:    {fontSize:13,fontWeight:'800',flex:1},
  copyBtn:          {paddingHorizontal:12,paddingVertical:6,borderRadius:20},
  copyBtnTxt:       {color:'#fff',fontWeight:'700',fontSize:12},
  improvedText:     {fontSize:14,lineHeight:22,fontStyle:'italic'},
});
