import React, { useState } from 'react';
import {
  View, Text, Image, ScrollView, TouchableOpacity,
  StyleSheet, Alert, TextInput, Modal,
} from 'react-native';
import * as Speech from 'expo-speech';
import { T } from '../theme';
import { getStatus, statusColors, statusLabel, getImageUrl } from '../state';
import { Card, Btn, Inp, Badge, SpeakBtn, Row } from '../components';
import SmartImage from '../components/SmartImage';

// ── Word Detail Modal ─────────────────────────────────────────────────────────
const WordModal = ({ word, onClose, onUpdate, onDelete, dk }) => {
  const t = T(dk);
  const [editing, setEditing] = useState(false);
  const [def, setDef]   = useState(word.definition || '');
  const [ex, setEx]     = useState([...(word.examples || ['', ''])]);
  const [imgUrl, setImgUrl] = useState(word.imageUrl || '');
  const status = getStatus(word);

  const regenImg = () => setImgUrl(getImageUrl(word.word)));
  const save = () => { onUpdate({ ...word, definition:def, examples:ex, imageUrl:imgUrl }); setEditing(false); };

  return (
    <Modal visible animationType="slide" transparent onRequestClose={onClose}>
      <View style={s.modalOverlay}>
        <View style={[s.modalSheet, { backgroundColor:t.card }]}>
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Top bar */}
            <Row style={s.modalTopBar}>
              <TouchableOpacity onPress={onClose}><Text style={[s.modalClose,{color:t.textSub}]}>✕</Text></TouchableOpacity>
              <Text style={[s.modalWordTitle,{color:t.text}]}>{word.word}</Text>
              <Row style={{gap:12}}>
                <TouchableOpacity onPress={()=>setEditing(e=>!e)}><Text style={{fontSize:18,color:t.primary}}>✏️</Text></TouchableOpacity>
                <TouchableOpacity onPress={()=>Alert.alert('حذف الكلمة؟','',[ {text:'إلغاء',style:'cancel'}, {text:'حذف',style:'destructive',onPress:()=>{onDelete(word.id);onClose();}} ])}><Text style={{fontSize:18}}>🗑️</Text></TouchableOpacity>
              </Row>
            </Row>

            {/* Image */}
            {imgUrl ? <SmartImage src={imgUrl} word={word.word} style={s.modalImg}/> : null}

            {/* Word + badge */}
            <Row style={s.modalWordRow}>
              <View style={{flex:1}}>
                <Text style={[s.modalWord,{color:t.text}]}>{word.word}</Text>
                <Badge status={status} dk={dk}/>
              </View>
              <SpeakBtn onPress={()=>Speech.speak(word.word,{language:word.language})} dk={dk} size={22}/>
            </Row>

            {/* Stats mini-row */}
            <Row style={{gap:8,marginBottom:16}}>
              {[{l:'مراجعة',v:(word.correctStreak||0)+(word.incorrectStreak||0)},{l:'صحيحة',v:word.correctStreak||0},{l:'الصعوبة',v:word.difficulty||'—'}].map(stat=>(
                <View key={stat.l} style={[s.miniStat,{backgroundColor:t.cardAlt,borderColor:t.border}]}>
                  <Text style={[s.miniStatVal,{color:t.primary}]}>{stat.v}</Text>
                  <Text style={[s.miniStatLbl,{color:t.textMuted}]}>{stat.l}</Text>
                </View>
              ))}
            </Row>

            {/* Definition */}
            <Row style={s.fieldHeader}>
              <Text style={[s.fieldLabel,{color:t.primary}]}>التعريف</Text>
              <SpeakBtn onPress={()=>Speech.speak(def,{language:word.language})} dk={dk}/>
            </Row>
            {editing
              ? <Inp value={def} onChange={setDef} rows={3} dk={dk} style={{marginBottom:14}}/>
              : <View style={[s.fieldBox,{backgroundColor:t.cardAlt,borderColor:t.border}]}>
                  <Text style={[s.fieldText,{color:t.text}]}>{def}</Text>
                </View>
            }

            {/* Examples */}
            <Text style={[s.fieldLabel,{color:t.primary,marginBottom:8}]}>الأمثلة</Text>
            {ex.map((e,i)=>(
              <View key={i} style={{marginBottom:8}}>
                {editing
                  ? <Inp value={e} onChange={v=>{const n=[...ex];n[i]=v;setEx(n);}} dk={dk}/>
                  : <Row style={[s.fieldBox,{backgroundColor:t.cardAlt,borderColor:t.border}]}>
                      <Text style={[s.fieldText,{color:t.text,flex:1}]}>{e}</Text>
                      <SpeakBtn onPress={()=>Speech.speak(e,{language:word.language})} dk={dk}/>
                    </Row>
                }
              </View>
            ))}

            {/* Image edit */}
            {editing && (
              <View style={{marginBottom:14}}>
                <Text style={[s.fieldLabel,{color:t.primary,marginBottom:8}]}>الصورة</Text>
                {imgUrl ? <Image source={{uri:imgUrl}} style={{width:'100%',height:110,borderRadius:12,marginBottom:10}} resizeMode="cover"/> : null}
                <Btn onPress={regenImg} variant="ghost" dk={dk} style={{fontSize:13}}>🔄 توليد صورة جديدة</Btn>
              </View>
            )}

            {/* Next review */}
            {word.nextReview && (
              <Row style={[s.nextReviewBox,{backgroundColor:t.cardAlt,borderColor:t.border}]}>
                <Text style={{fontSize:16}}>🕐</Text>
                <Text style={[s.nextReviewTxt,{color:t.textSub}]}>المراجعة القادمة: {word.nextReview}</Text>
              </Row>
            )}

            {/* Save / Cancel */}
            {editing && (
              <Row style={{gap:10,marginTop:4}}>
                <Btn onPress={()=>setEditing(false)} variant="white" full dk={dk}>إلغاء</Btn>
                <Btn onPress={save} full>💾 حفظ</Btn>
              </Row>
            )}
            <View style={{height:24}}/>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};

// ── Words Screen ──────────────────────────────────────────────────────────────
export default function WordsScreen({ state, dispatch, dk }) {
  const t = T(dk);
  const [view,   setView]   = useState('words'); // 'words' | 'notes'
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState(null);
  const { words, notes = [] } = state;

  const counts = {
    mastered: words.filter(w=>w.mastered).length,
    hard:     words.filter(w=>w.hard).length,
    learning: words.filter(w=>!w.mastered&&!w.hard&&w.correctStreak>0).length,
    new:      words.filter(w=>!w.mastered&&!w.hard&&!w.correctStreak).length,
  };

  const filtered = words.filter(w =>
    (!search || w.word.toLowerCase().includes(search.toLowerCase())) &&
    (filter === 'all' || getStatus(w) === filter)
  );

  const updateWord  = (w) => dispatch({ type:'UPDATE_WORD', word:w });
  const deleteWord  = (id) => dispatch({ type:'DELETE_WORD', id });
  const deleteNote  = (i) => dispatch({ type:'DELETE_NOTE', index:i });

  return (
    <View style={[s.container,{backgroundColor:t.bg}]}>
      {/* View toggle */}
      <View style={[s.tabBar,{backgroundColor:t.card,borderBottomColor:t.border}]}>
        {[{id:'words',l:'📝 كلماتي'},{id:'notes',l:'📓 ملاحظاتي'}].map(tb=>(
          <TouchableOpacity key={tb.id} onPress={()=>setView(tb.id)} style={[s.tab, view===tb.id && s.tabActive]}>
            <Text style={[s.tabTxt,{color:view===tb.id?t.primary:t.textMuted}]}>{tb.l}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {view === 'words' ? (
        <ScrollView contentContainerStyle={s.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {/* Search */}
          <View style={[s.searchBox,{backgroundColor:t.card,borderColor:t.border}]}>
            <Text style={{fontSize:16,marginRight:8}}>🔍</Text>
            <TextInput
              value={search} onChangeText={setSearch}
              placeholder="ابحث عن كلمة..."
              placeholderTextColor={t.textMuted}
              style={[s.searchInput,{color:t.text}]}
            />
          </View>

          {/* Filter chips */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:12}}>
            <View style={{flexDirection:'row',gap:8,paddingHorizontal:2}}>
              {[
                {id:'all',      l:`الكل (\${words.length})`},
                {id:'mastered', l:`متقنة (\${counts.mastered})`},
                {id:'hard',     l:`صعبة (\${counts.hard})`},
                {id:'learning', l:`تعلم (\${counts.learning})`},
                {id:'new',      l:`جديدة (\${counts.new})`},
              ].map(f=>(
                <TouchableOpacity key={f.id} onPress={()=>setFilter(f.id)}
                  style={[s.filterChip, filter===f.id && s.filterChipActive, {borderColor:filter===f.id?t.primary:t.border, backgroundColor:filter===f.id?t.pLight:t.card}]}>
                  <Text style={[s.filterChipTxt,{color:filter===f.id?t.primary:t.textMuted}]}>{f.l}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>

          {/* Word list */}
          {filtered.length === 0 ? (
            <View style={s.emptyArea}>
              <Text style={{fontSize:48,marginBottom:12}}>📭</Text>
              <Text style={[{color:t.textMuted,fontSize:14,textAlign:'center'}]}>لا كلمات هنا</Text>
            </View>
          ) : (
            filtered.map(word => {
              const status = getStatus(word);
              const sc = statusColors(status, dk);
              return (
                <TouchableOpacity key={word.id} onPress={()=>setSelected(word)} activeOpacity={0.85}>
                  <Card dk={dk} style={s.wordRow}>
                    {word.imageUrl ? (
                      <SmartImage src={word.imageUrl} word={word.word} style={s.wordThumb}/>
                    ) : (
                      <View style={[s.wordThumbPlaceholder,{backgroundColor:sc.bg}]}>
                        <Text style={{fontSize:20}}>{word.word[0]?.toUpperCase()}</Text>
                      </View>
                    )}
                    <View style={{flex:1,gap:4}}>
                      <Row style={{justifyContent:'space-between'}}>
                        <Text style={[s.wordName,{color:t.text}]}>{word.word}</Text>
                        <Badge status={status} dk={dk}/>
                      </Row>
                      <Text style={[s.wordDef,{color:t.textSub}]} numberOfLines={1}>{word.definition}</Text>
                      {word.nextReview && (
                        <Text style={[s.wordNext,{color:t.textMuted}]}>📅 {word.nextReview}</Text>
                      )}
                    </View>
                  </Card>
                </TouchableOpacity>
              );
            })
          )}
        </ScrollView>
      ) : (
        // Notes view
        <ScrollView contentContainerStyle={s.content}>
          {notes.length === 0 ? (
            <View style={s.emptyArea}>
              <Text style={{fontSize:56,marginBottom:12}}>📭</Text>
              <Text style={[{color:t.textMuted,fontSize:14,textAlign:'center'}]}>لا ملاحظات بعد</Text>
              <Text style={[{color:t.textMuted,fontSize:12,textAlign:'center',marginTop:6,lineHeight:20}]}>
                ستظهر هنا تصحيحات الفقرة التي تحفظها بعد كل جلسة مراجعة
              </Text>
            </View>
          ) : (
            [...notes].reverse().map((note, i) => {
              const realIdx = notes.length - 1 - i;
              return (
                <Card key={i} dk={dk} style={[s.noteCard, {borderLeftColor: note.score>=5 ? t.green : t.red}]}>
                  <Row style={s.noteHeader}>
                    <Text style={[s.noteDate,{color:t.textMuted}]}>{note.date}</Text>
                    <Row style={{gap:8,alignItems:'center'}}>
                      <View style={[s.noteScore,{backgroundColor:note.score>=5?t.gLight:t.rLight}]}>
                        <Text style={[s.noteScoreTxt,{color:note.score>=5?t.green:t.red}]}>{note.score}/10</Text>
                      </View>
                      <TouchableOpacity onPress={()=>Alert.alert('حذف الملاحظة؟','',[ {text:'إلغاء',style:'cancel'}, {text:'حذف',style:'destructive',onPress:()=>deleteNote(realIdx)} ])}>
                        <Text style={{fontSize:16,color:t.red}}>🗑️</Text>
                      </TouchableOpacity>
                    </Row>
                  </Row>
                  <View style={[s.wordChips,{marginBottom:8}]}>
                    {(note.words||[]).map((w,wi)=>(
                      <View key={wi} style={[s.noteChip,{backgroundColor:t.pLight}]}>
                        <Text style={[s.noteChipTxt,{color:t.primary}]}>{w}</Text>
                      </View>
                    ))}
                  </View>
                  <Text style={[s.noteParagraph,{color:t.textSub}]}>{note.paragraph}</Text>
                  {(note.corrections||[]).length>0 && (
                    <View style={[s.noteCorrections,{backgroundColor:t.cardAlt,borderColor:t.border}]}>
                      <Text style={[s.noteCorrectionsTitle,{color:t.text}]}>📝 التصحيحات:</Text>
                      {note.corrections.map((c,ci)=>(
                        <Text key={ci} style={[{color:t.textSub,fontSize:13,marginTop:4}]}>• {c}</Text>
                      ))}
                    </View>
                  )}
                </Card>
              );
            })
          )}
        </ScrollView>
      )}

      {/* Word detail modal */}
      {selected && (
        <WordModal
          word={selected}
          dk={dk}
          onClose={()=>setSelected(null)}
          onUpdate={(w)=>{ updateWord(w); setSelected(w); }}
          onDelete={(id)=>{ deleteWord(id); setSelected(null); }}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  container:    { flex:1 },
  tabBar:       { flexDirection:'row', borderBottomWidth:1, paddingTop:52 },
  tab:          { flex:1, paddingVertical:12, alignItems:'center' },
  tabActive:    { borderBottomWidth:2, borderBottomColor:'#7C3AED' },
  tabTxt:       { fontSize:14, fontWeight:'700' },
  content:      { padding:16, paddingBottom:32 },
  searchBox:    { flexDirection:'row', alignItems:'center', borderRadius:12, borderWidth:1.5, paddingHorizontal:12, paddingVertical:10, marginBottom:12 },
  searchInput:  { flex:1, fontSize:15, fontWeight:'500' },
  filterChip:   { paddingVertical:6, paddingHorizontal:12, borderRadius:20, borderWidth:1.5 },
  filterChipActive:{},
  filterChipTxt:{ fontSize:12, fontWeight:'700' },
  wordRow:      { flexDirection:'row', gap:12, alignItems:'center', marginBottom:8, padding:12 },
  wordThumb:    { width:56, height:56, borderRadius:10 },
  wordThumbPlaceholder:{ width:56, height:56, borderRadius:10, alignItems:'center', justifyContent:'center' },
  wordName:     { fontSize:17, fontWeight:'900' },
  wordDef:      { fontSize:13 },
  wordNext:     { fontSize:11 },
  emptyArea:    { alignItems:'center', paddingTop:60 },
  // Note styles
  noteCard:     { borderLeftWidth:4, marginBottom:12, padding:14 },
  noteHeader:   { justifyContent:'space-between', marginBottom:10 },
  noteDate:     { fontSize:12, fontWeight:'600' },
  noteScore:    { paddingHorizontal:10, paddingVertical:3, borderRadius:20 },
  noteScoreTxt: { fontWeight:'900', fontSize:13 },
  wordChips:    { flexDirection:'row', flexWrap:'wrap', gap:6 },
  noteChip:     { paddingHorizontal:10, paddingVertical:4, borderRadius:20 },
  noteChipTxt:  { fontSize:12, fontWeight:'700' },
  noteParagraph:{ fontSize:13, lineHeight:20, marginBottom:8, fontStyle:'italic' },
  noteCorrections:{ borderRadius:10, padding:10, borderWidth:1 },
  noteCorrectionsTitle:{ fontSize:13, fontWeight:'800', marginBottom:4 },
  // Modal
  modalOverlay: { flex:1, backgroundColor:'rgba(0,0,0,.58)', justifyContent:'flex-end' },
  modalSheet:   { borderTopLeftRadius:24, borderTopRightRadius:24, padding:20, maxHeight:'92%' },
  modalTopBar:  { justifyContent:'space-between', marginBottom:14 },
  modalClose:   { fontSize:20 },
  modalWordTitle:{ fontSize:18, fontWeight:'900' },
  modalImg:     { width:'100%', height:150, borderRadius:14, marginBottom:14 },
  modalWordRow: { justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 },
  modalWord:    { fontSize:28, fontWeight:'900', marginBottom:6 },
  miniStat:     { flex:1, borderRadius:12, padding:10, alignItems:'center', borderWidth:1 },
  miniStatVal:  { fontSize:20, fontWeight:'900' },
  miniStatLbl:  { fontSize:11, color:'#999', marginTop:2 },
  fieldHeader:  { justifyContent:'space-between', marginBottom:6 },
  fieldLabel:   { fontSize:14, fontWeight:'700' },
  fieldBox:     { borderRadius:12, padding:12, borderWidth:1, marginBottom:14 },
  fieldText:    { fontSize:14, lineHeight:22 },
  nextReviewBox:{ gap:6, padding:10, borderRadius:12, borderWidth:1, marginBottom:14 },
  nextReviewTxt:{ fontSize:13 },
});
