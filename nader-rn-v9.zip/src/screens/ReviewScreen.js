import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  StyleSheet, Alert, Animated, Easing,
} from 'react-native';
import * as Speech  from 'expo-speech';
import * as Haptics from 'expo-haptics';
import { T }        from '../theme';
import { t, isRTL } from '../i18n';
import {
  getDueWords, DAILY_CARDS, MASTERED_THRESHOLD, HARD_THRESHOLD,
  nextReviewDate, similarity, todayStr,
} from '../state';
import { aiReviewContent }              from '../services/ai';
import { playSound, preloadSounds }     from '../services/SoundService';
import { Card, Btn, Inp, Spinner, Elephant } from '../components';
import SmartImage                       from '../components/SmartImage';
import ParagraphChallenge               from './ParagraphChallenge';

// ─── TTS ──────────────────────────────────────────────────────────────────────
const speakWord = (text, lang) => Speech.speak(text, { language: lang, rate: 0.9 });
const speakWithPause = (text, lang) => {
  Speech.stop();
  const parts = text.split('___');
  if (parts.length === 1) { speakWord(text, lang); return; }
  let i = 0;
  const next = () => {
    if (i >= parts.length) return;
    const chunk = parts[i++];
    if (chunk.trim()) {
      Speech.speak(chunk, { language: lang, rate: 0.9,
        onDone: () => { if (i < parts.length) setTimeout(next, 800); else next(); } });
    } else { if (i < parts.length) setTimeout(next, 800); else next(); }
  };
  next();
};

// ─── Slide-in card on mount ───────────────────────────────────────────────────
const SlideCard = ({ children, style, dir = 1 }) => {
  const slide = useRef(new Animated.Value(dir * 60)).current;
  const alpha = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.spring(slide, { toValue: 0, useNativeDriver: true, tension: 90, friction: 11 }),
      Animated.timing(alpha, { toValue: 1, duration: 220, useNativeDriver: true }),
    ]).start();
  }, []);
  return (
    <Animated.View style={[style, { transform: [{ translateX: slide }], opacity: alpha }]}>
      {children}
    </Animated.View>
  );
};

// ─── Confetti burst ───────────────────────────────────────────────────────────
const CONFETTI = ['🎉','⭐','✨','🌟','💫','🎊','🏆','🎯'];
const ConfettiBurst = ({ visible }) => {
  const anims = useRef(CONFETTI.map(() => ({
    y: new Animated.Value(-20),
    x: new Animated.Value(0),
    o: new Animated.Value(1),
    s: new Animated.Value(0.5),
  }))).current;

  useEffect(() => {
    if (!visible) return;
    anims.forEach((a, i) => {
      a.y.setValue(-20); a.x.setValue(0); a.o.setValue(1); a.s.setValue(0.5);
      Animated.parallel([
        Animated.timing(a.y, { toValue: 140 + i * 12, duration: 1000,
          useNativeDriver: true, easing: Easing.out(Easing.quad) }),
        Animated.timing(a.x, { toValue: (i % 2 === 0 ? 1 : -1) * (15 + i * 12),
          duration: 1000, useNativeDriver: true }),
        Animated.timing(a.o, { toValue: 0, duration: 1000, delay: 350, useNativeDriver: true }),
        Animated.spring(a.s, { toValue: 1, useNativeDriver: true, speed: 30 }),
      ]).start();
    });
  }, [visible]);

  if (!visible) return null;
  return (
    <View style={cf.wrap} pointerEvents="none">
      {CONFETTI.map((em, i) => (
        <Animated.Text key={i} style={[cf.item, {
          transform: [{ translateY: anims[i].y }, { translateX: anims[i].x }, { scale: anims[i].s }],
          opacity: anims[i].o,
          left: `\${6 + i * 11}%`,
        }]}>{em}</Animated.Text>
      ))}
    </View>
  );
};
const cf = StyleSheet.create({
  wrap: { position:'absolute', top:0, left:0, right:0, height:180, zIndex:999, overflow:'hidden' },
  item: { position:'absolute', fontSize:26 },
});

// ─── Pulse ring (correct answer) ─────────────────────────────────────────────
const PulseRing = ({ visible, color = '#22C55E' }) => {
  const scale = useRef(new Animated.Value(0.5)).current;
  const alpha = useRef(new Animated.Value(0.8)).current;
  useEffect(() => {
    if (!visible) return;
    scale.setValue(0.5); alpha.setValue(0.8);
    Animated.parallel([
      Animated.timing(scale, { toValue: 2.2, duration: 600, useNativeDriver: true, easing: Easing.out(Easing.quad) }),
      Animated.timing(alpha, { toValue: 0,   duration: 600, useNativeDriver: true }),
    ]).start();
  }, [visible]);
  if (!visible) return null;
  return (
    <Animated.View pointerEvents="none" style={[pr.ring, {
      borderColor: color, transform: [{ scale }], opacity: alpha,
    }]}/>
  );
};
const pr = StyleSheet.create({
  ring: { position:'absolute', alignSelf:'center', width:100, height:100,
          borderRadius:50, borderWidth:3, zIndex:50 },
});

// ─── XP pop-up ────────────────────────────────────────────────────────────────
const XPPop = ({ xp, visible }) => {
  const y = useRef(new Animated.Value(0)).current;
  const o = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!visible) return;
    y.setValue(0); o.setValue(1);
    Animated.parallel([
      Animated.timing(y, { toValue: -50, duration: 900, useNativeDriver: true, easing: Easing.out(Easing.quad) }),
      Animated.timing(o, { toValue: 0,   duration: 900, delay: 300, useNativeDriver: true }),
    ]).start();
  }, [visible]);
  if (!visible || !xp) return null;
  return (
    <Animated.View pointerEvents="none" style={[xpp.box, { transform: [{ translateY: y }], opacity: o }]}>
      <Text style={xpp.txt}>+{xp} XP ⭐</Text>
    </Animated.View>
  );
};
const xpp = StyleSheet.create({
  box: { position:'absolute', alignSelf:'center', top:0, backgroundColor:'#F59E0B',
         paddingHorizontal:14, paddingVertical:6, borderRadius:20, zIndex:60 },
  txt: { color:'#fff', fontWeight:'900', fontSize:16 },
});

// ─── Review Screen ────────────────────────────────────────────────────────────
export default function ReviewScreen({ state, dispatch, onComplete, dk }) {
  const th   = T(dk);
  const rtl  = isRTL();
  const ta   = rtl ? 'right' : 'left';
  const rowD = rtl ? 'row-reverse' : 'row';

  const [session,      setSession]      = useState([]);
  const [idx,          setIdx]          = useState(0);
  const [cardData,     setCardData]     = useState(null);
  const [loadingCard,  setLoadingCard]  = useState(false);
  const [answer,       setAnswer]       = useState('');
  const [revealed,     setRevealed]     = useState(false);
  const [verdict,      setVerdict]      = useState(null);
  const [hintLetter,   setHintLetter]   = useState(false);
  const [hintLength,   setHintLength]   = useState(false);
  const [phase,        setPhase]        = useState('review');
  const [showConfetti, setShowConfetti] = useState(false);
  const [showPulse,    setShowPulse]    = useState(false);
  const [pulseColor,   setPulseColor]   = useState('#22C55E');
  const [xpPop,        setXpPop]        = useState({ visible:false, xp:0 });
  const [slideDir,     setSlideDir]     = useState(1);

  const shakeAnim  = useRef(new Animated.Value(0)).current;
  const bounceAnim = useRef(new Animated.Value(1)).current;
  const cardKey    = useRef(0);
  const hintUsed   = useRef({ letter: false, length: false });
  const sessionLog = useRef({ correct: 0, total: 0, startTime: Date.now() });

  useEffect(() => { preloadSounds(); }, []);

  const loadCard = useCallback(async (word, settings) => {
    setLoadingCard(true);
    setAnswer(''); setRevealed(false); setVerdict(null);
    setHintLetter(false); setHintLength(false);
    hintUsed.current = { letter: false, length: false };
    cardKey.current += 1;
    try {
      if (!settings.groqApiKey) throw new Error('no key');
      const c = await aiReviewContent(word.word, word.language, settings);
      setCardData(c);
    } catch {
      const blank = s => s.replace(new RegExp(word.word, 'gi'), '___');
      setCardData({
        definition: blank(word.definition || ''),
        examples:   (word.examples || []).map(blank),
      });
    }
    setLoadingCard(false);
  }, []);

  useEffect(() => {
    const due = getDueWords(state.words).slice(0, DAILY_CARDS);
    setSession(due);
    if (due.length > 0) loadCard(due[0], state.settings);
  }, []);

  // ── shake on wrong ──────────────────────────────────────────────────────────
  const shake = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(() => {});
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 14,  duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -14, duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8,   duration: 45, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8,  duration: 45, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0,   duration: 35, useNativeDriver: true }),
    ]).start();
  };

  // ── scale-bounce on correct ─────────────────────────────────────────────────
  const bounce = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    Animated.sequence([
      Animated.spring(bounceAnim, { toValue: 1.06, useNativeDriver: true, speed: 50 }),
      Animated.spring(bounceAnim, { toValue: 1,    useNativeDriver: true, speed: 20 }),
    ]).start();
  };

  // ── check answer ────────────────────────────────────────────────────────────
  const checkAnswer = () => {
    if (!answer.trim()) return;
    const word = session[idx];
    const sim  = similarity(answer, word.word);
    const v    = sim >= 0.99 ? 'correct' : sim >= 0.8 ? 'close' : 'wrong';

    setVerdict(v); setRevealed(true);
    sessionLog.current.total++;

    if (v !== 'wrong') {
      sessionLog.current.correct++;
      playSound('correct');
      bounce();
      setShowConfetti(true);
      setPulseColor('#22C55E');
      setShowPulse(true);
      setTimeout(() => setShowConfetti(false), 1200);
      setTimeout(() => setShowPulse(false),    700);
    } else {
      playSound('wrong');
      shake();
      setPulseColor('#EF4444');
      setShowPulse(true);
      setTimeout(() => setShowPulse(false), 600);
    }
    setTimeout(() => speakWord(word.word, word.language), 700);
  };

  // ── rate difficulty + advance ───────────────────────────────────────────────
  const rate = async (difficulty) => {
    let w = { ...session[idx] };
    const correct = verdict === 'correct' || verdict === 'close';

    if (correct) {
      w.correctStreak   = (w.correctStreak   || 0) + 1; w.incorrectStreak = 0;
      if (w.correctStreak >= MASTERED_THRESHOLD) w.mastered = true;
    } else {
      w.incorrectStreak = (w.incorrectStreak || 0) + 1; w.correctStreak = 0;
      if (w.incorrectStreak >= HARD_THRESHOLD) w.hard = true;
    }
    w.difficulty = difficulty;
    w.nextReview = nextReviewDate(difficulty, w.correctStreak);
    dispatch({ type: 'UPDATE_WORD', word: w });

    const xp = correct ? 10 : 2;
    dispatch({ type: 'AWARD_XP', amount: xp });
    setXpPop({ visible: true, xp });
    setTimeout(() => setXpPop({ visible: false, xp: 0 }), 1200);
    Haptics.selectionAsync().catch(() => {});

    if (idx + 1 >= session.length) {
      dispatch({
        type: 'LOG_SESSION',
        session: {
          date:     todayStr(),
          wordIds:  session.map(x => x.id),
          correct:  sessionLog.current.correct,
          total:    sessionLog.current.total,
          duration: Math.round((Date.now() - sessionLog.current.startTime) / 1000),
        },
      });
      // Play completed sound before showing paragraph screen
      await playSound('completed');
      setPhase('paragraph');
    } else {
      const ni = idx + 1;
      setSlideDir(1);
      setIdx(ni);
      loadCard(session[ni], state.settings);
    }
  };

  // ── hints ────────────────────────────────────────────────────────────────────
  const useLetterHint = () => {
    if (hintUsed.current.letter) return;
    if ((state.profile.hintPoints || 0) < 5) {
      Alert.alert('', rtl ? 'نقاط غير كافية! (تحتاج 5)' : 'Not enough points! (need 5)');
      return;
    }
    hintUsed.current.letter = true;
    dispatch({ type: 'SPEND_HINTS', amount: 5 });
    setHintLetter(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  };
  const useLengthHint = () => {
    if (hintUsed.current.length) return;
    if ((state.profile.hintPoints || 0) < 3) {
      Alert.alert('', rtl ? 'نقاط غير كافية! (تحتاج 3)' : 'Not enough points! (need 3)');
      return;
    }
    hintUsed.current.length = true;
    dispatch({ type: 'SPEND_HINTS', amount: 3 });
    setHintLength(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  };

  // ─────────────────────────────────────────────────────────────────────────────
  if (session.length === 0) return (
    <View style={[rs.empty, { backgroundColor: th.bg }]}>
      <Text style={rs.emptyEmoji}>🎉</Text>
      <Text style={[rs.emptyTitle, { color: th.text }]}>{t('nothingToReview')}</Text>
      <Btn onPress={onComplete} style={{ marginTop: 16 }}>{t('backHome')}</Btn>
    </View>
  );

  if (phase === 'paragraph') return (
    <ParagraphChallenge session={session} state={state} dispatch={dispatch} onComplete={onComplete} dk={dk}/>
  );

  const word = session[idx];
  const prog = (idx / session.length) * 100;

  return (
    <View style={[rs.root, { backgroundColor: th.bg }]}>
      {/* Overlays */}
      <ConfettiBurst visible={showConfetti}/>
      <PulseRing     visible={showPulse}   color={pulseColor}/>
      <XPPop         visible={xpPop.visible} xp={xpPop.xp}/>

      <ScrollView style={rs.scroll} keyboardShouldPersistTaps="handled">
        {/* Progress */}
        <View style={[rs.progressArea, { flexDirection: rowD }]}>
          <TouchableOpacity onPress={onComplete}>
            <Text style={[rs.backBtn, { color: th.textSub }]}>←</Text>
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <View style={[rs.progRow, { flexDirection: rowD }]}>
              <Text style={[rs.progTxt, { color: th.textSub }]}>
                {t('card')} {idx + 1}/{session.length}
              </Text>
              <Text style={[rs.progTxt, { color: th.textSub }]}>+10 XP ⭐</Text>
            </View>
            <View style={[rs.barBg, { backgroundColor: th.border }]}>
              <Animated.View style={[rs.barFill, { width: `\${prog}%` }]}/>
            </View>
          </View>
        </View>

        <View style={rs.body}>
          {/* Flashcard */}
          <SlideCard key={cardKey.current} dir={slideDir}>
            <Animated.View style={[rs.flashcard, { transform: [{ scale: bounceAnim }] }]}>
              <Card dk={dk} style={{ padding: 0, overflow: 'hidden' }}>
                {loadingCard ? (
                  <View style={rs.loadingCard}>
                    <Elephant size={56}/>
                    <Text style={[rs.loadingTxt, { color: th.primary }]}>
                      {t('generatingCard')}
                    </Text>
                  </View>
                ) : cardData && (
                  <>
                    {/* Image */}
                    {word.imageUrl ? (
                      <SmartImage src={word.imageUrl} word={word.word} style={rs.cardImg}/>
                    ) : null}

                    <View style={{ padding: 14 }}>
                      {/* Definition */}
                      <TouchableOpacity
                        onPress={() => speakWithPause(cardData.definition, word.language)}
                        style={[rs.textBox, { backgroundColor: th.cardAlt, borderColor: th.border }]}
                      >
                        <Text style={[rs.defText, { color: th.text, textAlign: ta }]}>
                          📖 {cardData.definition}
                        </Text>
                        <Text style={rs.speakIcon}>🔊</Text>
                      </TouchableOpacity>

                      {/* Examples */}
                      {(cardData.examples || []).map((ex, i) => (
                        <TouchableOpacity key={i}
                          onPress={() => speakWithPause(ex, word.language)}
                          style={[rs.textBox, { backgroundColor: th.cardAlt, borderColor: th.border }]}
                        >
                          <Text style={[rs.exText, { color: th.text, textAlign: ta }]}>
                            💡 {ex}
                          </Text>
                          <Text style={rs.speakIcon}>🔊</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </>
                )}
              </Card>
            </Animated.View>
          </SlideCard>

          {/* Hints */}
          {!revealed && (
            <View style={rs.hintsSection}>
              <View style={[{ flexDirection: rowD, justifyContent: 'flex-end' }]}>
                <Text style={[rs.hintPtsTxt, { color: th.gold, backgroundColor: th.goLight }]}>
                  💡 {state.profile.hintPoints} {t('ptsLeft')}
                </Text>
              </View>
              <View style={[rs.hintsRow, { flexDirection: rowD }]}>
                <TouchableOpacity onPress={useLetterHint}
                  style={[rs.hintBtn, { borderColor: th.primary, backgroundColor: th.pLight },
                    hintLetter && rs.hintBtnUsed]}>
                  {hintLetter
                    ? <Text style={[rs.hintBtnTxt, { color: th.primary }]}>
                        {rtl ? 'الحرف: ' : 'Letter: '}
                        <Text style={{ fontWeight: '900' }}>{word.word[0].toUpperCase()}</Text>
                      </Text>
                    : <Text style={[rs.hintBtnTxt, { color: th.primary }]}>{t('firstLetter')}</Text>
                  }
                </TouchableOpacity>
                <TouchableOpacity onPress={useLengthHint}
                  style={[rs.hintBtn, { borderColor: th.blue, backgroundColor: th.bLight },
                    hintLength && rs.hintBtnUsed]}>
                  {hintLength
                    ? <Text style={[rs.hintBtnTxt, { color: th.blue }]}>
                        {rtl ? 'الحروف: ' : 'Length: '}
                        <Text style={{ fontWeight: '900' }}>{word.word.length}</Text>
                      </Text>
                    : <Text style={[rs.hintBtnTxt, { color: th.blue }]}>{t('wordLength')}</Text>
                  }
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Input / Result */}
          {!revealed ? (
            <Animated.View style={{ transform: [{ translateX: shakeAnim }] }}>
              <Card dk={dk}>
                <Inp value={answer} onChange={setAnswer}
                  placeholder={t('typeHidden')} dk={dk}
                  style={{ textAlign: 'center', fontSize: 18, fontWeight: '700', marginBottom: 12 }}
                  autoFocus
                />
                <Btn onPress={checkAnswer} disabled={!answer.trim()} full>{t('check')}</Btn>
              </Card>
            </Animated.View>
          ) : (
            <SlideCard key={`result_\${cardKey.current}`} dir={-1}>
              <Card dk={dk} style={[rs.resultCard, {
                backgroundColor: verdict === 'correct' ? th.gLight : verdict === 'close' ? th.goLight : th.rLight,
                borderColor:     verdict === 'correct' ? th.green  : verdict === 'close' ? th.gold   : th.red,
              }]}>
                <View style={rs.resultTop}>
                  <Text style={rs.resultEmoji}>
                    {verdict === 'correct' ? '🎉' : verdict === 'close' ? '🤏' : '❌'}
                  </Text>
                  <Text style={[rs.resultTitle, {
                    color: verdict === 'correct' ? th.green : verdict === 'close' ? th.gold : th.red,
                  }]}>
                    {verdict === 'correct' ? t('nailedIt') : verdict === 'close' ? t('soClose') : t('notQuite')}
                  </Text>
                  <TouchableOpacity onPress={() => speakWord(word.word, word.language)}
                    style={[rs.wordRow, { flexDirection: rowD }]}>
                    <Text style={[rs.wordTxt, { color: th.text }]}>
                      {word.word}
                    </Text>
                    <Text style={{ fontSize: 16 }}>🔊</Text>
                  </TouchableOpacity>
                </View>

                <Text style={[rs.rateLabel, { color: th.textMuted }]}>{t('howHard')}</Text>
                <View style={[rs.rateBtns, { flexDirection: rowD }]}>
                  {[
                    { l: t('easy'),   v: 'easy',   c: th.green, e: '😄' },
                    { l: t('medium'), v: 'medium', c: th.gold,  e: '😐' },
                    { l: t('hard2'),  v: 'hard',   c: th.red,   e: '😓' },
                  ].map(({ l, v, c, e }) => (
                    <TouchableOpacity key={v} onPress={() => rate(v)}
                      style={[rs.rateBtn, { borderColor: c, backgroundColor: th.card }]}>
                      <Text style={{ fontSize: 20 }}>{e}</Text>
                      <Text style={{ color: c, fontWeight: '700', fontSize: 13 }}>{l}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </Card>
            </SlideCard>
          )}
        </View>
        <View style={{ height: 32 }}/>
      </ScrollView>
    </View>
  );
}

const rs = StyleSheet.create({
  root:         { flex:1 },
  scroll:       { flex:1 },
  progressArea: { alignItems:'center', gap:10, paddingHorizontal:20, paddingTop:56, paddingBottom:16 },
  backBtn:      { fontSize:22 },
  progRow:      { justifyContent:'space-between', marginBottom:5 },
  progTxt:      { fontSize:13 },
  barBg:        { height:10, borderRadius:10, overflow:'hidden' },
  barFill:      { height:'100%', backgroundColor:'#7C3AED', borderRadius:10 },
  body:         { padding:16, gap:12 },
  flashcard:    {},
  loadingCard:  { alignItems:'center', padding:40, gap:12 },
  loadingTxt:   { fontWeight:'700', fontSize:14, textAlign:'center' },
  cardImg:      { width:'100%', height:150, borderRadius:0 },
  textBox:      { borderRadius:12, padding:13, marginBottom:10, borderWidth:1, flexDirection:'row', alignItems:'flex-start' },
  defText:      { fontSize:15, lineHeight:24, flex:1 },
  exText:       { fontSize:14, lineHeight:22, flex:1 },
  speakIcon:    { fontSize:18, marginLeft:8 },
  hintsSection: { gap:8 },
  hintPtsTxt:   { fontSize:12, fontWeight:'700', paddingHorizontal:10, paddingVertical:3, borderRadius:12 },
  hintsRow:     { gap:8 },
  hintBtn:      { flex:1, padding:10, borderRadius:12, borderWidth:2, borderStyle:'dashed', alignItems:'center' },
  hintBtnUsed:  { borderStyle:'solid' },
  hintBtnTxt:   { fontSize:12, fontWeight:'700', textAlign:'center' },
  resultCard:   { borderWidth:2 },
  resultTop:    { alignItems:'center', marginBottom:16, gap:4 },
  resultEmoji:  { fontSize:44 },
  resultTitle:  { fontSize:18, fontWeight:'900' },
  wordRow:      { alignItems:'center', gap:6, marginTop:4 },
  wordTxt:      { fontSize:18, fontWeight:'900' },
  rateLabel:    { textAlign:'center', marginBottom:12 },
  rateBtns:     { gap:8 },
  rateBtn:      { flex:1, padding:12, borderRadius:12, borderWidth:2, alignItems:'center', gap:4 },
  empty:        { flex:1, alignItems:'center', justifyContent:'center', padding:40 },
  emptyEmoji:   { fontSize:72, marginBottom:14 },
  emptyTitle:   { fontSize:22, fontWeight:'900', textAlign:'center' },
});
