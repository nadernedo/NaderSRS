/**
 * SmartImage — simple URL-based image with loading/error states.
 * Includes 18-second timeout to avoid indefinite loading on Pollinations.ai.
 */
import React, { useState, useRef, useEffect } from 'react';
import { View, Image, Text, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';

const PALETTES = [
  ['#7C3AED','#C4B5FD'], ['#10B981','#A7F3D0'], ['#F59E0B','#FDE68A'],
  ['#EF4444','#FECACA'], ['#3B82F6','#BFDBFE'], ['#EC4899','#FBCFE8'],
  ['#06B6D4','#A5F3FC'], ['#84CC16','#D9F99D'],
];
const palette = (word = '?') =>
  PALETTES[Math.abs((word.charCodeAt(0) || 0) % PALETTES.length)];

export const ImageFallback = ({ word = '?', style = {} }) => {
  const [c1, c2] = palette(word);
  return (
    <View style={[s.fallback, style, { backgroundColor: c1 }]}>
      <View style={[s.circle, { backgroundColor: c2 + 'AA' }]}>
        <Text style={s.letter}>{(word[0] || '?').toUpperCase()}</Text>
      </View>
      <Text style={s.wordTxt} numberOfLines={1}>{word}</Text>
    </View>
  );
};

export const makeImageUrl = (word) => {
  const seed = Math.floor(Math.random() * 99999);
  const prompt = encodeURIComponent(
    'minimalist flat illustration of ' + word + ', colorful, white background'
  );
  return 'https://image.pollinations.ai/prompt/' + prompt +
    '?seed=' + seed + '&nologo=true&width=512&height=512&model=flux-schnell';
};

export default function SmartImage({ src, word = '', style = {}, onNewUrl }) {
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState(false);
  const [imageUrl, setImageUrl] = useState(src || null);
  const timeoutRef = useRef(null);

  const clearTO = () => {
    if (timeoutRef.current) { clearTimeout(timeoutRef.current); timeoutRef.current = null; }
  };

  useEffect(() => {
    clearTO();
    setImageUrl(src || null);
    setLoading(!!src);
    setError(false);
    if (src) {
      timeoutRef.current = setTimeout(() => { setLoading(false); setError(true); }, 18000);
    }
    return clearTO;
  }, [src]);

  useEffect(() => () => clearTO(), []);

  const handleLoadStart = () => {
    setLoading(true); setError(false);
    clearTO();
    timeoutRef.current = setTimeout(() => { setLoading(false); setError(true); }, 18000);
  };
  const handleLoadEnd = () => { clearTO(); setLoading(false); };
  const handleError   = () => { clearTO(); setLoading(false); setError(true); };

  const retry = () => {
    clearTO();
    const newUrl = makeImageUrl(word);
    setImageUrl(newUrl);
    setLoading(true); setError(false);
    timeoutRef.current = setTimeout(() => { setLoading(false); setError(true); }, 18000);
    if (onNewUrl) onNewUrl(newUrl);
  };

  if (!imageUrl) return <ImageFallback word={word} style={style}/>;

  if (error) {
    return (
      <View style={[s.container, style]}>
        <ImageFallback word={word} style={StyleSheet.absoluteFill}/>
        <TouchableOpacity onPress={retry} style={s.retryBtn}>
          <Text style={s.retryTxt}>🔄</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[s.container, style]}>
      <ImageFallback word={word} style={StyleSheet.absoluteFill}/>
      {loading && (
        <View style={s.loadingOverlay}>
          <ActivityIndicator color="#fff" size="large"/>
          <Text style={s.loadingEmoji}>🎨</Text>
        </View>
      )}
      <Image
        source={{ uri: imageUrl }}
        style={[StyleSheet.absoluteFill, loading && { opacity: 0 }]}
        resizeMode="cover"
        onLoadStart={handleLoadStart}
        onLoadEnd={handleLoadEnd}
        onError={handleError}
      />
    </View>
  );
}

const s = StyleSheet.create({
  container:     { overflow: 'hidden' },
  fallback:      { justifyContent: 'center', alignItems: 'center', gap: 6, overflow: 'hidden' },
  circle:        { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  letter:        { fontSize: 30, fontWeight: '900', color: '#fff' },
  wordTxt:       { fontSize: 12, fontWeight: '700', color: 'rgba(255,255,255,.85)', maxWidth: '80%' },
  loadingOverlay:{ ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center',
                   backgroundColor: 'rgba(0,0,0,.25)', gap: 6 },
  loadingEmoji:  { fontSize: 22 },
  retryBtn:      { position: 'absolute', bottom: 8, right: 8, backgroundColor: 'rgba(0,0,0,.4)',
                   borderRadius: 20, padding: 6 },
  retryTxt:      { fontSize: 18 },
});
