// Language code → full name mapping
const LANG_NAMES = {
  en: 'English', ar: 'Arabic', fr: 'French',  de: 'German',
  es: 'Spanish', ja: 'Japanese', zh: 'Chinese', ko: 'Korean',
};
const getOutputLang = (s) => LANG_NAMES[s?.outputLanguage || 'ar'] || 'Arabic';

// ── Groq API call ─────────────────────────────────────────────────────────────
const callGroq = async (apiKey, model, messages) => {
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + apiKey,
    },
    body: JSON.stringify({ model, max_tokens: 1200, temperature: 0.7, messages }),
  });
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error((e.error && e.error.message) || 'HTTP ' + res.status);
  }
  const d = await res.json();
  return (d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content) || '';
};

// ── JSON extractor: strips ``` fences, finds outermost { } ───────────────────
const parseJSON = (raw) => {
  // Strip ```json ... ``` or ``` ... ``` fences
  let text = raw.replace(/```(?:json)?\s*/gi, '').replace(/```\s*/g, '').trim();
  // Find outermost JSON object
  const first = text.indexOf('{');
  const last  = text.lastIndexOf('}');
  if (first === -1 || last === -1 || last <= first) {
    throw new Error('No valid JSON found in AI response');
  }
  let jsonStr = text.slice(first, last + 1);
  try {
    return JSON.parse(jsonStr);
  } catch (_) {
    // Try stripping trailing commas before ] or }
    jsonStr = jsonStr.replace(/,(\s*[}\]])/g, '$1');
    return JSON.parse(jsonStr);
  }
};

export const callAI = (settings, messages) =>
  callGroq(settings.groqApiKey, settings.aiModel, messages);

// ── Generate word definition + examples ──────────────────────────────────────
export const aiGenerateWord = async (word, lang, settings) => {
  const outLang = getOutputLang(settings);
  const prompt = `You are a language tutor. The student is learning ${lang}.
Define the word: ${word}
Write the definition and BOTH example sentences in ${outLang}.
Return ONLY a raw JSON object — no markdown, no code block:
{"definition":"<one sentence in ${outLang}>","examples":["<sentence using ${word}>","<another sentence using ${word}>"]}`;
  const raw = await callAI(settings, [{ role: 'user', content: prompt }]);
  return parseJSON(raw);
};

// ── Fill-in-the-blank review card ─────────────────────────────────────────────
export const aiReviewContent = async (word, lang, settings) => {
  const outLang = getOutputLang(settings);
  const prompt = `Make a fill-in-the-blank flashcard for the ${lang} word "${word}".
Replace EVERY occurrence of "${word}" with ___ (three underscores).
Write the definition and examples in ${outLang}.
Return ONLY a raw JSON object — no markdown, no code block:
{"definition":"<${outLang} definition with ___ for the word>","examples":["<${outLang} sentence with ___ >","<another ${outLang} sentence with ___ >"]}`;
  const raw = await callAI(settings, [{ role: 'user', content: prompt }]);
  return parseJSON(raw);
};

// ── Evaluate paragraph ────────────────────────────────────────────────────────
export const aiEvaluateParagraph = async (paragraph, words, lang, settings) => {
  const outLang   = getOutputLang(settings);
  const wordList  = words.join(', ');
  const prompt = `You are a ${lang} writing coach. Give ALL feedback in ${outLang}.
Target vocab words: ${wordList}
Student paragraph: "${paragraph}"

Creative writing is fine — judge grammar and vocab usage only.
Return ONLY a raw JSON object — no markdown:
{"score":7,"feedback":"<one sentence in ${outLang}>","corrections":["<fix 1 in ${outLang}>","<fix 2>"],"encouragement":"<short motivational line in ${outLang}>"}`;
  const raw = await callAI(settings, [{ role: 'user', content: prompt }]);
  return parseJSON(raw);
};

// ── Test Groq connection ──────────────────────────────────────────────────────
export const testGroqConnection = async (apiKey, model) => {
  try {
    const r = await callGroq(apiKey, model, [{ role: 'user', content: 'Reply with one word: OK' }]);
    return { ok: true, msg: `✅ Connected! Reply: "${r.trim().slice(0, 30)}"` };
  } catch (e) {
    return { ok: false, msg: `❌ Failed: ${e.message}` };
  }
};

// ── Generate improved paragraph ───────────────────────────────────────────────
export const aiImprovedParagraph = async (paragraph, corrections, lang, settings) => {
  const outLang   = getOutputLang(settings);
  const corrList  = corrections.map((c, i) => `${i + 1}. ${c}`).join('\n');
  const prompt = `You are a ${lang} writing coach. Rewrite applying ALL corrections, keep original ideas.
Original: "${paragraph}"

Corrections:
${corrList}

Describe changes in ${outLang}.
Return ONLY a raw JSON object:
{"improved":"<corrected paragraph>","changes":["<change 1 in ${outLang}>","<change 2>"]}`;
  const raw = await callAI(settings, [{ role: 'user', content: prompt }]);
  return parseJSON(raw);
};
