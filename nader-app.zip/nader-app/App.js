import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, StatusBar } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import * as SplashScreen from 'expo-splash-screen';
import AppNavigator from './src/navigation/AppNavigator';
import { isOnboardingDone, getProfile } from './src/services/StorageService';
import { setLanguage } from './src/constants/i18n';
import { colors } from './src/constants/colors';

SplashScreen.preventAutoHideAsync();

export default function App() {
  const [ready, setReady] = useState(false);
  const [onboarded, setOnboarded] = useState(false);

  useEffect(() => {
    prepare();
  }, []);

  const prepare = async () => {
    try {
      const [done, profile] = await Promise.all([
        isOnboardingDone(),
        getProfile(),
      ]);

      if (profile?.appLanguage) {
        setLanguage(profile.appLanguage);
      }

      setOnboarded(done);
    } catch (e) {
      console.warn('App init error:', e);
    } finally {
      setReady(true);
      await SplashScreen.hideAsync();
    }
  };

  if (!ready) {
    return (
      <View style={styles.splash}>
        <Text style={styles.splashEmoji}>🦉</Text>
        <Text style={styles.splashText}>نادر</Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />
      <AppNavigator isOnboarded={onboarded} />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  splash: {
    flex: 1,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  splashEmoji: {
    fontSize: 80,
  },
  splashText: {
    fontSize: 40,
    fontWeight: '900',
    color: '#FFFFFF',
    letterSpacing: 4,
  },
});
