# 🦉 Nader App - تطبيق تعلم اللغات

تطبيق موبايل مبني بـ React Native / Expo لتعلم اللغات بطريقة ذكية ومرحة.

---

## ✨ المميزات

- 🧠 **SRS Algorithm** - نظام مراجعة ذكي
- 🤖 **Groq AI** - توليد تعريفات وأمثلة بالذكاء الاصطناعي
- 🖼️ **Image Generation** - صور تعبيرية مجانية عبر Pollinations.ai
- 🔥 **Streak System** - سلسلة أيام متواصلة
- 👾 **Paragraph Challenge** - تحدي الكتابة اليومي
- 📊 **Stats Dashboard** - إحصائيات تفصيلية
- 🔔 **Local Notifications** - تذكيرات يومية

---

## 🚀 خطوات التشغيل

### 1. تثبيت المتطلبات
```bash
node --version   # يجب أن يكون 18+
npm --version
```

### 2. تثبيت Expo CLI و EAS CLI
```bash
npm install -g expo-cli eas-cli
```

### 3. تثبيت dependencies
```bash
cd nader-app
npm install
```

### 4. تشغيل التطبيق محلياً
```bash
npx expo start
```
ثم امسح QR Code بتطبيق **Expo Go** من متجر Google Play.

---

## 📦 بناء APK

### الطريقة السهلة (EAS Build - مجانية)

#### 1. إنشاء حساب Expo
اذهب إلى [expo.dev](https://expo.dev) وأنشئ حساباً مجانياً.

#### 2. تسجيل الدخول
```bash
eas login
```

#### 3. ربط المشروع
```bash
eas init
```
سيعطيك `projectId`، أضفه في `app.json` تحت `extra.eas.projectId`.

#### 4. بناء APK
```bash
eas build -p android --profile preview
```
> سيتم البناء على السيرفر (5-10 دقائق) ثم يعطيك رابط تحميل APK مباشرة!

---

## 🔑 مفاتيح API

### Groq API (مجاني)
1. اذهب إلى [console.groq.com](https://console.groq.com)
2. أنشئ حساباً مجانياً
3. أنشئ مفتاح API
4. أدخله في التطبيق من **الإعدادات → مفاتيح API**

### الصور (مجانية تلقائياً)
التطبيق يستخدم [Pollinations.ai](https://pollinations.ai) - **لا يحتاج API key**.

---

## 📁 هيكل المشروع

```
nader-app/
├── App.js                    # Entry point
├── app.json                  # Expo config
├── eas.json                  # EAS Build config
├── src/
│   ├── constants/
│   │   ├── colors.js         # ألوان وثيمات
│   │   ├── i18n.js           # ترجمات عربي/إنجليزي
│   │   └── languages.js      # قائمة اللغات
│   ├── services/
│   │   ├── StorageService.js # AsyncStorage (قاعدة البيانات)
│   │   ├── SRSService.js     # خوارزمية المراجعة
│   │   ├── GroqService.js    # Groq AI API
│   │   ├── ImageService.js   # توليد الصور
│   │   └── NotificationService.js
│   ├── components/
│   │   ├── Mascot.js         # شخصية البومة المتحركة
│   │   └── Badges.js         # StreakBadge, XPBar, LevelBadge
│   ├── navigation/
│   │   └── AppNavigator.js   # Navigation setup
│   └── screens/
│       ├── OnboardingScreen.js   # الإعداد الأولي
│       ├── HomeScreen.js         # الشاشة الرئيسية
│       ├── AddWordScreen.js      # إضافة كلمات
│       ├── ReviewScreen.js       # جلسة المراجعة
│       ├── ParagraphChallengeScreen.js  # تحدي الكتابة
│       ├── StatsScreen.js        # الإحصائيات
│       └── SettingsScreen.js     # الإعدادات
```

---

## 📱 الشاشات

| الشاشة | الوصف |
|--------|-------|
| Onboarding | 4 خطوات: ترحيب، اسم، لغة التعلم، لغة الواجهة |
| Home | الرئيسية مع mascot، streak، XP، وزر المراجعة |
| Add Word | إضافة كلمات فردية أو متعددة مع AI |
| Review | جلسة SRS مع تلميحات وتقييم ذاتي |
| Paragraph Challenge | تحدي الكتابة مع تقييم AI |
| Stats | رسوم بيانية وإحصائيات كاملة |
| Settings | ملف شخصي، API keys، لغات، إشعارات |

---

## 🛠️ تقنيات مستخدمة

- **React Native** + **Expo** ~51
- **AsyncStorage** - تخزين محلي
- **Groq API** (llama-3.1-8b-instant) - ذكاء اصطناعي
- **Pollinations.ai** - توليد صور مجاني
- **expo-speech** - Text-to-Speech
- **expo-notifications** - إشعارات محلية
- **react-native-chart-kit** - رسوم بيانية
- **expo-linear-gradient** - تدرجات لونية

---

## ❓ مشاكل شائعة

**`npm install` بطيء؟**
```bash
npm install --legacy-peer-deps
```

**خطأ في expo start؟**
```bash
npx expo install --fix
```

**APK لا يعمل على الجهاز؟**
تأكد من تفعيل "Unknown Sources" في إعدادات الأندرويد.
