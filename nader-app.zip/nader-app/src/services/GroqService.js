const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL = 'llama-3.1-8b-instant'; // Fast and free tier

// ─── Test connection ───────────────────────────────────────────────────────────

export const testGroqConnection = async (apiKey) => {
  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 10,
        messages: [{ role: 'user', content: 'Say "ok"' }],
      }),
    });
    return response.ok;
  } catch {
    return false;
  }
};

// ─── Generate word content ─────────────────────────────────────────────────────

export const generateWordContent = async (word, targetLanguage, apiKey) => {
  const prompt = `You are a language learning assistant. Generate content for the word "${word}" in ${targetLanguage}.
Return ONLY a valid JSON object (no markdown, no extra text) with exactly this structure:
{
  "definition": "Clear definition in 1-2 sentences. Include part of speech at start (e.g., [Noun] ...)",
  "examples": [
    "First natural example sentence using '${word}' in context",
    "Second natural example sentence using '${word}' in a different context"
  ],
  "pronunciation": "Simple phonetic pronunciation (e.g., /ɪˈfem.ər.əl/)"
}`;

  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 300,
        temperature: 0.7,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || 'Groq API error');
    }

    const data = await response.json();
    const text = data.choices[0]?.message?.content || '';
    
    // Extract JSON from response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Invalid response format');
    
    return JSON.parse(jsonMatch[0]);
  } catch (error) {
    throw error;
  }
};

// ─── Generate review card (with blanked word) ──────────────────────────────────

export const generateReviewCard = async (word, targetLanguage, apiKey) => {
  const prompt = `Generate a FRESH definition and examples for the word "${word}" in ${targetLanguage} for a language learner reviewing this word.
IMPORTANT: Replace every occurrence of "${word}" with "___" (three underscores).
Return ONLY a valid JSON object with:
{
  "definition": "Definition of the word where '${word}' is replaced with '___'",
  "examples": [
    "Example sentence where '${word}' is replaced with '___'",
    "Another different example where '${word}' is replaced with '___'"
  ]
}
Make the examples DIFFERENT from common ones to prevent blind memorization.`;

  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 300,
        temperature: 0.9, // Higher temperature for more variety
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) throw new Error('Groq API error');

    const data = await response.json();
    const text = data.choices[0]?.message?.content || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Invalid response format');
    
    return JSON.parse(jsonMatch[0]);
  } catch {
    // Fallback: use original content with word blanked
    return null;
  }
};

// ─── Evaluate paragraph challenge ─────────────────────────────────────────────

export const evaluateParagraph = async (paragraph, targetWords, targetLanguage, apiKey) => {
  const wordsList = targetWords.join(', ');

  const prompt = `You are evaluating a language learner's writing in ${targetLanguage}.

The learner was reviewing these words: ${wordsList}
They need to use at least 4 of these words in their paragraph.

Their paragraph:
"${paragraph}"

Evaluate this paragraph and return ONLY a valid JSON object:
{
  "score": <integer 0-10>,
  "wordsUsedCorrectly": [<array of correctly used words from the target list>],
  "wordsMissed": [<array of target words not used or used incorrectly>],
  "grammarErrors": [
    {
      "original": "<problematic phrase>",
      "corrected": "<corrected version>",
      "explanation": "<brief explanation>"
    }
  ],
  "nativeRating": "<natural|somewhat-natural|unnatural>",
  "feedback": "<1-2 sentences of encouraging feedback mentioning what was good>",
  "passed": <true if score >= 5 AND at least 4 target words used correctly, false otherwise>
}

Scoring guide:
- Grammar accuracy (0-4 points)
- Correct usage of target words (0-4 points)
- Natural/native-like writing (0-2 points)
Accept creative/absurd stories as long as grammar is correct and words are used properly.`;

  try {
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 600,
        temperature: 0.3,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) throw new Error('Groq API error');

    const data = await response.json();
    const text = data.choices[0]?.message?.content || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Invalid response format');

    const result = JSON.parse(jsonMatch[0]);

    // Ensure passed logic is correct
    result.passed =
      result.score >= 5 && result.wordsUsedCorrectly.length >= 4;

    return result;
  } catch (error) {
    throw error;
  }
};
