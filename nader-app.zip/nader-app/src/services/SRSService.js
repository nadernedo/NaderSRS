import { updateWord } from './StorageService';

// ─── SRS Constants ────────────────────────────────────────────────────────────

const STATUS = {
  NEW: 'new',
  LEARNING: 'learning',
  HARD: 'hard',
  MASTERED: 'mastered',
};

const INTERVALS = {
  EASY: 2.5,
  MEDIUM: 1.5,
  HARD: 0.5,
  MIN_DAYS: 1,
  MASTERED_BASE: 7,
};

const STREAKS = {
  MASTER_CORRECT: 3,
  BECOME_HARD: 3,
};

// ─── Create a new word object ─────────────────────────────────────────────────

export const createWordObject = ({
  word,
  definition,
  examples,
  imageUrl = null,
  pronunciation = '',
}) => ({
  id: generateId(),
  word: word.trim(),
  definition,
  examples,
  imageUrl,
  pronunciation,
  status: STATUS.NEW,
  correctStreak: 0,
  incorrectStreak: 0,
  interval: 1, // days
  dateAdded: new Date().toISOString(),
  lastReviewDate: null,
  nextReviewDate: new Date().toISOString(), // Due today
  totalReviews: 0,
  totalCorrect: 0,
});

// ─── Process a review answer ──────────────────────────────────────────────────

export const processReview = async (word, rating) => {
  // rating: 'easy' | 'medium' | 'hard'
  const now = new Date();
  let {
    correctStreak = 0,
    incorrectStreak = 0,
    interval = 1,
    totalReviews = 0,
    totalCorrect = 0,
    status,
  } = word;

  totalReviews += 1;

  let newStatus = status;
  let newInterval = interval;
  let xpEarned = 0;

  if (rating === 'hard') {
    // Wrong/Hard
    incorrectStreak += 1;
    correctStreak = 0;
    newInterval = Math.max(interval * INTERVALS.HARD, INTERVALS.MIN_DAYS);
    xpEarned = 3;

    if (incorrectStreak >= STREAKS.BECOME_HARD) {
      newStatus = STATUS.HARD;
    } else if (status === 'mastered') {
      newStatus = STATUS.LEARNING;
    }
  } else {
    // Correct (easy or medium)
    totalCorrect += 1;
    correctStreak += 1;
    incorrectStreak = 0;

    const multiplier =
      rating === 'easy' ? INTERVALS.EASY : INTERVALS.MEDIUM;
    newInterval = Math.max(interval * multiplier, INTERVALS.MIN_DAYS);

    xpEarned = rating === 'easy' ? 15 : 10;

    if (correctStreak >= STREAKS.MASTER_CORRECT) {
      newStatus = STATUS.MASTERED;
      newInterval = Math.max(newInterval, INTERVALS.MASTERED_BASE);
      xpEarned += 25; // bonus for mastering
    } else if (status === STATUS.NEW || status === STATUS.HARD) {
      newStatus = STATUS.LEARNING;
    }
  }

  // Calculate next review date
  const nextReviewDate = new Date(now);
  nextReviewDate.setDate(nextReviewDate.getDate() + Math.round(newInterval));

  const updates = {
    status: newStatus,
    correctStreak,
    incorrectStreak,
    interval: newInterval,
    totalReviews,
    totalCorrect,
    lastReviewDate: now.toISOString(),
    nextReviewDate: nextReviewDate.toISOString(),
  };

  await updateWord(word.id, updates);

  return {
    ...word,
    ...updates,
    xpEarned,
    statusChanged: newStatus !== status,
    mastered: newStatus === STATUS.MASTERED && status !== STATUS.MASTERED,
  };
};

// ─── XP System ────────────────────────────────────────────────────────────────

export const XP_THRESHOLDS = [
  { level: 'beginner', minXP: 0, maxXP: 200, label: 'beginner' },
  { level: 'learner', minXP: 201, maxXP: 600, label: 'learner' },
  { level: 'writer', minXP: 601, maxXP: 1200, label: 'writer' },
  { level: 'speaker', minXP: 1201, maxXP: 2500, label: 'speaker' },
  { level: 'native', minXP: 2501, maxXP: Infinity, label: 'native' },
];

export const getLevelInfo = (totalXP) => {
  const current = XP_THRESHOLDS.find(
    (l) => totalXP >= l.minXP && totalXP <= l.maxXP
  ) || XP_THRESHOLDS[0];

  const nextIndex = XP_THRESHOLDS.indexOf(current) + 1;
  const next = XP_THRESHOLDS[nextIndex] || null;

  const progress = next
    ? (totalXP - current.minXP) / (next.minXP - current.minXP)
    : 1;

  return {
    current: current.level,
    currentLabel: current.label,
    xpInLevel: totalXP - current.minXP,
    xpToNext: next ? next.minXP - totalXP : 0,
    progress: Math.min(progress, 1),
    isMaxLevel: !next,
  };
};

export const LEVEL_AVATARS = {
  beginner: '🌱',
  learner: '📚',
  writer: '✍️',
  speaker: '🗣️',
  native: '🏆',
};

// ─── Typo Tolerance ───────────────────────────────────────────────────────────

export const checkAnswer = (input, correct, tolerance = 0.8) => {
  const normalizedInput = input.trim().toLowerCase();
  const normalizedCorrect = correct.trim().toLowerCase();

  if (normalizedInput === normalizedCorrect) {
    return { result: 'correct', similarity: 1 };
  }

  const similarity = calculateSimilarity(normalizedInput, normalizedCorrect);

  if (similarity >= tolerance) {
    return { result: 'almost', similarity };
  }

  return { result: 'wrong', similarity };
};

const calculateSimilarity = (a, b) => {
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  const distance = levenshteinDistance(a, b);
  return 1 - distance / maxLen;
};

const levenshteinDistance = (a, b) => {
  const matrix = [];
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  return matrix[b.length][a.length];
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

const generateId = () => {
  return `word_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const generateSessionId = () => {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};
