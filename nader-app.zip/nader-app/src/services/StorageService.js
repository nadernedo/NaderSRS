import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  PROFILE: '@nader_profile',
  WORDS: '@nader_words',
  SESSIONS: '@nader_sessions',
  ONBOARDING_DONE: '@nader_onboarding',
  HINT_POINTS: '@nader_hint_points',
  LAST_HINT_REFRESH: '@nader_hint_refresh',
  DAILY_SESSION: '@nader_daily_session',
};

const DEFAULT_PROFILE = {
  name: '',
  avatar: '🎓',
  targetLanguage: 'en',
  appLanguage: 'ar',
  streak: 0,
  lastStudyDate: null,
  totalXP: 0,
  level: 'beginner',
  groqApiKey: '',
  notificationsEnabled: true,
  reminderTime: '20:00',
  createdAt: new Date().toISOString(),
};

// ─── Profile ──────────────────────────────────────────────────────────────────

export const getProfile = async () => {
  try {
    const data = await AsyncStorage.getItem(KEYS.PROFILE);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
};

export const saveProfile = async (profile) => {
  try {
    await AsyncStorage.setItem(KEYS.PROFILE, JSON.stringify(profile));
    return true;
  } catch {
    return false;
  }
};

export const updateProfile = async (updates) => {
  try {
    const profile = await getProfile();
    const updated = { ...profile, ...updates };
    await saveProfile(updated);
    return updated;
  } catch {
    return null;
  }
};

// ─── Words ────────────────────────────────────────────────────────────────────

export const getWords = async () => {
  try {
    const data = await AsyncStorage.getItem(KEYS.WORDS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

export const saveWords = async (words) => {
  try {
    await AsyncStorage.setItem(KEYS.WORDS, JSON.stringify(words));
    return true;
  } catch {
    return false;
  }
};

export const addWord = async (word) => {
  try {
    const words = await getWords();
    const exists = words.some(
      (w) => w.word.toLowerCase() === word.word.toLowerCase()
    );
    if (exists) return { success: false, reason: 'exists' };
    const newWords = [...words, word];
    await saveWords(newWords);
    return { success: true };
  } catch {
    return { success: false, reason: 'error' };
  }
};

export const updateWord = async (wordId, updates) => {
  try {
    const words = await getWords();
    const idx = words.findIndex((w) => w.id === wordId);
    if (idx === -1) return false;
    words[idx] = { ...words[idx], ...updates };
    await saveWords(words);
    return true;
  } catch {
    return false;
  }
};

export const deleteWord = async (wordId) => {
  try {
    const words = await getWords();
    const filtered = words.filter((w) => w.id !== wordId);
    await saveWords(filtered);
    return true;
  } catch {
    return false;
  }
};

export const getDueWords = async (limit = 7) => {
  try {
    const words = await getWords();
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Words due for review (nextReviewDate <= today)
    const due = words.filter((w) => {
      if (w.status === 'mastered') {
        const nextReview = w.nextReviewDate ? new Date(w.nextReviewDate) : new Date(0);
        return nextReview <= now;
      }
      const nextReview = w.nextReviewDate ? new Date(w.nextReviewDate) : today;
      return nextReview <= now;
    });

    // Sort: hard words first, then by review date
    due.sort((a, b) => {
      if (a.status === 'hard' && b.status !== 'hard') return -1;
      if (b.status === 'hard' && a.status !== 'hard') return 1;
      const dateA = a.nextReviewDate ? new Date(a.nextReviewDate) : new Date(0);
      const dateB = b.nextReviewDate ? new Date(b.nextReviewDate) : new Date(0);
      return dateA - dateB;
    });

    // If not enough due words, add new words
    let selected = due.slice(0, limit);
    if (selected.length < limit) {
      const newWords = words
        .filter((w) => w.status === 'new' && !selected.find((s) => s.id === w.id))
        .slice(0, limit - selected.length);
      selected = [...selected, ...newWords];
    }

    return selected;
  } catch {
    return [];
  }
};

// ─── Sessions ─────────────────────────────────────────────────────────────────

export const getSessions = async () => {
  try {
    const data = await AsyncStorage.getItem(KEYS.SESSIONS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

export const saveSession = async (session) => {
  try {
    const sessions = await getSessions();
    const updated = [...sessions, session];
    // Keep last 90 days
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - 90);
    const filtered = updated.filter((s) => new Date(s.date) >= cutoff);
    await AsyncStorage.setItem(KEYS.SESSIONS, JSON.stringify(filtered));
    return true;
  } catch {
    return false;
  }
};

export const getTodaySession = async () => {
  try {
    const data = await AsyncStorage.getItem(KEYS.DAILY_SESSION);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
};

export const setTodaySession = async (session) => {
  try {
    await AsyncStorage.setItem(KEYS.DAILY_SESSION, JSON.stringify(session));
    return true;
  } catch {
    return false;
  }
};

// ─── Streak ───────────────────────────────────────────────────────────────────

export const updateStreak = async () => {
  try {
    const profile = await getProfile();
    if (!profile) return null;

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const lastStudy = profile.lastStudyDate ? new Date(profile.lastStudyDate) : null;

    let { streak = 0 } = profile;

    if (!lastStudy) {
      streak = 1;
    } else {
      const lastStudyDay = new Date(
        lastStudy.getFullYear(),
        lastStudy.getMonth(),
        lastStudy.getDate()
      );
      const dayDiff = Math.floor((today - lastStudyDay) / (1000 * 60 * 60 * 24));

      if (dayDiff === 0) {
        // Already studied today, no change
      } else if (dayDiff === 1) {
        streak += 1;
      } else {
        streak = 1; // Streak broken
      }
    }

    const updated = await updateProfile({
      streak,
      lastStudyDate: now.toISOString(),
    });
    return updated;
  } catch {
    return null;
  }
};

// ─── Hint Points ──────────────────────────────────────────────────────────────

const MAX_HINT_POINTS = 15;

export const getHintPoints = async () => {
  try {
    const lastRefresh = await AsyncStorage.getItem(KEYS.LAST_HINT_REFRESH);
    const today = new Date().toDateString();

    if (lastRefresh !== today) {
      await AsyncStorage.setItem(KEYS.HINT_POINTS, String(MAX_HINT_POINTS));
      await AsyncStorage.setItem(KEYS.LAST_HINT_REFRESH, today);
      return MAX_HINT_POINTS;
    }

    const points = await AsyncStorage.getItem(KEYS.HINT_POINTS);
    return points !== null ? parseInt(points) : MAX_HINT_POINTS;
  } catch {
    return MAX_HINT_POINTS;
  }
};

export const spendHintPoints = async (cost) => {
  try {
    const current = await getHintPoints();
    if (current < cost) return false;
    await AsyncStorage.setItem(KEYS.HINT_POINTS, String(current - cost));
    return true;
  } catch {
    return false;
  }
};

// ─── Onboarding ───────────────────────────────────────────────────────────────

export const isOnboardingDone = async () => {
  try {
    const val = await AsyncStorage.getItem(KEYS.ONBOARDING_DONE);
    return val === 'true';
  } catch {
    return false;
  }
};

export const setOnboardingDone = async () => {
  await AsyncStorage.setItem(KEYS.ONBOARDING_DONE, 'true');
};

// ─── Stats helpers ────────────────────────────────────────────────────────────

export const getStats = async () => {
  try {
    const [profile, words, sessions] = await Promise.all([
      getProfile(),
      getWords(),
      getSessions(),
    ]);

    const totalWords = words.length;
    const masteredWords = words.filter((w) => w.status === 'mastered').length;
    const hardWords = words.filter((w) => w.status === 'hard').length;
    const learningWords = words.filter(
      (w) => w.status === 'learning' || w.status === 'new'
    ).length;

    // Today's study time
    const today = new Date().toDateString();
    const todaySessions = sessions.filter(
      (s) => new Date(s.date).toDateString() === today
    );
    const todayMinutes = todaySessions.reduce((sum, s) => sum + (s.duration || 0), 0) / 60;

    // Weekly data (last 7 days)
    const weeklyData = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toDateString();
      const daySessions = sessions.filter(
        (s) => new Date(s.date).toDateString() === dateStr
      );
      const dayMinutes = daySessions.reduce((sum, s) => sum + (s.duration || 0), 0) / 60;
      weeklyData.push({
        date: d,
        label: d.toLocaleDateString('en', { weekday: 'short' }),
        minutes: Math.round(dayMinutes),
        xp: daySessions.reduce((sum, s) => sum + (s.xpEarned || 0), 0),
      });
    }

    return {
      streak: profile?.streak || 0,
      totalXP: profile?.totalXP || 0,
      level: profile?.level || 'beginner',
      totalWords,
      masteredWords,
      hardWords,
      learningWords,
      todayMinutes: Math.round(todayMinutes),
      weeklyData,
    };
  } catch {
    return null;
  }
};

// ─── Clear all data ───────────────────────────────────────────────────────────

export const clearAllData = async () => {
  try {
    const allKeys = Object.values(KEYS);
    await AsyncStorage.multiRemove(allKeys);
    return true;
  } catch {
    return false;
  }
};
