import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

const NOTIFICATION_MESSAGES = [
  { title: '🦉 نادر يناديك!', body: 'وقت المراجعة! حافظ على سلسلتك 🔥' },
  { title: '📚 لا تنسى كلماتك!', body: 'دماغك جاهز للتعلم؟ تعال نراجع! 💪' },
  { title: '🔥 سلسلتك في خطر!', body: 'راجع اليوم وحافظ على streak تعبت عشانه!' },
  { title: '⭐ وقت ذهبي للتعلم!', body: 'الكلمات الجديدة في انتظارك 🌟' },
  { title: '🎯 هدف اليوم!', body: 'راجع 7 كلمات وأكمل التحدي 🏆' },
];

export const requestNotificationPermission = async () => {
  if (!Device.isDevice) return false;

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') return false;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'Nader Reminders',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#7C3AED',
    });
  }

  return true;
};

export const scheduleDailyReminder = async (hour = 20, minute = 0) => {
  try {
    // Cancel existing
    await Notifications.cancelAllScheduledNotificationsAsync();

    const msg = NOTIFICATION_MESSAGES[Math.floor(Math.random() * NOTIFICATION_MESSAGES.length)];

    await Notifications.scheduleNotificationAsync({
      content: {
        title: msg.title,
        body: msg.body,
        sound: true,
        color: '#7C3AED',
      },
      trigger: {
        hour,
        minute,
        repeats: true,
      },
    });

    return true;
  } catch {
    return false;
  }
};

export const cancelAllNotifications = async () => {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    return true;
  } catch {
    return false;
  }
};

export const sendStreakNotification = async (streakDays) => {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: `🔥 ${streakDays} يوم متواصل!`,
        body: 'ممتاز! استمر في تحديك اليومي 💪',
        sound: true,
      },
      trigger: null, // Immediate
    });
  } catch {}
};

export const parseReminderTime = (timeStr) => {
  const [hour, minute] = timeStr.split(':').map(Number);
  return { hour: hour || 20, minute: minute || 0 };
};
