// Uses Pollinations.ai - completely free, no API key needed
// Falls back to Hugging Face if HF key is provided

const POLLINATIONS_URL = 'https://image.pollinations.ai/prompt';
const HF_API_URL = 'https://api-inference.huggingface.co/models';

export const generateWordImage = async (word, targetLanguage, hfApiKey = null) => {
  try {
    // Build a descriptive prompt for the word
    const prompt = `minimalist clean illustration representing the concept of "${word}" in ${targetLanguage}, 
    flat design, colorful, educational, no text, white background, digital art`;

    if (hfApiKey) {
      try {
        return await generateWithHuggingFace(prompt, hfApiKey);
      } catch {
        // Fallback to pollinations
      }
    }

    return generatePollinationsUrl(prompt);
  } catch {
    return null;
  }
};

const generatePollinationsUrl = (prompt) => {
  const encoded = encodeURIComponent(prompt);
  // Add seed for deterministic results and nologo=true
  const seed = Math.floor(Math.random() * 10000);
  return `${POLLINATIONS_URL}/${encoded}?width=512&height=512&seed=${seed}&nologo=true&model=flux`;
};

const generateWithHuggingFace = async (prompt, apiKey) => {
  const response = await fetch(
    `${HF_API_URL}/stabilityai/stable-diffusion-2-1`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          num_inference_steps: 20,
          guidance_scale: 7.5,
          width: 512,
          height: 512,
        },
      }),
    }
  );

  if (!response.ok) throw new Error('HF API error');

  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

// Prebuilt fallback image based on first letter (emoji-based placeholder)
export const getWordEmoji = (word) => {
  const emojiMap = {
    a: '🅰️', b: '🐝', c: '🌊', d: '🐉', e: '🦅',
    f: '🔥', g: '🌿', h: '🏠', i: '💡', j: '💎',
    k: '🔑', l: '🍃', m: '🌙', n: '⭐', o: '🌊',
    p: '🌸', q: '👑', r: '🌈', s: '✨', t: '🌳',
    u: '🦄', v: '🌺', w: '🌊', x: '✖️', y: '💛',
    z: '⚡',
  };
  const letter = word[0]?.toLowerCase() || 'a';
  return emojiMap[letter] || '📚';
};
