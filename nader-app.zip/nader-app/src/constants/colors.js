export const colors = {
  primary: '#7C3AED',
  primaryLight: '#EDE9FE',
  primaryMid: '#A78BFA',
  primaryDark: '#5B21B6',
  secondary: '#F97316',
  secondaryLight: '#FFF7ED',
  teal: '#14B8A6',
  tealLight: '#F0FDFA',
  success: '#22C55E',
  successLight: '#F0FDF4',
  error: '#EF4444',
  errorLight: '#FEF2F2',
  warning: '#F59E0B',
  warningLight: '#FFFBEB',
  hard: '#F97316',
  mastered: '#22C55E',
  background: '#FAFAFA',
  surface: '#FFFFFF',
  surfaceAlt: '#F8F7FF',
  text: '#1E293B',
  textSecondary: '#64748B',
  textLight: '#94A3B8',
  border: '#E2E8F0',
  borderPurple: '#DDD6FE',
  streak: '#FF6348',
  streakLight: '#FFF5F0',
  xp: '#F59E0B',
  xpLight: '#FFFBEB',
  hint: '#3B82F6',
  hintLight: '#EFF6FF',
  shadow: 'rgba(124, 58, 237, 0.15)',
  overlay: 'rgba(0,0,0,0.5)',
  white: '#FFFFFF',
  black: '#000000',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  full: 9999,
};

export const fontSize = {
  xs: 11,
  sm: 13,
  md: 15,
  lg: 17,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  hero: 42,
};

export const shadows = {
  small: {
    shadowColor: '#7C3AED',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  medium: {
    shadowColor: '#7C3AED',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 6,
  },
  large: {
    shadowColor: '#7C3AED',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 10,
  },
};
