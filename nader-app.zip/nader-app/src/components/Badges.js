import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
} from 'react-native';
import { colors, radius, fontSize } from '../constants/colors';
import { getLevelInfo, LEVEL_AVATARS } from '../services/SRSService';

// ─── Streak Badge ─────────────────────────────────────────────────────────────

export const StreakBadge = ({ streak = 0, size = 'medium', style }) => {
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (streak > 0) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, { toValue: 1.1, duration: 600, useNativeDriver: true }),
          Animated.timing(pulse, { toValue: 1.0, duration: 600, useNativeDriver: true }),
        ])
      ).start();
    }
  }, [streak]);

  const sizeConfig = {
    small: { container: 40, text: 12, emoji: 14 },
    medium: { container: 56, text: 14, emoji: 18 },
    large: { container: 72, text: 18, emoji: 24 },
  };

  const s = sizeConfig[size] || sizeConfig.medium;

  return (
    <Animated.View
      style={[
        styles.streakBadge,
        {
          width: s.container,
          height: s.container,
          borderRadius: s.container / 2,
          transform: [{ scale: pulse }],
          backgroundColor: streak > 0 ? colors.streakLight : '#F5F5F5',
          borderColor: streak > 0 ? colors.streak : '#DDD',
        },
        style,
      ]}
    >
      <Text style={{ fontSize: s.emoji }}>🔥</Text>
      <Text style={[styles.streakNumber, { fontSize: s.text, color: streak > 0 ? colors.streak : colors.textLight }]}>
        {streak}
      </Text>
    </Animated.View>
  );
};

// ─── XP Progress Bar ──────────────────────────────────────────────────────────

export const XPBar = ({ totalXP = 0, showLabel = true, style }) => {
  const progressAnim = useRef(new Animated.Value(0)).current;
  const levelInfo = getLevelInfo(totalXP);

  useEffect(() => {
    Animated.timing(progressAnim, {
      toValue: levelInfo.progress,
      duration: 1000,
      useNativeDriver: false,
    }).start();
  }, [totalXP]);

  return (
    <View style={[styles.xpContainer, style]}>
      {showLabel && (
        <View style={styles.xpHeader}>
          <Text style={styles.xpLevel}>
            {LEVEL_AVATARS[levelInfo.current]} {levelInfo.current}
          </Text>
          <Text style={styles.xpPoints}>
            {levelInfo.isMaxLevel ? '🏆 MAX' : `${levelInfo.xpToNext} XP →`}
          </Text>
        </View>
      )}
      <View style={styles.xpBarBg}>
        <Animated.View
          style={[
            styles.xpBarFill,
            {
              width: progressAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ['0%', '100%'],
              }),
            },
          ]}
        />
      </View>
    </View>
  );
};

// ─── Level Badge ──────────────────────────────────────────────────────────────

export const LevelBadge = ({ level, xp, style }) => {
  const levelInfo = getLevelInfo(xp || 0);
  const currentLevel = level || levelInfo.current;
  const avatar = LEVEL_AVATARS[currentLevel] || '🌱';

  const levelColors = {
    beginner: { bg: '#F0FDF4', border: '#22C55E', text: '#15803D' },
    learner: { bg: '#EFF6FF', border: '#3B82F6', text: '#1D4ED8' },
    writer: { bg: '#F5F3FF', border: '#7C3AED', text: '#5B21B6' },
    speaker: { bg: '#FFF7ED', border: '#F97316', text: '#C2410C' },
    native: { bg: '#FFFBEB', border: '#F59E0B', text: '#B45309' },
  };

  const lc = levelColors[currentLevel] || levelColors.beginner;

  return (
    <View
      style={[
        styles.levelBadge,
        { backgroundColor: lc.bg, borderColor: lc.border },
        style,
      ]}
    >
      <Text style={styles.levelEmoji}>{avatar}</Text>
      <Text style={[styles.levelText, { color: lc.text }]}>{currentLevel}</Text>
    </View>
  );
};

// ─── XP Burst (animated +XP popup) ───────────────────────────────────────────

export const XPBurst = ({ xp, visible, onComplete }) => {
  const translateY = useRef(new Animated.Value(0)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(0.5)).current;

  useEffect(() => {
    if (visible) {
      translateY.setValue(0);
      opacity.setValue(0);
      scale.setValue(0.5);

      Animated.parallel([
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.spring(scale, { toValue: 1.2, useNativeDriver: true }),
        Animated.timing(translateY, { toValue: -60, duration: 1200, useNativeDriver: true }),
      ]).start(() => {
        Animated.timing(opacity, { toValue: 0, duration: 300, useNativeDriver: true }).start(onComplete);
      });
    }
  }, [visible]);

  if (!visible) return null;

  return (
    <Animated.View
      style={[
        styles.xpBurst,
        { opacity, transform: [{ translateY }, { scale }] },
      ]}
    >
      <Text style={styles.xpBurstText}>+{xp} XP ⭐</Text>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  streakBadge: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    gap: 2,
  },
  streakNumber: {
    fontWeight: '800',
    lineHeight: 14,
  },
  xpContainer: {
    width: '100%',
  },
  xpHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  xpLevel: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.primary,
    textTransform: 'capitalize',
  },
  xpPoints: {
    fontSize: 12,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  xpBarBg: {
    height: 10,
    backgroundColor: colors.primaryLight,
    borderRadius: radius.full,
    overflow: 'hidden',
  },
  xpBarFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: radius.full,
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: radius.full,
    borderWidth: 2,
    gap: 4,
  },
  levelEmoji: {
    fontSize: 14,
  },
  levelText: {
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'capitalize',
  },
  xpBurst: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: colors.xp,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: radius.full,
    zIndex: 100,
  },
  xpBurstText: {
    color: '#FFF',
    fontWeight: '800',
    fontSize: 16,
  },
});
