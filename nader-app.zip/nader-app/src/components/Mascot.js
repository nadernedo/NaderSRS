import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
} from 'react-native';
import { colors } from '../constants/colors';

const MOODS = {
  happy: { emoji: '🦉', bg: colors.primaryLight, border: colors.primary },
  excited: { emoji: '🎉', bg: colors.xpLight, border: colors.xp },
  thinking: { emoji: '🤔', bg: colors.tealLight, border: colors.teal },
  celebrating: { emoji: '🏆', bg: colors.xpLight, border: colors.xp },
  sad: { emoji: '😅', bg: colors.errorLight, border: colors.error },
  sleeping: { emoji: '😴', bg: '#F0F0F0', border: '#CCCCCC' },
  loading: { emoji: '⚙️', bg: colors.primaryLight, border: colors.primary },
  fire: { emoji: '🔥', bg: colors.streakLight, border: colors.streak },
};

const Mascot = ({
  mood = 'happy',
  size = 'medium',
  message = null,
  onPress = null,
  style,
  animate = true,
}) => {
  const bounce = useRef(new Animated.Value(0)).current;
  const rotate = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(1)).current;
  const [currentMood, setCurrentMood] = useState(mood);

  useEffect(() => {
    setCurrentMood(mood);
    if (mood === 'celebrating') {
      celebrateAnimation();
    } else if (mood === 'loading') {
      loadingAnimation();
    } else if (animate) {
      idleAnimation();
    }
  }, [mood]);

  const idleAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(bounce, {
          toValue: -8,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(bounce, {
          toValue: 0,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const celebrateAnimation = () => {
    Animated.sequence([
      Animated.timing(scale, {
        toValue: 1.3,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(scale, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.loop(
        Animated.sequence([
          Animated.timing(rotate, {
            toValue: 1,
            duration: 300,
            useNativeDriver: true,
          }),
          Animated.timing(rotate, {
            toValue: -1,
            duration: 300,
            useNativeDriver: true,
          }),
          Animated.timing(rotate, {
            toValue: 0,
            duration: 300,
            useNativeDriver: true,
          }),
        ]),
        { iterations: 3 }
      ),
    ]).start();
  };

  const loadingAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(rotate, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(rotate, {
          toValue: -1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(rotate, {
          toValue: 0,
          duration: 500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const spin = rotate.interpolate({
    inputRange: [-1, 0, 1],
    outputRange: ['-15deg', '0deg', '15deg'],
  });

  const sizes = {
    small: { container: 60, emoji: 28, borderRadius: 20 },
    medium: { container: 90, emoji: 42, borderRadius: 30 },
    large: { container: 120, emoji: 56, borderRadius: 40 },
  };

  const s = sizes[size] || sizes.medium;
  const moodConfig = MOODS[currentMood] || MOODS.happy;

  const mascotComponent = (
    <Animated.View
      style={[
        styles.mascot,
        {
          width: s.container,
          height: s.container,
          borderRadius: s.borderRadius,
          backgroundColor: moodConfig.bg,
          borderColor: moodConfig.border,
          transform: [
            { translateY: bounce },
            { rotate: spin },
            { scale },
          ],
        },
        style,
      ]}
    >
      <Text style={{ fontSize: s.emoji }}>{moodConfig.emoji}</Text>
    </Animated.View>
  );

  return (
    <View style={styles.wrapper}>
      {onPress ? (
        <TouchableOpacity onPress={onPress} activeOpacity={0.8}>
          {mascotComponent}
        </TouchableOpacity>
      ) : (
        mascotComponent
      )}
      {message && (
        <View style={styles.bubble}>
          <View style={styles.bubbleTail} />
          <Text style={styles.bubbleText}>{message}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'center',
  },
  mascot: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  bubble: {
    marginTop: 12,
    backgroundColor: colors.surface,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderWidth: 2,
    borderColor: colors.borderPurple,
    maxWidth: 280,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  bubbleTail: {
    position: 'absolute',
    top: -8,
    left: '50%',
    marginLeft: -8,
    width: 0,
    height: 0,
    borderLeftWidth: 8,
    borderRightWidth: 8,
    borderBottomWidth: 8,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: colors.borderPurple,
  },
  bubbleText: {
    fontSize: 14,
    color: colors.text,
    textAlign: 'center',
    fontWeight: '500',
    lineHeight: 20,
  },
});

export default Mascot;
