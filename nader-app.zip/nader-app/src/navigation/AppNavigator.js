import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { colors } from '../constants/colors';
import { t } from '../constants/i18n';

import OnboardingScreen from '../screens/OnboardingScreen';
import HomeScreen from '../screens/HomeScreen';
import AddWordScreen from '../screens/AddWordScreen';
import ReviewScreen from '../screens/ReviewScreen';
import ParagraphChallengeScreen from '../screens/ParagraphChallengeScreen';
import StatsScreen from '../screens/StatsScreen';
import SettingsScreen from '../screens/SettingsScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const TabIcon = ({ emoji, label, focused }) => (
  <View style={[styles.tabItem, focused && styles.tabItemFocused]}>
    <Text style={[styles.tabEmoji, focused && styles.tabEmojiFocused]}>{emoji}</Text>
    <Text style={[styles.tabLabel, focused && styles.tabLabelFocused]}>{label}</Text>
  </View>
);

const MainTabs = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarStyle: styles.tabBar,
      tabBarShowLabel: false,
    }}
  >
    <Tab.Screen
      name="Home"
      component={HomeScreen}
      options={{
        tabBarIcon: ({ focused }) => (
          <TabIcon emoji="🏠" label={t('addWords').split(' ')[0]} focused={focused} />
        ),
      }}
    />
    <Tab.Screen
      name="AddWord"
      component={AddWordScreen}
      options={{
        tabBarIcon: ({ focused }) => (
          <TabIcon emoji="➕" label="أضف" focused={focused} />
        ),
      }}
    />
    <Tab.Screen
      name="Review"
      component={ReviewScreen}
      options={{
        tabBarIcon: ({ focused }) => (
          <TabIcon emoji="🎯" label="راجع" focused={focused} />
        ),
      }}
    />
    <Tab.Screen
      name="Stats"
      component={StatsScreen}
      options={{
        tabBarIcon: ({ focused }) => (
          <TabIcon emoji="📊" label="إحصاء" focused={focused} />
        ),
      }}
    />
    <Tab.Screen
      name="Settings"
      component={SettingsScreen}
      options={{
        tabBarIcon: ({ focused }) => (
          <TabIcon emoji="⚙️" label="إعدادات" focused={focused} />
        ),
      }}
    />
  </Tab.Navigator>
);

const AppNavigator = ({ isOnboarded }) => (
  <NavigationContainer>
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>
      {!isOnboarded ? (
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      ) : (
        <>
          <Stack.Screen name="MainTabs" component={MainTabs} />
          <Stack.Screen
            name="ParagraphChallenge"
            component={ParagraphChallengeScreen}
            options={{ animation: 'slide_from_bottom' }}
          />
        </>
      )}
    </Stack.Navigator>
  </NavigationContainer>
);

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    height: 72,
    paddingBottom: 8,
    paddingTop: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 8,
  },
  tabItem: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  tabItemFocused: {
    backgroundColor: colors.primaryLight,
  },
  tabEmoji: {
    fontSize: 22,
  },
  tabEmojiFocused: {
    fontSize: 24,
  },
  tabLabel: {
    fontSize: 10,
    color: colors.textLight,
    fontWeight: '500',
  },
  tabLabelFocused: {
    color: colors.primary,
    fontWeight: '700',
  },
});

export default AppNavigator;
