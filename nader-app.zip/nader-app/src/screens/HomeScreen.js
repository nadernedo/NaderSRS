import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';
import { colors, radius, spacing, fontSize, shadows } from '../constants/colors';
import { getProfile, getDueWords, getWords, updateStreak, getHintPoints } from '../services/StorageService';
import { getLevelInfo, LEVEL_AVATARS } from '../services/SRSService';
import { t, setLanguage } from '../constants/i18n';
import Mascot from '../components/Mascot';
import { StreakBadge, XPBar, LevelBadge } from '../components/Badges';

const getGreeting = (name) => {
  const hour = new Date().getHours();
  let greeting = '';
  if (hour < 12) greeting = 'صباح الخير';
  else if (hour < 17) greeting = 'مساء الخير';
  else if (hour < 21) greeting = 'مساء النور';
  else greeting = 'تصبح على خير';
  return `${greeting}، ${name}! 👋`;
};

const getMascotMood = (streak, dueCount) => {
  if (streak > 7) return 'fire';
  if (dueCount === 0) return 'celebrating';
  if (streak === 0) return 'happy';
  return 'happy';
};

const getMascotMessage = (name, streak, dueCount, totalWords) => {
  if (totalWords === 0) return `مرحباً ${name}! أضف أول كلمة لك لنبدأ الرحلة 🌟`;
  if (dueCount === 0) return `أحسنت ${name}! أكملت مراجعاتك اليوم 🎉`;
  if (streak > 7) return `${streak} يوم متواصل! أنت رائع ${name}! 🔥`;
  if (dueCount > 0) return `لديك ${dueCount} بطاقات تنتظرك! يلا ${name}! 🎯`;
  return `مرحباً ${name}! جاهز للتعلم؟ 🦉`;
};

export default function HomeScreen({ navigation }) {
  const [profile, setProfile] = useState(null);
  const [dueWords, setDueWords] = useState([]);
  const [totalWords, setTotalWords] = useState(0);
  const [hintPoints, setHintPoints] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const [profileData, due, allWords, hints] = await Promise.all([
        getProfile(),
        getDueWords(7),
        getWords(),
        getHintPoints(),
      ]);

      if (profileData) {
        setLanguage(profileData.appLanguage || 'ar');
        setProfile(profileData);
      }
      setDueWords(due);
      setTotalWords(allWords.length);
      setHintPoints(hints);
    } catch (e) {
      console.error(e);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  if (!profile) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>🦉</Text>
      </View>
    );
  }

  const levelInfo = getLevelInfo(profile.totalXP || 0);
  const dueCount = dueWords.length;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
    >
      {/* Header */}
      <LinearGradient colors={['#7C3AED', '#9F67FA']} style={styles.header}>
        <View style={styles.headerTop}>
          <View style={styles.greetingRow}>
            <Text style={styles.greeting}>{getGreeting(profile.name)}</Text>
          </View>
          <StreakBadge streak={profile.streak || 0} size="medium" />
        </View>

        {/* XP Bar */}
        <View style={styles.xpSection}>
          <XPBar totalXP={profile.totalXP || 0} showLabel />
        </View>
      </LinearGradient>

      {/* Mascot Section */}
      <View style={styles.mascotSection}>
        <Mascot
          mood={getMascotMood(profile.streak, dueCount)}
          size="large"
          message={getMascotMessage(profile.name, profile.streak, dueCount, totalWords)}
          animate
        />
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        <StatCard
          emoji="📚"
          value={totalWords}
          label="كلمة"
          color={colors.primary}
          bgColor={colors.primaryLight}
        />
        <StatCard
          emoji="✅"
          value={dueWords.filter((w) => w.status === 'mastered').length}
          label="متقن"
          color={colors.success}
          bgColor={colors.successLight}
        />
        <StatCard
          emoji="💡"
          value={hintPoints}
          label="تلميح"
          color={colors.hint}
          bgColor={colors.hintLight}
        />
        <StatCard
          emoji={LEVEL_AVATARS[levelInfo.current]}
          value={levelInfo.current}
          label="المستوى"
          color={colors.secondary}
          bgColor={colors.secondaryLight}
          isText
        />
      </View>

      {/* Today's Session Card */}
      {dueCount > 0 ? (
        <TouchableOpacity
          style={styles.reviewCard}
          onPress={() => navigation.navigate('Review')}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={['#7C3AED', '#6D28D9']}
            style={styles.reviewCardGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.reviewCardLeft}>
              <Text style={styles.reviewCardTitle}>جلسة اليوم 🎯</Text>
              <Text style={styles.reviewCardSubtitle}>{dueCount} بطاقات جاهزة للمراجعة</Text>
              <View style={styles.reviewCardDots}>
                {Array(Math.min(dueCount, 7)).fill(0).map((_, i) => (
                  <View key={i} style={styles.reviewDot} />
                ))}
              </View>
            </View>
            <View style={styles.reviewCardRight}>
              <Text style={styles.reviewCardArrow}>🚀</Text>
              <Text style={styles.reviewCardButtonText}>ابدأ!</Text>
            </View>
          </LinearGradient>
        </TouchableOpacity>
      ) : (
        <View style={styles.allDoneCard}>
          <Text style={styles.allDoneEmoji}>🎊</Text>
          <Text style={styles.allDoneTitle}>أحسنت! أكملت مراجعاتك اليوم</Text>
          <Text style={styles.allDoneSubtitle}>تعال غداً لمراجعة المزيد</Text>
        </View>
      )}

      {/* Quick Actions */}
      <Text style={styles.sectionTitle}>إجراءات سريعة</Text>
      <View style={styles.actionsGrid}>
        <ActionButton
          emoji="➕"
          label="أضف كلمات جديدة"
          sublabel="فردية أو متعددة"
          color={colors.teal}
          bgColor={colors.tealLight}
          onPress={() => navigation.navigate('AddWord')}
        />
        <ActionButton
          emoji="📊"
          label="إحصائياتك"
          sublabel="تقدمك وإنجازاتك"
          color={colors.secondary}
          bgColor={colors.secondaryLight}
          onPress={() => navigation.navigate('Stats')}
        />
      </View>

      {/* Level Progress */}
      {!levelInfo.isMaxLevel && (
        <View style={styles.levelCard}>
          <View style={styles.levelCardHeader}>
            <Text style={styles.levelCardTitle}>
              {LEVEL_AVATARS[levelInfo.current]} {levelInfo.current}
            </Text>
            <Text style={styles.levelCardXP}>{levelInfo.xpToNext} XP للمستوى التالي</Text>
          </View>
          <View style={styles.levelProgressBg}>
            <View
              style={[styles.levelProgressFill, { width: `${levelInfo.progress * 100}%` }]}
            />
          </View>
        </View>
      )}

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const StatCard = ({ emoji, value, label, color, bgColor, isText }) => (
  <View style={[styles.statCard, { backgroundColor: bgColor }]}>
    <Text style={styles.statEmoji}>{emoji}</Text>
    <Text style={[styles.statValue, { color, fontSize: isText ? 10 : 18 }]}>
      {value}
    </Text>
    <Text style={[styles.statLabel, { color }]}>{label}</Text>
  </View>
);

const ActionButton = ({ emoji, label, sublabel, color, bgColor, onPress }) => (
  <TouchableOpacity
    style={[styles.actionButton, { backgroundColor: bgColor, borderColor: color + '40' }]}
    onPress={onPress}
    activeOpacity={0.8}
  >
    <Text style={styles.actionEmoji}>{emoji}</Text>
    <Text style={[styles.actionLabel, { color }]}>{label}</Text>
    <Text style={styles.actionSublabel}>{sublabel}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    paddingBottom: 24,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  loadingText: {
    fontSize: 64,
  },
  header: {
    paddingTop: 56,
    paddingBottom: 28,
    paddingHorizontal: spacing.lg,
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  greetingRow: {
    flex: 1,
  },
  greeting: {
    fontSize: fontSize.xl,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  xpSection: {
    marginTop: 4,
  },
  mascotSection: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
  },
  statsRow: {
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    borderRadius: radius.lg,
    paddingVertical: spacing.sm,
    gap: 2,
  },
  statEmoji: {
    fontSize: 20,
  },
  statValue: {
    fontWeight: '800',
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'center',
  },
  reviewCard: {
    marginHorizontal: spacing.md,
    borderRadius: radius.xl,
    overflow: 'hidden',
    marginBottom: spacing.md,
    ...shadows.large,
  },
  reviewCardGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.lg,
  },
  reviewCardLeft: {
    flex: 1,
  },
  reviewCardTitle: {
    fontSize: fontSize.xl,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  reviewCardSubtitle: {
    fontSize: fontSize.sm,
    color: 'rgba(255,255,255,0.8)',
    marginBottom: 12,
  },
  reviewCardDots: {
    flexDirection: 'row',
    gap: 6,
  },
  reviewDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.6)',
  },
  reviewCardRight: {
    alignItems: 'center',
    gap: 4,
  },
  reviewCardArrow: {
    fontSize: 36,
  },
  reviewCardButtonText: {
    fontSize: fontSize.md,
    fontWeight: '800',
    color: '#FFD700',
  },
  allDoneCard: {
    marginHorizontal: spacing.md,
    backgroundColor: colors.successLight,
    borderRadius: radius.xl,
    padding: spacing.lg,
    alignItems: 'center',
    marginBottom: spacing.md,
    borderWidth: 2,
    borderColor: colors.success + '40',
  },
  allDoneEmoji: {
    fontSize: 48,
    marginBottom: 8,
  },
  allDoneTitle: {
    fontSize: fontSize.lg,
    fontWeight: '700',
    color: colors.success,
    textAlign: 'center',
  },
  allDoneSubtitle: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: '700',
    color: colors.text,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
  actionsGrid: {
    flexDirection: 'row',
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  actionButton: {
    flex: 1,
    borderRadius: radius.xl,
    padding: spacing.md,
    borderWidth: 2,
    gap: 4,
    ...shadows.small,
  },
  actionEmoji: {
    fontSize: 28,
  },
  actionLabel: {
    fontSize: fontSize.sm,
    fontWeight: '700',
  },
  actionSublabel: {
    fontSize: 11,
    color: colors.textSecondary,
  },
  levelCard: {
    marginHorizontal: spacing.md,
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    padding: spacing.md,
    ...shadows.small,
  },
  levelCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  levelCardTitle: {
    fontSize: fontSize.md,
    fontWeight: '700',
    color: colors.primary,
    textTransform: 'capitalize',
  },
  levelCardXP: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
  },
  levelProgressBg: {
    height: 8,
    backgroundColor: colors.primaryLight,
    borderRadius: radius.full,
  },
  levelProgressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: radius.full,
  },
});
