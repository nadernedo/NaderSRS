import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, Animated, Image, Alert, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Speech from 'expo-speech';
import { useFocusEffect } from '@react-navigation/native';
import { colors, radius, spacing, fontSize, shadows } from '../constants/colors';
import { getDueWords, getProfile, updateProfile, getHintPoints, spendHintPoints, saveSession } from '../services/StorageService';
import { processReview, checkAnswer, generateSessionId } from '../services/SRSService';
import { generateReviewCard } from '../services/GroqService';
import { getWordEmoji } from '../services/ImageService';
import Mascot from '../components/Mascot';
import { XPBurst } from '../components/Badges';

const SESSION_SIZE = 7;
const HINT_COSTS = { firstLetter: 3, wordLength: 1 };

export default function ReviewScreen({ navigation }) {
  const [profile, setProfile] = useState(null);
  const [words, setWords] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [result, setResult] = useState(null); // null | 'correct' | 'almost' | 'wrong'
  const [showRating, setShowRating] = useState(false);
  const [hintPoints, setHintPoints] = useState(0);
  const [usedHints, setUsedHints] = useState([]);
  const [sessionStart] = useState(Date.now());
  const [xpEarned, setXpEarned] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [xpBurst, setXpBurst] = useState({ visible: false, amount: 0 });
  const [reviewContent, setReviewContent] = useState(null);
  const [loadingCard, setLoadingCard] = useState(false);
  const [mascotMood, setMascotMood] = useState('happy');
  const [mascotMsg, setMascotMsg] = useState('');
  const [sessionDone, setSessionDone] = useState(false);

  const shakeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(0)).current;
  const inputRef = useRef(null);

  useFocusEffect(
    useCallback(() => {
      loadSession();
    }, [])
  );

  const loadSession = async () => {
    const [p, due, hints] = await Promise.all([
      getProfile(), getDueWords(SESSION_SIZE), getHintPoints(),
    ]);
    setProfile(p);
    setWords(due);
    setHintPoints(hints);
    setCurrentIndex(0);
    setResult(null);
    setSessionDone(false);
    setXpEarned(0);
    setCorrectCount(0);
    if (due.length > 0) loadCardContent(due[0], p);
  };

  const loadCardContent = async (word, p) => {
    setLoadingCard(true);
    setReviewContent(null);
    const profile = p || await getProfile();
    const apiKey = profile?.groqApiKey || '';
    if (apiKey) {
      try {
        const content = await generateReviewCard(word.word, profile?.targetLanguage || 'en', apiKey);
        if (content) { setReviewContent(content); setLoadingCard(false); return; }
      } catch {}
    }
    // Fallback: blank word in original content
    const blanked = word.word.toLowerCase();
    const blankDef = (word.definition || '').replace(new RegExp(blanked, 'gi'), '___');
    const blankExamples = (word.examples || []).map(ex =>
      ex.replace(new RegExp(blanked, 'gi'), '___')
    );
    setReviewContent({ definition: blankDef, examples: blankExamples });
    setLoadingCard(false);
  };

  const shake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 80, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 80, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 6, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const slideNext = (cb) => {
    Animated.timing(slideAnim, { toValue: -400, duration: 250, useNativeDriver: true }).start(() => {
      slideAnim.setValue(400);
      cb();
      Animated.timing(slideAnim, { toValue: 0, duration: 250, useNativeDriver: true }).start();
    });
  };

  const checkUserAnswer = () => {
    if (!answer.trim()) return;
    const word = words[currentIndex];
    const { result: res } = checkAnswer(answer, word.word);
    setResult(res);
    if (res === 'correct' || res === 'almost') {
      setMascotMood('celebrating');
      setMascotMsg(res === 'correct' ? '🎉 صحيح! ممتاز!' : '🤏 قريب جداً!');
      setShowRating(true);
    } else {
      shake();
      setMascotMood('sad');
      setMascotMsg('حاول مرة أخرى! 💪');
      setShowRating(true);
    }
  };

  const handleRating = async (rating) => {
    const word = words[currentIndex];
    const updated = await processReview(word, rating);
    const xp = updated.xpEarned || 0;

    if (rating !== 'hard') {
      setCorrectCount(c => c + 1);
      setXpEarned(e => e + xp);
      setXpBurst({ visible: true, amount: xp });
      await updateProfile({ totalXP: (profile?.totalXP || 0) + xp });
    }

    const next = currentIndex + 1;
    if (next >= words.length) {
      finishSession(xpEarned + xp);
      return;
    }

    slideNext(() => {
      setCurrentIndex(next);
      setAnswer('');
      setResult(null);
      setShowRating(false);
      setUsedHints([]);
      setMascotMood('happy');
      setMascotMsg('');
      loadCardContent(words[next], profile);
    });
  };

  const finishSession = async (totalXP) => {
    const duration = Math.floor((Date.now() - sessionStart) / 1000);
    await saveSession({
      id: generateSessionId(),
      date: new Date().toISOString(),
      wordsReviewed: words.length,
      correctCount,
      xpEarned: totalXP,
      duration,
    });
    setSessionDone(true);
  };

  const useHint = async (type) => {
    const cost = HINT_COSTS[type];
    if (hintPoints < cost) {
      Alert.alert('نقاط غير كافية', `تحتاج ${cost} نقاط. لديك ${hintPoints} فقط.`);
      return;
    }
    const spent = await spendHintPoints(cost);
    if (spent) {
      setHintPoints(p => p - cost);
      setUsedHints(h => [...h, type]);
    }
  };

  const speak = (text) => {
    const lang = profile?.targetLanguage || 'en';
    Speech.speak(text, { language: lang, rate: 0.85 });
  };

  // ─── Session Done Screen ──────────────────────────────────────────────────

  if (sessionDone) {
    return (
      <View style={styles.doneContainer}>
        <LinearGradient colors={['#7C3AED', '#9F67FA']} style={styles.doneHeader}>
          <Mascot mood="celebrating" size="large" animate />
          <Text style={styles.doneTitleText}>انتهت الجلسة! 🏆</Text>
        </LinearGradient>
        <ScrollView contentContainerStyle={styles.doneContent}>
          <View style={styles.doneStats}>
            {[
              { label: 'كلمات راجعتها', value: words.length, emoji: '📚' },
              { label: 'إجابات صحيحة', value: correctCount, emoji: '✅' },
              { label: 'نقاط XP', value: xpEarned, emoji: '⭐' },
            ].map((s, i) => (
              <View key={i} style={styles.doneStat}>
                <Text style={styles.doneStatEmoji}>{s.emoji}</Text>
                <Text style={styles.doneStatValue}>{s.value}</Text>
                <Text style={styles.doneStatLabel}>{s.label}</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity
            style={styles.challengeBtn}
            onPress={() => navigation.navigate('ParagraphChallenge', { words: words.map(w => w.word) })}
          >
            <LinearGradient colors={['#F97316', '#DC2626']} style={styles.challengeBtnGradient}>
              <Text style={styles.challengeBtnEmoji}>👾</Text>
              <View>
                <Text style={styles.challengeBtnTitle}>تحدي البراجراف!</Text>
                <Text style={styles.challengeBtnSub}>استخدم كلماتك في فقرة</Text>
              </View>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.homeBtn} onPress={() => navigation.navigate('Home')}>
            <Text style={styles.homeBtnText}>🏠 الرئيسية</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  // ─── No words state ────────────────────────────────────────────────────────

  if (words.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <LinearGradient colors={['#7C3AED', '#9F67FA']} style={styles.emptyHeader}>
          <Text style={styles.emptyHeaderText}>🎯 المراجعة</Text>
        </LinearGradient>
        <View style={styles.emptyBody}>
          <Mascot mood="sleeping" size="large" message="لا توجد بطاقات للمراجعة الآن! تعال لاحقاً 😴" />
          <TouchableOpacity style={styles.addWordBtn} onPress={() => navigation.navigate('AddWord')}>
            <Text style={styles.addWordBtnText}>➕ أضف كلمات جديدة</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const currentWord = words[currentIndex];

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={['#7C3AED', '#9F67FA']} style={styles.header}>
        <View style={styles.headerRow}>
          <Text style={styles.headerTitle}>🎯 المراجعة</Text>
          <View style={styles.progressPills}>
            {words.map((_, i) => (
              <View key={i} style={[styles.progressPill,
                i < currentIndex && styles.progressPillDone,
                i === currentIndex && styles.progressPillCurrent,
              ]} />
            ))}
          </View>
          <Text style={styles.progressText}>{currentIndex + 1}/{words.length}</Text>
        </View>
        <View style={styles.hintRow}>
          <Text style={styles.hintPointsText}>💡 {hintPoints} تلميح</Text>
        </View>
      </LinearGradient>

      <ScrollView style={styles.scroll} keyboardShouldPersistTaps="handled">
        {/* Mascot */}
        {mascotMsg ? (
          <View style={styles.mascotRow}>
            <Mascot mood={mascotMood} size="small" message={mascotMsg} />
          </View>
        ) : null}

        {/* Card */}
        <Animated.View style={[styles.card, { transform: [{ translateX: slideAnim }] }]}>
          {/* Word image */}
          {currentWord.imageUrl && (
            <Image source={{ uri: currentWord.imageUrl }} style={styles.cardImage} resizeMode="cover" />
          )}

          {loadingCard ? (
            <View style={styles.cardLoading}>
              <ActivityIndicator color={colors.primary} />
              <Text style={styles.cardLoadingText}>يولّد بطاقة جديدة... 🤔</Text>
            </View>
          ) : (
            <>
              {/* Definition */}
              <View style={styles.cardSection}>
                <View style={styles.cardSectionHeader}>
                  <Text style={styles.cardSectionLabel}>📖 التعريف</Text>
                  <TouchableOpacity onPress={() => speak(reviewContent?.definition || '')}>
                    <Text style={styles.speakBtn}>🔊</Text>
                  </TouchableOpacity>
                </View>
                <Text style={styles.cardDefinition}>{reviewContent?.definition || '...'}</Text>
              </View>

              {/* Examples */}
              {(reviewContent?.examples || []).map((ex, i) => (
                <View key={i} style={styles.cardSection}>
                  <View style={styles.cardSectionHeader}>
                    <Text style={styles.cardSectionLabel}>💬 مثال {i + 1}</Text>
                    <TouchableOpacity onPress={() => speak(ex)}>
                      <Text style={styles.speakBtn}>🔊</Text>
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.cardExample}>{ex}</Text>
                </View>
              ))}
            </>
          )}
        </Animated.View>

        {/* Hints */}
        <View style={styles.hintsRow}>
          <TouchableOpacity
            style={[styles.hintBtn, usedHints.includes('firstLetter') && styles.hintBtnUsed]}
            onPress={() => !usedHints.includes('firstLetter') && useHint('firstLetter')}
          >
            <Text style={styles.hintBtnText}>
              {usedHints.includes('firstLetter')
                ? `الحرف الأول: ${currentWord.word[0].toUpperCase()}`
                : `🔤 أول حرف (${HINT_COSTS.firstLetter}💡)`}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.hintBtn, usedHints.includes('wordLength') && styles.hintBtnUsed]}
            onPress={() => !usedHints.includes('wordLength') && useHint('wordLength')}
          >
            <Text style={styles.hintBtnText}>
              {usedHints.includes('wordLength')
                ? `الأحرف: ${currentWord.word.length}`
                : `🔢 عدد الحروف (${HINT_COSTS.wordLength}💡)`}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Answer Input */}
        {!showRating ? (
          <Animated.View style={[styles.answerSection, { transform: [{ translateX: shakeAnim }] }]}>
            <TextInput
              ref={inputRef}
              style={styles.answerInput}
              placeholder="اكتب الكلمة المخفية..."
              placeholderTextColor={colors.textLight}
              value={answer}
              onChangeText={setAnswer}
              autoCapitalize="none"
              returnKeyType="done"
              onSubmitEditing={checkUserAnswer}
            />
            <TouchableOpacity style={styles.checkBtn} onPress={checkUserAnswer}>
              <LinearGradient colors={['#7C3AED', '#5B21B6']} style={styles.checkBtnGradient}>
                <Text style={styles.checkBtnText}>✓ تحقق</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>
        ) : (
          <View style={styles.ratingSection}>
            {/* Result feedback */}
            <View style={[styles.resultBadge,
              result === 'correct' && styles.resultCorrect,
              result === 'almost' && styles.resultAlmost,
              result === 'wrong' && styles.resultWrong,
            ]}>
              <Text style={styles.resultText}>
                {result === 'correct' ? '🎉 صحيح!' : result === 'almost' ? '🤏 قريب جداً!' : '❌ الإجابة:'}
              </Text>
              {(result === 'almost' || result === 'wrong') && (
                <Text style={styles.correctAnswerText}>{currentWord.word}</Text>
              )}
            </View>

            {/* Self-rating */}
            <Text style={styles.ratingLabel}>كيف كان تذكرها؟</Text>
            <View style={styles.ratingBtns}>
              {[
                { key: 'easy', label: '😊 سهل', color: colors.success },
                { key: 'medium', label: '😐 متوسط', color: colors.warning },
                { key: 'hard', label: '😰 صعب', color: colors.error },
              ].map(r => (
                <TouchableOpacity
                  key={r.key}
                  style={[styles.ratingBtn, { borderColor: r.color }]}
                  onPress={() => handleRating(r.key)}
                >
                  <Text style={[styles.ratingBtnText, { color: r.color }]}>{r.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        <View style={{ height: 32 }} />
      </ScrollView>

      <XPBurst
        xp={xpBurst.amount}
        visible={xpBurst.visible}
        onComplete={() => setXpBurst({ visible: false, amount: 0 })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingTop: 52, paddingBottom: 16, paddingHorizontal: spacing.md, borderBottomLeftRadius: 24, borderBottomRightRadius: 24 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: 8 },
  headerTitle: { fontSize: fontSize.lg, fontWeight: '800', color: '#FFF' },
  progressPills: { flex: 1, flexDirection: 'row', gap: 4, flexWrap: 'wrap' },
  progressPill: { width: 14, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.3)' },
  progressPillDone: { backgroundColor: '#22C55E' },
  progressPillCurrent: { backgroundColor: '#FFD700' },
  progressText: { fontSize: fontSize.sm, color: '#FFF', fontWeight: '700' },
  hintRow: { flexDirection: 'row' },
  hintPointsText: { fontSize: fontSize.sm, color: 'rgba(255,255,255,0.85)', fontWeight: '600' },
  scroll: { flex: 1 },
  mascotRow: { alignItems: 'center', paddingVertical: spacing.md },
  card: { margin: spacing.md, backgroundColor: colors.surface, borderRadius: radius.xl, overflow: 'hidden', ...shadows.medium },
  cardImage: { width: '100%', height: 160 },
  cardLoading: { padding: spacing.xl, alignItems: 'center', gap: spacing.sm },
  cardLoadingText: { color: colors.textSecondary, fontSize: fontSize.sm },
  cardSection: { padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border },
  cardSectionHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  cardSectionLabel: { fontSize: 11, fontWeight: '700', color: colors.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5 },
  speakBtn: { fontSize: 18 },
  cardDefinition: { fontSize: fontSize.md, color: colors.text, lineHeight: 24 },
  cardExample: { fontSize: fontSize.md, color: colors.textSecondary, fontStyle: 'italic', lineHeight: 22 },
  hintsRow: { flexDirection: 'row', paddingHorizontal: spacing.md, gap: spacing.sm, marginBottom: spacing.sm },
  hintBtn: { flex: 1, backgroundColor: colors.hintLight, borderRadius: radius.lg, padding: spacing.sm, alignItems: 'center', borderWidth: 1, borderColor: colors.hint + '30' },
  hintBtnUsed: { backgroundColor: colors.successLight, borderColor: colors.success + '30' },
  hintBtnText: { fontSize: 11, fontWeight: '600', color: colors.hint, textAlign: 'center' },
  answerSection: { paddingHorizontal: spacing.md, gap: spacing.sm },
  answerInput: { backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, fontSize: fontSize.lg, color: colors.text, borderWidth: 2, borderColor: colors.border, fontWeight: '500', textAlign: 'center' },
  checkBtn: { borderRadius: radius.lg, overflow: 'hidden', ...shadows.small },
  checkBtnGradient: { padding: spacing.md, alignItems: 'center' },
  checkBtnText: { color: '#FFF', fontSize: fontSize.lg, fontWeight: '800' },
  ratingSection: { paddingHorizontal: spacing.md, gap: spacing.md },
  resultBadge: { borderRadius: radius.lg, padding: spacing.md, alignItems: 'center', gap: 4 },
  resultCorrect: { backgroundColor: colors.successLight },
  resultAlmost: { backgroundColor: colors.warningLight },
  resultWrong: { backgroundColor: colors.errorLight },
  resultText: { fontSize: fontSize.lg, fontWeight: '800', color: colors.text },
  correctAnswerText: { fontSize: fontSize.xl, fontWeight: '800', color: colors.primary },
  ratingLabel: { fontSize: fontSize.md, fontWeight: '700', color: colors.text, textAlign: 'center' },
  ratingBtns: { flexDirection: 'row', gap: spacing.sm },
  ratingBtn: { flex: 1, borderWidth: 2, borderRadius: radius.lg, padding: spacing.sm, alignItems: 'center' },
  ratingBtnText: { fontSize: fontSize.sm, fontWeight: '700' },
  doneContainer: { flex: 1, backgroundColor: colors.background },
  doneHeader: { paddingTop: 52, paddingBottom: 32, alignItems: 'center', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, gap: spacing.md },
  doneTitleText: { fontSize: fontSize.xxl, fontWeight: '800', color: '#FFF' },
  doneContent: { padding: spacing.lg, gap: spacing.md },
  doneStats: { flexDirection: 'row', gap: spacing.sm },
  doneStat: { flex: 1, backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, alignItems: 'center', gap: 4, ...shadows.small },
  doneStatEmoji: { fontSize: 28 },
  doneStatValue: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.primary },
  doneStatLabel: { fontSize: 11, color: colors.textSecondary, textAlign: 'center' },
  challengeBtn: { borderRadius: radius.xl, overflow: 'hidden', ...shadows.large },
  challengeBtnGradient: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md },
  challengeBtnEmoji: { fontSize: 48 },
  challengeBtnTitle: { fontSize: fontSize.xl, fontWeight: '800', color: '#FFF' },
  challengeBtnSub: { fontSize: fontSize.sm, color: 'rgba(255,255,255,0.8)' },
  homeBtn: { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, alignItems: 'center', ...shadows.small },
  homeBtnText: { fontSize: fontSize.md, fontWeight: '700', color: colors.text },
  emptyContainer: { flex: 1, backgroundColor: colors.background },
  emptyHeader: { paddingTop: 52, paddingBottom: 20, paddingHorizontal: spacing.lg, borderBottomLeftRadius: 24, borderBottomRightRadius: 24 },
  emptyHeaderText: { fontSize: fontSize.xl, fontWeight: '800', color: '#FFF' },
  emptyBody: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl, gap: spacing.xl },
  addWordBtn: { backgroundColor: colors.primary, borderRadius: radius.xl, paddingHorizontal: spacing.xl, paddingVertical: spacing.md, ...shadows.medium },
  addWordBtnText: { color: '#FFF', fontSize: fontSize.lg, fontWeight: '800' },
});
