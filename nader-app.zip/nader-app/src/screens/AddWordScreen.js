import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Animated,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, radius, spacing, fontSize, shadows } from '../constants/colors';
import { getProfile, addWord } from '../services/StorageService';
import { generateWordContent } from '../services/GroqService';
import { generateWordImage, getWordEmoji } from '../services/ImageService';
import { createWordObject } from '../services/SRSService';
import Mascot from '../components/Mascot';

const LOADING_MESSAGES = [
  'الذكاء الاصطناعي يقرأ أفكارك... 🤔',
  'يبحث في قواميس الكون... 📚',
  'يرسم المعنى في مخيلته... 🎨',
  'لحظة قبل الإلهام... ✨',
  'يصنع كلمة رائعة لك... 🌟',
];

export default function AddWordScreen({ navigation }) {
  const [profile, setProfile] = useState(null);
  const [mode, setMode] = useState('single'); // 'single' | 'bulk'
  const [wordInput, setWordInput] = useState('');
  const [bulkInput, setBulkInput] = useState('');
  const [generatedCards, setGeneratedCards] = useState([]);
  const [editingCard, setEditingCard] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState(0);
  const [savingAll, setSavingAll] = useState(false);
  const [savedCount, setSavedCount] = useState(0);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    getProfile().then(setProfile);
  }, []);

  useEffect(() => {
    if (loading) {
      const interval = setInterval(() => {
        setLoadingMsg((m) => (m + 1) % LOADING_MESSAGES.length);
        Animated.sequence([
          Animated.timing(fadeAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
          Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
        ]).start();
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [loading]);

  const getApiKey = () => profile?.groqApiKey || '';

  const generateSingle = async () => {
    const word = wordInput.trim();
    if (!word) return Alert.alert('', 'اكتب كلمة أولاً');
    if (word.length < 2) return Alert.alert('', 'الكلمة قصيرة جداً');
    if (!getApiKey()) return Alert.alert('لا يوجد API Key', 'أضف مفتاح Groq في الإعدادات أولاً');

    setLoading(true);
    setGeneratedCards([]);

    try {
      const [content, imageUrl] = await Promise.all([
        generateWordContent(word, profile?.targetLanguage || 'en', getApiKey()),
        generateWordImage(word, profile?.targetLanguage || 'en'),
      ]);

      const card = createWordObject({
        word,
        definition: content.definition,
        examples: content.examples,
        imageUrl,
        pronunciation: content.pronunciation,
      });

      setGeneratedCards([card]);
    } catch (e) {
      Alert.alert('خطأ', e.message || 'تعذر توليد المحتوى. تحقق من مفتاح API');
    } finally {
      setLoading(false);
    }
  };

  const generateBulk = async () => {
    const words = bulkInput
      .split(',')
      .map((w) => w.trim())
      .filter((w) => w.length >= 2);

    if (words.length === 0) return Alert.alert('', 'اكتب كلمات مفصولة بفاصلة');
    if (words.length > 10) return Alert.alert('', 'الحد الأقصى 10 كلمات في المرة');
    if (!getApiKey()) return Alert.alert('لا يوجد API Key', 'أضف مفتاح Groq في الإعدادات');

    setLoading(true);
    setGeneratedCards([]);

    const results = [];
    for (const word of words) {
      try {
        const content = await generateWordContent(word, profile?.targetLanguage || 'en', getApiKey());
        const imageUrl = generateWordImage(word, profile?.targetLanguage || 'en'); // Don't await - use URL directly
        const card = createWordObject({
          word,
          definition: content.definition,
          examples: content.examples,
          imageUrl: `https://image.pollinations.ai/prompt/${encodeURIComponent(word + ' concept illustration flat design')}?width=512&height=512&nologo=true`,
          pronunciation: content.pronunciation,
        });
        results.push(card);
      } catch {
        // Skip failed words
      }
    }

    setGeneratedCards(results);
    setLoading(false);
  };

  const saveCard = async (card) => {
    const result = await addWord(card);
    if (result.success) {
      setGeneratedCards((prev) => prev.filter((c) => c.id !== card.id));
      setSavedCount((n) => n + 1);
      if (generatedCards.length === 1) {
        setWordInput('');
        Alert.alert('🎉', `تم حفظ "${card.word}" بنجاح!`);
      }
    } else if (result.reason === 'exists') {
      Alert.alert('موجودة بالفعل', `الكلمة "${card.word}" موجودة في قائمتك`);
    }
  };

  const saveAll = async () => {
    setSavingAll(true);
    let saved = 0;
    for (const card of generatedCards) {
      const result = await addWord(card);
      if (result.success) saved++;
    }
    setSavingAll(false);
    setSavedCount((n) => n + saved);
    setGeneratedCards([]);
    setBulkInput('');
    Alert.alert('🎉', `تم حفظ ${saved} كلمة بنجاح!`);
  };

  const updateCardField = (cardId, field, value) => {
    setGeneratedCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, [field]: value } : c))
    );
  };

  const pickImage = async (cardId) => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
      base64: true,
    });
    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      updateCardField(cardId, 'imageUrl', uri);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      {/* Header */}
      <LinearGradient colors={['#14B8A6', '#0D9488']} style={styles.header}>
        <Text style={styles.headerTitle}>➕ إضافة كلمات</Text>
        {savedCount > 0 && (
          <View style={styles.savedBadge}>
            <Text style={styles.savedBadgeText}>✓ {savedCount} محفوظة</Text>
          </View>
        )}
      </LinearGradient>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Mode Toggle */}
        <View style={styles.modeToggle}>
          <TouchableOpacity
            style={[styles.modeBtn, mode === 'single' && styles.modeBtnActive]}
            onPress={() => { setMode('single'); setGeneratedCards([]); }}
          >
            <Text style={[styles.modeBtnText, mode === 'single' && styles.modeBtnTextActive]}>
              كلمة واحدة
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.modeBtn, mode === 'bulk' && styles.modeBtnActive]}
            onPress={() => { setMode('bulk'); setGeneratedCards([]); }}
          >
            <Text style={[styles.modeBtnText, mode === 'bulk' && styles.modeBtnTextActive]}>
              إضافة متعددة
            </Text>
          </TouchableOpacity>
        </View>

        {/* Single mode */}
        {mode === 'single' && (
          <View style={styles.inputSection}>
            <Text style={styles.inputLabel}>اكتب الكلمة</Text>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.wordInput}
                placeholder="مثال: ephemeral"
                placeholderTextColor={colors.textLight}
                value={wordInput}
                onChangeText={setWordInput}
                autoCapitalize="none"
                returnKeyType="done"
                onSubmitEditing={generateSingle}
              />
              <TouchableOpacity
                style={[styles.generateBtn, loading && styles.generateBtnDisabled]}
                onPress={generateSingle}
                disabled={loading}
              >
                <Text style={styles.generateBtnText}>🤖 توليد</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Bulk mode */}
        {mode === 'bulk' && (
          <View style={styles.inputSection}>
            <Text style={styles.inputLabel}>اكتب كلمات مفصولة بفاصلة (حتى 10)</Text>
            <TextInput
              style={[styles.wordInput, styles.bulkInput]}
              placeholder="ephemeral, serendipity, melancholy, ..."
              placeholderTextColor={colors.textLight}
              value={bulkInput}
              onChangeText={setBulkInput}
              multiline
              autoCapitalize="none"
            />
            <TouchableOpacity
              style={[styles.generateBtn, styles.generateBtnFull, loading && styles.generateBtnDisabled]}
              onPress={generateBulk}
              disabled={loading}
            >
              <Text style={styles.generateBtnText}>🤖 توليد الكل</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Loading State */}
        {loading && (
          <View style={styles.loadingContainer}>
            <Mascot mood="loading" size="large" animate />
            <Animated.Text style={[styles.loadingText, { opacity: fadeAnim }]}>
              {LOADING_MESSAGES[loadingMsg]}
            </Animated.Text>
            <ActivityIndicator color={colors.primary} size="large" style={{ marginTop: 8 }} />
          </View>
        )}

        {/* Generated Cards */}
        {generatedCards.length > 0 && (
          <View style={styles.cardsSection}>
            <View style={styles.cardsSectionHeader}>
              <Text style={styles.cardsSectionTitle}>
                {generatedCards.length > 1 ? `${generatedCards.length} بطاقات مولّدة` : 'بطاقتك الجديدة'}
              </Text>
              {generatedCards.length > 1 && (
                <TouchableOpacity
                  style={styles.saveAllBtn}
                  onPress={saveAll}
                  disabled={savingAll}
                >
                  <Text style={styles.saveAllBtnText}>
                    {savingAll ? '...' : '💾 حفظ الكل'}
                  </Text>
                </TouchableOpacity>
              )}
            </View>

            {generatedCards.map((card) => (
              <WordCard
                key={card.id}
                card={card}
                onSave={() => saveCard(card)}
                onPickImage={() => pickImage(card.id)}
                onEditDefinition={(text) => updateCardField(card.id, 'definition', text)}
                onEditExample={(index, text) => {
                  const examples = [...card.examples];
                  examples[index] = text;
                  updateCardField(card.id, 'examples', examples);
                }}
              />
            ))}
          </View>
        )}

        {/* Empty state */}
        {!loading && generatedCards.length === 0 && (
          <View style={styles.emptyState}>
            <Mascot mood="thinking" size="medium" message="اكتب كلمة وسأجلب لها تعريفاً وصورة! 🎨" />
            <View style={styles.tipsContainer}>
              <Text style={styles.tipsTitle}>💡 نصائح</Text>
              {[
                'يمكنك إضافة كلمات بأي لغة تتعلمها',
                'الذكاء الاصطناعي يولّد تعريفاً وأمثلة وصورة',
                'يمكنك تعديل التعريف أو تغيير الصورة',
                'الكلمات المضافة ستظهر في جلسة المراجعة',
              ].map((tip, i) => (
                <View key={i} style={styles.tipItem}>
                  <Text style={styles.tipBullet}>•</Text>
                  <Text style={styles.tipText}>{tip}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        <View style={{ height: 32 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ─── Word Card Component ──────────────────────────────────────────────────────

const WordCard = ({ card, onSave, onPickImage, onEditDefinition, onEditExample }) => {
  const [editingDef, setEditingDef] = useState(false);
  const [editingEx, setEditingEx] = useState(null);
  const [tempDef, setTempDef] = useState(card.definition);
  const [tempEx, setTempEx] = useState(card.examples || []);

  return (
    <View style={styles.wordCard}>
      {/* Word header */}
      <View style={styles.wordCardHeader}>
        <Text style={styles.wordCardWord}>{card.word}</Text>
        {card.pronunciation && (
          <Text style={styles.wordCardPronounce}>{card.pronunciation}</Text>
        )}
      </View>

      {/* Image */}
      <TouchableOpacity onPress={onPickImage} style={styles.imageContainer}>
        {card.imageUrl ? (
          <Image
            source={{ uri: card.imageUrl }}
            style={styles.wordImage}
            resizeMode="cover"
          />
        ) : (
          <View style={styles.imagePlaceholder}>
            <Text style={styles.imagePlaceholderText}>{getWordEmoji(card.word)}</Text>
          </View>
        )}
        <View style={styles.imageOverlay}>
          <Text style={styles.imageOverlayText}>📷 تغيير</Text>
        </View>
      </TouchableOpacity>

      {/* Definition */}
      <View style={styles.fieldContainer}>
        <View style={styles.fieldHeader}>
          <Text style={styles.fieldLabel}>📖 التعريف</Text>
          <TouchableOpacity onPress={() => setEditingDef(!editingDef)}>
            <Text style={styles.editBtn}>{editingDef ? '✓ حفظ' : '✏️ تعديل'}</Text>
          </TouchableOpacity>
        </View>
        {editingDef ? (
          <TextInput
            style={styles.editInput}
            value={tempDef}
            onChangeText={(t) => { setTempDef(t); onEditDefinition(t); }}
            multiline
            autoFocus
          />
        ) : (
          <Text style={styles.fieldText}>{card.definition}</Text>
        )}
      </View>

      {/* Examples */}
      <View style={styles.fieldContainer}>
        <Text style={styles.fieldLabel}>💬 أمثلة</Text>
        {(card.examples || []).map((ex, i) => (
          <View key={i} style={styles.exampleItem}>
            <Text style={styles.exampleNum}>{i + 1}.</Text>
            {editingEx === i ? (
              <TextInput
                style={[styles.editInput, { flex: 1 }]}
                value={tempEx[i]}
                onChangeText={(t) => {
                  const updated = [...tempEx];
                  updated[i] = t;
                  setTempEx(updated);
                  onEditExample(i, t);
                }}
                autoFocus
                onBlur={() => setEditingEx(null)}
              />
            ) : (
              <TouchableOpacity
                style={{ flex: 1 }}
                onPress={() => setEditingEx(i)}
              >
                <Text style={styles.exampleText}>{ex}</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}
      </View>

      {/* Save button */}
      <TouchableOpacity style={styles.saveCardBtn} onPress={onSave}>
        <LinearGradient
          colors={['#14B8A6', '#0D9488']}
          style={styles.saveCardBtnGradient}
        >
          <Text style={styles.saveCardBtnText}>💾 حفظ الكلمة</Text>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingTop: 56,
    paddingBottom: 20,
    paddingHorizontal: spacing.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTitle: {
    fontSize: fontSize.xl,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  savedBadge: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: radius.full,
  },
  savedBadgeText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: fontSize.sm,
  },
  scroll: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.md,
  },
  modeToggle: {
    flexDirection: 'row',
    backgroundColor: colors.border,
    borderRadius: radius.lg,
    padding: 4,
    marginBottom: spacing.md,
  },
  modeBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: radius.md,
  },
  modeBtnActive: {
    backgroundColor: colors.surface,
    ...shadows.small,
  },
  modeBtnText: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  modeBtnTextActive: {
    color: colors.primary,
    fontWeight: '700',
  },
  inputSection: {
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  inputLabel: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  inputRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  wordInput: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: fontSize.md,
    color: colors.text,
    borderWidth: 2,
    borderColor: colors.border,
    fontWeight: '500',
  },
  bulkInput: {
    height: 100,
    textAlignVertical: 'top',
    paddingTop: spacing.md,
  },
  generateBtn: {
    backgroundColor: colors.primary,
    borderRadius: radius.lg,
    paddingHorizontal: spacing.md,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.small,
  },
  generateBtnFull: {
    paddingVertical: spacing.md,
  },
  generateBtnDisabled: {
    opacity: 0.6,
  },
  generateBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: fontSize.sm,
  },
  loadingContainer: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
    gap: spacing.md,
  },
  loadingText: {
    fontSize: fontSize.md,
    color: colors.primary,
    fontWeight: '600',
    textAlign: 'center',
  },
  cardsSection: {
    gap: spacing.sm,
  },
  cardsSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  cardsSectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: '700',
    color: colors.text,
  },
  saveAllBtn: {
    backgroundColor: colors.teal,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.full,
  },
  saveAllBtnText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: fontSize.sm,
  },
  wordCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    overflow: 'hidden',
    marginBottom: spacing.md,
    ...shadows.medium,
  },
  wordCardHeader: {
    padding: spacing.md,
    backgroundColor: colors.primaryLight,
  },
  wordCardWord: {
    fontSize: fontSize.xxl,
    fontWeight: '800',
    color: colors.primary,
  },
  wordCardPronounce: {
    fontSize: fontSize.sm,
    color: colors.primaryMid,
    fontStyle: 'italic',
    marginTop: 2,
  },
  imageContainer: {
    height: 180,
    overflow: 'hidden',
    position: 'relative',
  },
  wordImage: {
    width: '100%',
    height: '100%',
  },
  imagePlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: colors.surfaceAlt,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imagePlaceholderText: {
    fontSize: 64,
  },
  imageOverlay: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: radius.sm,
  },
  imageOverlayText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  fieldContainer: {
    padding: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  fieldHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  fieldLabel: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  editBtn: {
    fontSize: fontSize.sm,
    color: colors.primary,
    fontWeight: '600',
  },
  fieldText: {
    fontSize: fontSize.md,
    color: colors.text,
    lineHeight: 22,
  },
  editInput: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.md,
    padding: spacing.sm,
    fontSize: fontSize.md,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.primary,
    minHeight: 40,
  },
  exampleItem: {
    flexDirection: 'row',
    gap: 6,
    marginBottom: 6,
    alignItems: 'flex-start',
  },
  exampleNum: {
    fontSize: fontSize.md,
    fontWeight: '700',
    color: colors.primary,
    marginTop: 2,
  },
  exampleText: {
    flex: 1,
    fontSize: fontSize.md,
    color: colors.textSecondary,
    lineHeight: 22,
    fontStyle: 'italic',
  },
  saveCardBtn: {
    margin: spacing.md,
    borderRadius: radius.lg,
    overflow: 'hidden',
    ...shadows.small,
  },
  saveCardBtnGradient: {
    padding: spacing.md,
    alignItems: 'center',
  },
  saveCardBtnText: {
    color: '#FFFFFF',
    fontSize: fontSize.md,
    fontWeight: '800',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
    gap: spacing.lg,
  },
  tipsContainer: {
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    padding: spacing.md,
    width: '100%',
    ...shadows.small,
  },
  tipsTitle: {
    fontSize: fontSize.md,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 8,
  },
  tipItem: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 6,
  },
  tipBullet: {
    color: colors.primary,
    fontWeight: '800',
    fontSize: 16,
  },
  tipText: {
    flex: 1,
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    lineHeight: 20,
  },
});
