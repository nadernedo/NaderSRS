import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, Alert, Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';
import { colors, radius, spacing, fontSize, shadows } from '../constants/colors';
import { getProfile, updateProfile, clearAllData, getHintPoints } from '../services/StorageService';
import { testGroqConnection } from '../services/GroqService';
import { scheduleDailyReminder, cancelAllNotifications, parseReminderTime } from '../services/NotificationService';
import { LEARNING_LANGUAGES, UI_LANGUAGES } from '../constants/languages';
import { getLevelInfo, LEVEL_AVATARS } from '../services/SRSService';
import { setLanguage } from '../constants/i18n';

export default function SettingsScreen() {
  const [profile, setProfile] = useState(null);
  const [groqKey, setGroqKey] = useState('');
  const [testStatus, setTestStatus] = useState(null); // null | 'testing' | 'ok' | 'fail'
  const [hintPoints, setHintPoints] = useState(0);
  const [saving, setSaving] = useState(false);

  useFocusEffect(
    useCallback(() => {
      loadProfile();
    }, [])
  );

  const loadProfile = async () => {
    const p = await getProfile();
    const hints = await getHintPoints();
    setProfile(p);
    setGroqKey(p?.groqApiKey || '');
    setHintPoints(hints);
  };

  const save = async (updates) => {
    setSaving(true);
    const updated = await updateProfile(updates);
    setProfile(updated);
    if (updates.appLanguage) setLanguage(updates.appLanguage);
    setSaving(false);
  };

  const saveGroqKey = async () => {
    await save({ groqApiKey: groqKey.trim() });
    Alert.alert('✅', 'تم حفظ مفتاح API');
  };

  const testGroq = async () => {
    if (!groqKey.trim()) {
      Alert.alert('', 'أدخل المفتاح أولاً');
      return;
    }
    setTestStatus('testing');
    const ok = await testGroqConnection(groqKey.trim());
    setTestStatus(ok ? 'ok' : 'fail');
    setTimeout(() => setTestStatus(null), 3000);
  };

  const handleNotificationToggle = async (val) => {
    await save({ notificationsEnabled: val });
    if (val && profile?.reminderTime) {
      const { hour, minute } = parseReminderTime(profile.reminderTime);
      await scheduleDailyReminder(hour, minute);
    } else {
      await cancelAllNotifications();
    }
  };

  const handleClearData = () => {
    Alert.alert(
      '⚠️ تحذير',
      'سيتم حذف جميع بياناتك بما فيها الكلمات والإحصائيات والسلسلة. هل أنت متأكد؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف كل شيء',
          style: 'destructive',
          onPress: async () => {
            await clearAllData();
            Alert.alert('', 'تم حذف جميع البيانات. أعد تشغيل التطبيق.');
          },
        },
      ]
    );
  };

  if (!profile) return <View style={styles.loading}><Text style={{ fontSize: 48 }}>⚙️</Text></View>;

  const levelInfo = getLevelInfo(profile.totalXP || 0);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Header */}
      <LinearGradient colors={['#1E293B', '#334155']} style={styles.header}>
        <Text style={styles.headerTitle}>⚙️ الإعدادات</Text>
      </LinearGradient>

      {/* Profile Card */}
      <Section title="👤 الملف الشخصي">
        <View style={styles.profileCard}>
          <Text style={styles.profileAvatar}>{LEVEL_AVATARS[levelInfo.current]}</Text>
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{profile.name}</Text>
            <Text style={styles.profileLevel}>{levelInfo.current} · {profile.totalXP || 0} XP</Text>
            <Text style={styles.profileStreak}>🔥 {profile.streak || 0} يوم متواصل</Text>
          </View>
        </View>
        <View style={styles.fieldRow}>
          <Text style={styles.fieldLabel}>الاسم</Text>
          <TextInput
            style={styles.fieldInput}
            value={profile.name}
            onChangeText={(t) => setProfile(p => ({ ...p, name: t }))}
            onBlur={() => save({ name: profile.name })}
            placeholder="اسمك"
          />
        </View>
        <View style={styles.hintPointsRow}>
          <Text style={styles.fieldLabel}>💡 نقاط التلميح</Text>
          <View style={styles.hintBadge}>
            <Text style={styles.hintBadgeText}>{hintPoints} / 15</Text>
            <Text style={styles.hintBadgeSub}>تتجدد يومياً</Text>
          </View>
        </View>
      </Section>

      {/* API Keys */}
      <Section title="🤖 مفاتيح الذكاء الاصطناعي">
        <Text style={styles.helperText}>
          احصل على مفتاح Groq المجاني من{' '}
          <Text style={styles.link}>console.groq.com</Text>
        </Text>
        <View style={styles.apiKeyRow}>
          <TextInput
            style={styles.apiKeyInput}
            value={groqKey}
            onChangeText={setGroqKey}
            placeholder="gsk_..."
            placeholderTextColor={colors.textLight}
            secureTextEntry
            autoCapitalize="none"
          />
        </View>
        <View style={styles.apiKeyActions}>
          <TouchableOpacity
            style={[styles.testBtn, testStatus === 'ok' && styles.testBtnOk, testStatus === 'fail' && styles.testBtnFail]}
            onPress={testGroq}
            disabled={testStatus === 'testing'}
          >
            <Text style={styles.testBtnText}>
              {testStatus === 'testing' ? '...' : testStatus === 'ok' ? '✅ متصل' : testStatus === 'fail' ? '❌ خطأ' : '🔗 اختبار'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.saveKeyBtn} onPress={saveGroqKey}>
            <Text style={styles.saveKeyBtnText}>💾 حفظ</Text>
          </TouchableOpacity>
        </View>
      </Section>

      {/* Languages */}
      <Section title="🌍 اللغات">
        <Text style={styles.fieldLabel}>اللغة التي تتعلمها</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.langScroll}>
          {LEARNING_LANGUAGES.map(lang => (
            <TouchableOpacity
              key={lang.code}
              style={[styles.langChip, profile.targetLanguage === lang.code && styles.langChipActive]}
              onPress={() => save({ targetLanguage: lang.code })}
            >
              <Text style={styles.langChipFlag}>{lang.flag}</Text>
              <Text style={[styles.langChipText, profile.targetLanguage === lang.code && styles.langChipTextActive]}>
                {lang.nativeName}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <Text style={[styles.fieldLabel, { marginTop: spacing.md }]}>لغة التطبيق</Text>
        <View style={styles.uiLangRow}>
          {UI_LANGUAGES.map(lang => (
            <TouchableOpacity
              key={lang.code}
              style={[styles.uiLangChip, profile.appLanguage === lang.code && styles.uiLangChipActive]}
              onPress={() => save({ appLanguage: lang.code })}
            >
              <Text style={styles.langChipFlag}>{lang.flag}</Text>
              <Text style={[styles.langChipText, profile.appLanguage === lang.code && styles.langChipTextActive]}>
                {lang.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </Section>

      {/* Notifications */}
      <Section title="🔔 الإشعارات">
        <View style={styles.switchRow}>
          <Text style={styles.switchLabel}>التذكير اليومي</Text>
          <Switch
            value={profile.notificationsEnabled}
            onValueChange={handleNotificationToggle}
            trackColor={{ true: colors.primary }}
            thumbColor="#FFF"
          />
        </View>
        {profile.notificationsEnabled && (
          <View style={styles.fieldRow}>
            <Text style={styles.fieldLabel}>وقت التذكير</Text>
            <TextInput
              style={[styles.fieldInput, styles.timeInput]}
              value={profile.reminderTime || '20:00'}
              onChangeText={(t) => setProfile(p => ({ ...p, reminderTime: t }))}
              onBlur={async () => {
                await save({ reminderTime: profile.reminderTime });
                const { hour, minute } = parseReminderTime(profile.reminderTime);
                await scheduleDailyReminder(hour, minute);
              }}
              placeholder="20:00"
              keyboardType="numbers-and-punctuation"
            />
          </View>
        )}
      </Section>

      {/* About */}
      <Section title="ℹ️ حول التطبيق">
        <View style={styles.aboutRow}><Text style={styles.aboutLabel}>الإصدار</Text><Text style={styles.aboutValue}>1.0.0</Text></View>
        <View style={styles.aboutRow}><Text style={styles.aboutLabel}>المطور</Text><Text style={styles.aboutValue}>Nader App</Text></View>
      </Section>

      {/* Danger Zone */}
      <TouchableOpacity style={styles.dangerBtn} onPress={handleClearData}>
        <Text style={styles.dangerBtnText}>🗑️ حذف جميع البيانات</Text>
      </TouchableOpacity>

      <View style={{ height: 32 }} />
    </ScrollView>
  );
}

const Section = ({ title, children }) => (
  <View style={styles.section}>
    <Text style={styles.sectionTitle}>{title}</Text>
    <View style={styles.sectionBody}>{children}</View>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { paddingBottom: 32 },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { paddingTop: 52, paddingBottom: 20, paddingHorizontal: spacing.lg, borderBottomLeftRadius: 24, borderBottomRightRadius: 24 },
  headerTitle: { fontSize: fontSize.xl, fontWeight: '800', color: '#FFF' },
  section: { margin: spacing.md, marginBottom: 0 },
  sectionTitle: { fontSize: fontSize.sm, fontWeight: '700', color: colors.textSecondary, marginBottom: spacing.sm, textTransform: 'uppercase', letterSpacing: 0.8, paddingHorizontal: 4 },
  sectionBody: { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, gap: spacing.sm, ...shadows.small },
  profileCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingBottom: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
  profileAvatar: { fontSize: 48 },
  profileInfo: { flex: 1 },
  profileName: { fontSize: fontSize.xl, fontWeight: '800', color: colors.text },
  profileLevel: { fontSize: fontSize.sm, color: colors.primary, fontWeight: '600', textTransform: 'capitalize' },
  profileStreak: { fontSize: fontSize.sm, color: colors.streak },
  fieldRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  fieldLabel: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary },
  fieldInput: { backgroundColor: colors.surfaceAlt, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: 8, fontSize: fontSize.md, color: colors.text, borderWidth: 1, borderColor: colors.border, minWidth: 120, textAlign: 'center' },
  hintPointsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  hintBadge: { backgroundColor: colors.hintLight, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.full, alignItems: 'center' },
  hintBadgeText: { fontSize: fontSize.md, fontWeight: '800', color: colors.hint },
  hintBadgeSub: { fontSize: 10, color: colors.textSecondary },
  helperText: { fontSize: fontSize.sm, color: colors.textSecondary },
  link: { color: colors.primary, fontWeight: '600' },
  apiKeyRow: { gap: 8 },
  apiKeyInput: { backgroundColor: colors.surfaceAlt, borderRadius: radius.md, padding: spacing.md, fontSize: fontSize.md, color: colors.text, borderWidth: 1, borderColor: colors.border },
  apiKeyActions: { flexDirection: 'row', gap: spacing.sm },
  testBtn: { flex: 1, backgroundColor: colors.surfaceAlt, borderRadius: radius.lg, padding: spacing.sm, alignItems: 'center', borderWidth: 1, borderColor: colors.border },
  testBtnOk: { backgroundColor: colors.successLight, borderColor: colors.success },
  testBtnFail: { backgroundColor: colors.errorLight, borderColor: colors.error },
  testBtnText: { fontSize: fontSize.sm, fontWeight: '700', color: colors.text },
  saveKeyBtn: { flex: 1, backgroundColor: colors.primary, borderRadius: radius.lg, padding: spacing.sm, alignItems: 'center' },
  saveKeyBtnText: { color: '#FFF', fontWeight: '700', fontSize: fontSize.sm },
  langScroll: { marginTop: 4 },
  langChip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 8, borderRadius: radius.full, borderWidth: 2, borderColor: colors.border, marginRight: 8, backgroundColor: colors.surfaceAlt },
  langChipActive: { borderColor: colors.primary, backgroundColor: colors.primaryLight },
  langChipFlag: { fontSize: 18 },
  langChipText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.text },
  langChipTextActive: { color: colors.primary },
  uiLangRow: { flexDirection: 'row', gap: spacing.sm, marginTop: 4 },
  uiLangChip: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: spacing.md, borderRadius: radius.xl, borderWidth: 2, borderColor: colors.border, backgroundColor: colors.surfaceAlt },
  uiLangChipActive: { borderColor: colors.primary, backgroundColor: colors.primaryLight },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  switchLabel: { fontSize: fontSize.md, fontWeight: '600', color: colors.text },
  timeInput: { width: 80 },
  aboutRow: { flexDirection: 'row', justifyContent: 'space-between' },
  aboutLabel: { fontSize: fontSize.sm, color: colors.textSecondary },
  aboutValue: { fontSize: fontSize.sm, fontWeight: '600', color: colors.text },
  dangerBtn: { margin: spacing.md, backgroundColor: colors.errorLight, borderRadius: radius.xl, padding: spacing.md, alignItems: 'center', borderWidth: 1, borderColor: colors.error + '40', marginTop: spacing.lg },
  dangerBtnText: { color: colors.error, fontWeight: '700', fontSize: fontSize.md },
});
