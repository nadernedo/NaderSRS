import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Animated,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, radius, spacing, fontSize } from '../constants/colors';
import { LEARNING_LANGUAGES, UI_LANGUAGES } from '../constants/languages';
import { saveProfile, setOnboardingDone } from '../services/StorageService';
import { scheduleDailyReminder, requestNotificationPermission } from '../services/NotificationService';
import { setLanguage, t } from '../constants/i18n';
import Mascot from '../components/Mascot';

const { width } = Dimensions.get('window');

const STEPS = ['welcome', 'name', 'learningLang', 'uiLang'];

export default function OnboardingScreen({ navigation }) {
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [targetLanguage, setTargetLanguage] = useState('en');
  const [appLanguage, setAppLanguage] = useState('ar');
  const [loading, setLoading] = useState(false);

  const slideAnim = useRef(new Animated.Value(0)).current;

  const animateNext = () => {
    Animated.sequence([
      Animated.timing(slideAnim, { toValue: -20, duration: 150, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start();
  };

  const goNext = () => {
    if (step === 1 && name.trim().length < 2) {
      Alert.alert('', 'اكتب اسمك (حرفين على الأقل)');
      return;
    }
    animateNext();
    setStep((s) => s + 1);
  };

  const finish = async () => {
    setLoading(true);
    try {
      setLanguage(appLanguage);

      const profile = {
        name: name.trim(),
        avatar: '🎓',
        targetLanguage,
        appLanguage,
        streak: 0,
        lastStudyDate: null,
        totalXP: 0,
        level: 'beginner',
        groqApiKey: '',
        notificationsEnabled: true,
        reminderTime: '20:00',
        createdAt: new Date().toISOString(),
      };

      await saveProfile(profile);
      await setOnboardingDone();

      const hasPermission = await requestNotificationPermission();
      if (hasPermission) {
        await scheduleDailyReminder(20, 0);
      }

      navigation.replace('MainTabs');
    } catch (e) {
      Alert.alert('خطأ', 'حدث خطأ، حاول مرة أخرى');
    } finally {
      setLoading(false);
    }
  };

  // Step 0 - Welcome
  const renderWelcome = () => (
    <View style={styles.stepContainer}>
      <Mascot mood="excited" size="large" animate />
      <Text style={styles.heroTitle}>مرحباً! 👋</Text>
      <Text style={styles.heroSubtitle}>
        أنا <Text style={styles.appName}>نادر</Text> 🦉{'\n'}
        مساعدك الشخصي في تعلم اللغات{'\n'}
        بطريقة ذكية وممتعة!
      </Text>
      <View style={styles.featureList}>
        {[
          { icon: '🧠', text: 'نظام مراجعة ذكي (SRS)' },
          { icon: '🤖', text: 'ذكاء اصطناعي لتوليد المحتوى' },
          { icon: '🔥', text: 'تحديات يومية وسلسلة متواصلة' },
          { icon: '📊', text: 'إحصائيات تقدمك الكاملة' },
        ].map((f, i) => (
          <View key={i} style={styles.featureItem}>
            <Text style={styles.featureIcon}>{f.icon}</Text>
            <Text style={styles.featureText}>{f.text}</Text>
          </View>
        ))}
      </View>
    </View>
  );

  // Step 1 - Name
  const renderName = () => (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={styles.stepContainer}
    >
      <Mascot mood="happy" size="large" message="ما اسمك؟ سأناديك به دائماً! 😊" />
      <Text style={styles.stepTitle}>ما اسمك؟</Text>
      <Text style={styles.stepSubtitle}>سيستخدمه التطبيق في الترحيب بك</Text>
      <TextInput
        style={styles.nameInput}
        placeholder="اكتب اسمك هنا..."
        placeholderTextColor={colors.textLight}
        value={name}
        onChangeText={setName}
        autoFocus
        textAlign="center"
        maxLength={20}
      />
    </KeyboardAvoidingView>
  );

  // Step 2 - Learning Language
  const renderLearningLang = () => (
    <View style={styles.stepContainer}>
      <Mascot mood="thinking" size="medium" />
      <Text style={styles.stepTitle}>ماذا تريد أن تتعلم؟</Text>
      <Text style={styles.stepSubtitle}>اختر اللغة التي ستضيف كلماتها</Text>
      <ScrollView style={styles.langList} showsVerticalScrollIndicator={false}>
        {LEARNING_LANGUAGES.map((lang) => (
          <TouchableOpacity
            key={lang.code}
            style={[
              styles.langOption,
              targetLanguage === lang.code && styles.langOptionSelected,
            ]}
            onPress={() => setTargetLanguage(lang.code)}
          >
            <Text style={styles.langFlag}>{lang.flag}</Text>
            <View>
              <Text style={[styles.langName, targetLanguage === lang.code && styles.langNameSelected]}>
                {lang.nativeName}
              </Text>
              <Text style={styles.langSubname}>{lang.name}</Text>
            </View>
            {targetLanguage === lang.code && (
              <Text style={styles.checkmark}>✓</Text>
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  // Step 3 - UI Language
  const renderUILang = () => (
    <View style={styles.stepContainer}>
      <Mascot mood="happy" size="medium" />
      <Text style={styles.stepTitle}>لغة التطبيق</Text>
      <Text style={styles.stepSubtitle}>اختر لغة واجهة التطبيق</Text>
      <View style={styles.uiLangList}>
        {UI_LANGUAGES.map((lang) => (
          <TouchableOpacity
            key={lang.code}
            style={[
              styles.uiLangOption,
              appLanguage === lang.code && styles.uiLangOptionSelected,
            ]}
            onPress={() => setAppLanguage(lang.code)}
          >
            <Text style={styles.uiLangFlag}>{lang.flag}</Text>
            <Text style={[styles.uiLangName, appLanguage === lang.code && styles.uiLangNameSelected]}>
              {lang.name}
            </Text>
            {appLanguage === lang.code && <Text style={styles.checkmark}>✓</Text>}
          </TouchableOpacity>
        ))}
      </View>
      {name ? (
        <View style={styles.summaryBox}>
          <Text style={styles.summaryTitle}>ملخص إعداداتك</Text>
          <Text style={styles.summaryItem}>👤 الاسم: {name}</Text>
          <Text style={styles.summaryItem}>
            🎯 اللغة:{' '}
            {LEARNING_LANGUAGES.find((l) => l.code === targetLanguage)?.flag}{' '}
            {LEARNING_LANGUAGES.find((l) => l.code === targetLanguage)?.nativeName}
          </Text>
          <Text style={styles.summaryItem}>
            📱 واجهة: {UI_LANGUAGES.find((l) => l.code === appLanguage)?.name}
          </Text>
        </View>
      ) : null}
    </View>
  );

  const steps = [renderWelcome, renderName, renderLearningLang, renderUILang];
  const isLast = step === STEPS.length - 1;

  return (
    <LinearGradient
      colors={['#7C3AED', '#A78BFA', '#EDE9FE']}
      style={styles.container}
    >
      {/* Progress dots */}
      <View style={styles.dotsContainer}>
        {STEPS.map((_, i) => (
          <View
            key={i}
            style={[styles.dot, i === step && styles.dotActive, i < step && styles.dotDone]}
          />
        ))}
      </View>

      {/* Content */}
      <Animated.View
        style={[styles.content, { transform: [{ translateX: slideAnim }] }]}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {steps[step]?.()}
        </ScrollView>
      </Animated.View>

      {/* Button */}
      <View style={styles.buttonContainer}>
        {step > 0 && (
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => setStep((s) => s - 1)}
          >
            <Text style={styles.backButtonText}>← رجوع</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[styles.nextButton, loading && styles.nextButtonDisabled]}
          onPress={isLast ? finish : goNext}
          disabled={loading}
        >
          <Text style={styles.nextButtonText}>
            {loading ? '...' : isLast ? 'ابدأ الرحلة! 🚀' : 'التالي →'}
          </Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    paddingTop: 60,
    paddingBottom: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.4)',
  },
  dotActive: {
    width: 24,
    backgroundColor: '#FFFFFF',
  },
  dotDone: {
    backgroundColor: 'rgba(255,255,255,0.8)',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: 100,
  },
  stepContainer: {
    flex: 1,
    alignItems: 'center',
    gap: spacing.md,
  },
  heroTitle: {
    fontSize: fontSize.hero,
    fontWeight: '800',
    color: '#FFFFFF',
    marginTop: spacing.md,
  },
  heroSubtitle: {
    fontSize: fontSize.lg,
    color: 'rgba(255,255,255,0.9)',
    textAlign: 'center',
    lineHeight: 28,
    fontWeight: '500',
  },
  appName: {
    fontWeight: '800',
    color: '#FFD700',
  },
  featureList: {
    width: '100%',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: radius.lg,
    padding: spacing.md,
    gap: spacing.sm,
  },
  featureIcon: {
    fontSize: 24,
  },
  featureText: {
    fontSize: fontSize.md,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  stepTitle: {
    fontSize: fontSize.xxl,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: spacing.md,
  },
  stepSubtitle: {
    fontSize: fontSize.md,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
  },
  nameInput: {
    backgroundColor: '#FFFFFF',
    borderRadius: radius.xl,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.lg,
    fontSize: fontSize.xl,
    fontWeight: '700',
    color: colors.text,
    width: '100%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    textAlign: 'center',
    marginTop: spacing.md,
  },
  langList: {
    width: '100%',
    maxHeight: 340,
  },
  langOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: 8,
    borderWidth: 2,
    borderColor: 'transparent',
    gap: spacing.sm,
  },
  langOptionSelected: {
    backgroundColor: '#FFFFFF',
    borderColor: '#FFD700',
  },
  langFlag: {
    fontSize: 28,
  },
  langName: {
    fontSize: fontSize.md,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  langNameSelected: {
    color: colors.primary,
  },
  langSubname: {
    fontSize: fontSize.sm,
    color: 'rgba(255,255,255,0.7)',
  },
  checkmark: {
    fontSize: 20,
    color: colors.primary,
    marginLeft: 'auto',
    fontWeight: '800',
  },
  uiLangList: {
    width: '100%',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  uiLangOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: radius.xl,
    padding: spacing.lg,
    borderWidth: 2,
    borderColor: 'transparent',
    gap: spacing.md,
  },
  uiLangOptionSelected: {
    backgroundColor: '#FFFFFF',
    borderColor: '#FFD700',
  },
  uiLangFlag: {
    fontSize: 36,
  },
  uiLangName: {
    fontSize: fontSize.xl,
    fontWeight: '700',
    color: '#FFFFFF',
    flex: 1,
  },
  uiLangNameSelected: {
    color: colors.primary,
  },
  summaryBox: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: radius.lg,
    padding: spacing.md,
    width: '100%',
    gap: spacing.xs,
    marginTop: spacing.md,
  },
  summaryTitle: {
    fontSize: fontSize.md,
    fontWeight: '700',
    color: '#FFD700',
    marginBottom: 4,
  },
  summaryItem: {
    fontSize: fontSize.md,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  buttonContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    paddingBottom: 40,
    paddingTop: spacing.md,
    gap: spacing.sm,
  },
  backButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: radius.xl,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    justifyContent: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: fontSize.md,
    fontWeight: '600',
  },
  nextButton: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: radius.xl,
    paddingVertical: spacing.md,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 6,
  },
  nextButtonDisabled: {
    opacity: 0.7,
  },
  nextButtonText: {
    fontSize: fontSize.lg,
    fontWeight: '800',
    color: colors.primary,
  },
});
