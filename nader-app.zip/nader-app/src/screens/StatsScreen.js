import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions } from 'react-native';
import { BarChart } from 'react-native-chart-kit';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';
import { colors, radius, spacing, fontSize, shadows } from '../constants/colors';
import { getStats } from '../services/StorageService';
import { getLevelInfo, LEVEL_AVATARS } from '../services/SRSService';

const { width } = Dimensions.get('window');

export default function StatsScreen() {
  const [stats, setStats] = useState(null);

  useFocusEffect(
    useCallback(() => {
      getStats().then(setStats);
    }, [])
  );

  if (!stats) {
    return (
      <View style={styles.loading}>
        <Text style={{ fontSize: 48 }}>📊</Text>
      </View>
    );
  }

  const levelInfo = getLevelInfo(stats.totalXP || 0);
  const chartData = {
    labels: (stats.weeklyData || []).map(d => d.label),
    datasets: [{ data: (stats.weeklyData || []).map(d => Math.max(d.minutes, 0)) }],
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Header */}
      <LinearGradient colors={['#F97316', '#EF4444']} style={styles.header}>
        <Text style={styles.headerTitle}>📊 إحصائياتك</Text>
        <View style={styles.streakBig}>
          <Text style={styles.streakEmoji}>🔥</Text>
          <Text style={styles.streakNum}>{stats.streak}</Text>
          <Text style={styles.streakLabel}>يوم متواصل</Text>
        </View>
      </LinearGradient>

      {/* Level card */}
      <View style={styles.levelCard}>
        <View style={styles.levelCardLeft}>
          <Text style={styles.levelEmoji}>{LEVEL_AVATARS[levelInfo.current]}</Text>
          <View>
            <Text style={styles.levelName}>{levelInfo.current}</Text>
            <Text style={styles.levelXP}>{stats.totalXP} XP إجمالي</Text>
          </View>
        </View>
        {!levelInfo.isMaxLevel && (
          <View style={styles.levelProgressSection}>
            <Text style={styles.levelProgressLabel}>{levelInfo.xpToNext} XP للمستوى التالي</Text>
            <View style={styles.levelProgressBg}>
              <View style={[styles.levelProgressFill, { width: `${levelInfo.progress * 100}%` }]} />
            </View>
          </View>
        )}
      </View>

      {/* Words Stats */}
      <Text style={styles.sectionTitle}>📚 الكلمات</Text>
      <View style={styles.statsGrid}>
        {[
          { label: 'إجمالي', value: stats.totalWords, emoji: '📚', color: colors.primary, bg: colors.primaryLight },
          { label: 'متقنة', value: stats.masteredWords, emoji: '⭐', color: colors.success, bg: colors.successLight },
          { label: 'صعبة', value: stats.hardWords, emoji: '🔥', color: colors.error, bg: colors.errorLight },
          { label: 'قيد التعلم', value: stats.learningWords, emoji: '📖', color: colors.warning, bg: colors.warningLight },
        ].map((s, i) => (
          <View key={i} style={[styles.statCard, { backgroundColor: s.bg }]}>
            <Text style={styles.statEmoji}>{s.emoji}</Text>
            <Text style={[styles.statValue, { color: s.color }]}>{s.value}</Text>
            <Text style={[styles.statLabel, { color: s.color }]}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* Study time */}
      <Text style={styles.sectionTitle}>⏱️ وقت الدراسة</Text>
      <View style={styles.timeCard}>
        <View style={styles.timeItem}>
          <Text style={styles.timeEmoji}>📅</Text>
          <Text style={styles.timeValue}>{stats.todayMinutes}</Text>
          <Text style={styles.timeLabel}>دقيقة اليوم</Text>
        </View>
        <View style={styles.timeDivider} />
        <View style={styles.timeItem}>
          <Text style={styles.timeEmoji}>📊</Text>
          <Text style={styles.timeValue}>
            {(stats.weeklyData || []).reduce((s, d) => s + d.minutes, 0)}
          </Text>
          <Text style={styles.timeLabel}>دقيقة هذا الأسبوع</Text>
        </View>
      </View>

      {/* Weekly Chart */}
      <Text style={styles.sectionTitle}>📈 النشاط الأسبوعي (دقائق)</Text>
      <View style={styles.chartCard}>
        {chartData.datasets[0].data.some(v => v > 0) ? (
          <BarChart
            data={chartData}
            width={width - spacing.md * 2 - 32}
            height={180}
            chartConfig={{
              backgroundColor: colors.surface,
              backgroundGradientFrom: colors.surface,
              backgroundGradientTo: colors.surface,
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(124, 58, 237, ${opacity})`,
              labelColor: () => colors.textSecondary,
              barPercentage: 0.7,
            }}
            style={{ borderRadius: 12 }}
            showValuesOnTopOfBars
          />
        ) : (
          <View style={styles.noData}>
            <Text style={styles.noDataEmoji}>😴</Text>
            <Text style={styles.noDataText}>لا توجد بيانات بعد. ابدأ الدراسة!</Text>
          </View>
        )}
      </View>

      {/* Mastery progress bar */}
      {stats.totalWords > 0 && (
        <>
          <Text style={styles.sectionTitle}>🎯 نسبة الإتقان</Text>
          <View style={styles.masteryCard}>
            <View style={styles.masteryRow}>
              <Text style={styles.masteryPercent}>
                {Math.round((stats.masteredWords / stats.totalWords) * 100)}%
              </Text>
              <Text style={styles.masteryLabel}>{stats.masteredWords}/{stats.totalWords} كلمة متقنة</Text>
            </View>
            <View style={styles.masteryBarBg}>
              <View
                style={[styles.masteryBarFill, { width: `${(stats.masteredWords / stats.totalWords) * 100}%` }]}
              />
            </View>
          </View>
        </>
      )}

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { paddingBottom: 32 },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { paddingTop: 52, paddingBottom: 32, paddingHorizontal: spacing.lg, borderBottomLeftRadius: 32, borderBottomRightRadius: 32 },
  headerTitle: { fontSize: fontSize.xl, fontWeight: '800', color: '#FFF', marginBottom: spacing.md },
  streakBig: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: radius.xl, padding: spacing.md, alignSelf: 'flex-start' },
  streakEmoji: { fontSize: 32 },
  streakNum: { fontSize: fontSize.xxxl, fontWeight: '800', color: '#FFF' },
  streakLabel: { fontSize: fontSize.sm, color: 'rgba(255,255,255,0.85)', fontWeight: '600' },
  levelCard: { margin: spacing.md, backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, ...shadows.small, gap: spacing.sm },
  levelCardLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  levelEmoji: { fontSize: 40 },
  levelName: { fontSize: fontSize.xl, fontWeight: '800', color: colors.primary, textTransform: 'capitalize' },
  levelXP: { fontSize: fontSize.sm, color: colors.textSecondary },
  levelProgressSection: { gap: 4 },
  levelProgressLabel: { fontSize: 11, color: colors.textSecondary },
  levelProgressBg: { height: 8, backgroundColor: colors.primaryLight, borderRadius: radius.full },
  levelProgressFill: { height: '100%', backgroundColor: colors.primary, borderRadius: radius.full },
  sectionTitle: { fontSize: fontSize.md, fontWeight: '700', color: colors.text, paddingHorizontal: spacing.md, marginBottom: spacing.sm },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: spacing.md, gap: spacing.sm, marginBottom: spacing.md },
  statCard: { flex: 1, minWidth: '45%', alignItems: 'center', borderRadius: radius.xl, padding: spacing.md, gap: 4 },
  statEmoji: { fontSize: 28 },
  statValue: { fontSize: fontSize.xxl, fontWeight: '800' },
  statLabel: { fontSize: fontSize.sm, fontWeight: '600' },
  timeCard: { marginHorizontal: spacing.md, backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, flexDirection: 'row', ...shadows.small, marginBottom: spacing.md },
  timeItem: { flex: 1, alignItems: 'center', gap: 4 },
  timeEmoji: { fontSize: 28 },
  timeValue: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.primary },
  timeLabel: { fontSize: fontSize.sm, color: colors.textSecondary, textAlign: 'center' },
  timeDivider: { width: 1, backgroundColor: colors.border, marginVertical: 8 },
  chartCard: { marginHorizontal: spacing.md, backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, ...shadows.small, marginBottom: spacing.md, alignItems: 'center' },
  noData: { padding: spacing.xl, alignItems: 'center', gap: spacing.sm },
  noDataEmoji: { fontSize: 48 },
  noDataText: { fontSize: fontSize.md, color: colors.textSecondary, textAlign: 'center' },
  masteryCard: { marginHorizontal: spacing.md, backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, ...shadows.small, gap: spacing.sm },
  masteryRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  masteryPercent: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.success },
  masteryLabel: { fontSize: fontSize.sm, color: colors.textSecondary },
  masteryBarBg: { height: 12, backgroundColor: colors.successLight, borderRadius: radius.full },
  masteryBarFill: { height: '100%', backgroundColor: colors.success, borderRadius: radius.full },
});
