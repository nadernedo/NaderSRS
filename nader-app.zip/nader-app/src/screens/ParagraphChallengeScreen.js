import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, Animated, ActivityIndicator, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, radius, spacing, fontSize, shadows } from '../constants/colors';
import { getProfile, updateProfile, updateStreak } from '../services/StorageService';
import { evaluateParagraph } from '../services/GroqService';

export default function ParagraphChallengeScreen({ navigation, route }) {
  const { words = [] } = route.params || {};
  const [paragraph, setParagraph] = useState('');
  const [evaluating, setEvaluating] = useState(false);
  const [result, setResult] = useState(null);
  const [profile, setProfile] = useState(null);
  const [attempts, setAttempts] = useState(0);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const slideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    getProfile().then(setProfile);
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.05, duration: 800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const usedWords = words.filter(w =>
    paragraph.toLowerCase().includes(w.toLowerCase())
  );

  const canSubmit = usedWords.length >= 4 && paragraph.trim().length > 20;

  const submit = async () => {
    if (!canSubmit) {
      Alert.alert('', 'يجب استخدام 4 كلمات على الأقل في فقرتك!');
      return;
    }
    const apiKey = profile?.groqApiKey || '';
    if (!apiKey) {
      Alert.alert('لا يوجد API Key', 'أضف مفتاح Groq في الإعدادات لتقييم الفقرة');
      return;
    }
    setEvaluating(true);
    setResult(null);
    try {
      const eval_ = await evaluateParagraph(paragraph, words, profile?.targetLanguage || 'en', apiKey);
      setResult(eval_);
      setAttempts(a => a + 1);
      if (eval_.passed) {
        await updateStreak();
        const xp = 30 + (eval_.score * 5);
        await updateProfile({ totalXP: (profile?.totalXP || 0) + xp });
      }
    } catch (e) {
      Alert.alert('خطأ', 'تعذر تقييم الفقرة. تحقق من الاتصال.');
    } finally {
      setEvaluating(false);
    }
  };

  const goHome = () => navigation.navigate('Home');

  // ─── Result View ──────────────────────────────────────────────────────────

  if (result) {
    return (
      <ScrollView style={styles.container} contentContainerStyle={styles.resultContainer}>
        <LinearGradient
          colors={result.passed ? ['#22C55E', '#16A34A'] : ['#F97316', '#DC2626']}
          style={styles.resultHeader}
        >
          <Text style={styles.resultEmoji}>{result.passed ? '🎊' : '📝'}</Text>
          <Text style={styles.resultTitle}>{result.passed ? 'اجتزت التحدي!' : 'لم تنجح بعد'}</Text>
          <View style={styles.scoreCircle}>
            <Text style={styles.scoreNumber}>{result.score}</Text>
            <Text style={styles.scoreDivider}>/10</Text>
          </View>
        </LinearGradient>

        <View style={styles.resultBody}>
          {/* Naturalness */}
          <View style={styles.resultCard}>
            <Text style={styles.resultCardTitle}>مستوى الطبيعية</Text>
            <Text style={styles.naturalText}>
              {result.nativeRating === 'natural' ? '🟢 طبيعي'
                : result.nativeRating === 'somewhat-natural' ? '🟡 شبه طبيعي'
                : '🔴 غير طبيعي'}
            </Text>
          </View>

          {/* Words used */}
          <View style={styles.resultCard}>
            <Text style={styles.resultCardTitle}>✅ كلمات مستخدمة صحيح ({result.wordsUsedCorrectly?.length || 0})</Text>
            <View style={styles.wordChips}>
              {(result.wordsUsedCorrectly || []).map((w, i) => (
                <View key={i} style={styles.wordChipGood}><Text style={styles.wordChipText}>{w}</Text></View>
              ))}
            </View>
          </View>

          {/* Grammar errors */}
          {(result.grammarErrors || []).length > 0 && (
            <View style={styles.resultCard}>
              <Text style={styles.resultCardTitle}>✏️ تصحيحات نحوية</Text>
              {result.grammarErrors.map((err, i) => (
                <View key={i} style={styles.errorItem}>
                  <Text style={styles.errorOriginal}>❌ {err.original}</Text>
                  <Text style={styles.errorCorrected}>✅ {err.corrected}</Text>
                  {err.explanation && <Text style={styles.errorExplanation}>💡 {err.explanation}</Text>}
                </View>
              ))}
            </View>
          )}

          {/* Feedback */}
          <View style={[styles.resultCard, styles.feedbackCard]}>
            <Text style={styles.resultCardTitle}>💬 ملاحظات نادر</Text>
            <Text style={styles.feedbackText}>{result.feedback}</Text>
          </View>

          {/* Your paragraph */}
          <View style={styles.resultCard}>
            <Text style={styles.resultCardTitle}>📄 فقرتك</Text>
            <Text style={styles.paragraphPreview}>{paragraph}</Text>
          </View>

          {result.passed ? (
            <TouchableOpacity style={styles.doneBtn} onPress={goHome}>
              <LinearGradient colors={['#22C55E', '#16A34A']} style={styles.doneBtnGradient}>
                <Text style={styles.doneBtnText}>🏠 العودة للرئيسية</Text>
              </LinearGradient>
            </TouchableOpacity>
          ) : (
            <>
              <TouchableOpacity
                style={styles.retryBtn}
                onPress={() => { setResult(null); }}
              >
                <Text style={styles.retryBtnText}>✏️ عدّل الفقرة وحاول مجدداً</Text>
              </TouchableOpacity>
              {attempts >= 3 && (
                <TouchableOpacity style={styles.skipBtn} onPress={goHome}>
                  <Text style={styles.skipBtnText}>تخطي هذه المرة</Text>
                </TouchableOpacity>
              )}
            </>
          )}
        </View>
      </ScrollView>
    );
  }

  // ─── Main Challenge UI ────────────────────────────────────────────────────

  return (
    <ScrollView style={styles.container} keyboardShouldPersistTaps="handled">
      {/* Header */}
      <LinearGradient colors={['#F97316', '#DC2626']} style={styles.header}>
        <Animated.Text style={[styles.bossEmoji, { transform: [{ scale: pulseAnim }] }]}>👾</Animated.Text>
        <Text style={styles.headerTitle}>تحدي البراجراف!</Text>
        <Text style={styles.headerSub}>استخدم 4 كلمات على الأقل في فقرة واحدة</Text>
      </LinearGradient>

      <View style={styles.body}>
        {/* Today's words */}
        <View style={styles.wordsSection}>
          <Text style={styles.wordsSectionTitle}>🎯 كلماتك اليوم:</Text>
          <View style={styles.wordChips}>
            {words.map((w, i) => (
              <View key={i} style={[
                styles.wordChip,
                paragraph.toLowerCase().includes(w.toLowerCase()) && styles.wordChipUsed,
              ]}>
                <Text style={[
                  styles.wordChipText,
                  paragraph.toLowerCase().includes(w.toLowerCase()) && styles.wordChipTextUsed,
                ]}>{w}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Counter */}
        <View style={styles.counterRow}>
          <Text style={[styles.counterText, usedWords.length >= 4 && styles.counterTextReady]}>
            {usedWords.length >= 4 ? `✅ ${usedWords.length} كلمات مستخدمة - جاهز!` : `${usedWords.length}/4 كلمات مستخدمة`}
          </Text>
        </View>

        {/* Text area */}
        <TextInput
          style={styles.textArea}
          placeholder="اكتب فقرتك هنا... يمكنك كتابة قصة خيالية أو أي شيء تريد، المهم استخدام الكلمات بشكل صحيح!"
          placeholderTextColor={colors.textLight}
          value={paragraph}
          onChangeText={setParagraph}
          multiline
          textAlignVertical="top"
          autoFocus
        />

        <Text style={styles.charCount}>{paragraph.length} حرف</Text>

        {/* Submit */}
        <TouchableOpacity
          style={[styles.submitBtn, !canSubmit && styles.submitBtnDisabled]}
          onPress={submit}
          disabled={!canSubmit || evaluating}
        >
          {evaluating ? (
            <View style={styles.evaluatingRow}>
              <ActivityIndicator color="#FFF" />
              <Text style={styles.submitBtnText}>الذكاء الاصطناعي يقيّم كلامك... 🤖</Text>
            </View>
          ) : (
            <LinearGradient
              colors={canSubmit ? ['#F97316', '#DC2626'] : ['#CBD5E1', '#94A3B8']}
              style={styles.submitBtnGradient}
            >
              <Text style={styles.submitBtnText}>
                {canSubmit ? '🚀 أرسل للتقييم' : `استخدم ${4 - usedWords.length} كلمات أكثر`}
              </Text>
            </LinearGradient>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.skipChallengeBtn} onPress={goHome}>
          <Text style={styles.skipChallengeBtnText}>تخطي التحدي</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { paddingTop: 52, paddingBottom: 28, alignItems: 'center', gap: 8, borderBottomLeftRadius: 32, borderBottomRightRadius: 32 },
  bossEmoji: { fontSize: 64 },
  headerTitle: { fontSize: fontSize.xxl, fontWeight: '800', color: '#FFF' },
  headerSub: { fontSize: fontSize.sm, color: 'rgba(255,255,255,0.85)', textAlign: 'center' },
  body: { padding: spacing.md, gap: spacing.md },
  wordsSection: { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, ...shadows.small },
  wordsSectionTitle: { fontSize: fontSize.md, fontWeight: '700', color: colors.text, marginBottom: 8 },
  wordChips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  wordChip: { backgroundColor: colors.primaryLight, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.full, borderWidth: 1, borderColor: colors.borderPurple },
  wordChipUsed: { backgroundColor: colors.success, borderColor: colors.success },
  wordChipGood: { backgroundColor: colors.successLight, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.full },
  wordChipText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.primary },
  wordChipTextUsed: { color: '#FFF' },
  counterRow: { alignItems: 'center' },
  counterText: { fontSize: fontSize.md, fontWeight: '600', color: colors.textSecondary },
  counterTextReady: { color: colors.success, fontWeight: '800' },
  textArea: { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, fontSize: fontSize.md, color: colors.text, borderWidth: 2, borderColor: colors.border, minHeight: 180, lineHeight: 24, ...shadows.small },
  charCount: { fontSize: 11, color: colors.textLight, textAlign: 'right' },
  submitBtn: { borderRadius: radius.xl, overflow: 'hidden', ...shadows.medium },
  submitBtnDisabled: { opacity: 0.7 },
  submitBtnGradient: { padding: spacing.md, alignItems: 'center' },
  evaluatingRow: { backgroundColor: colors.primary, padding: spacing.md, flexDirection: 'row', gap: spacing.sm, alignItems: 'center', justifyContent: 'center', borderRadius: radius.xl },
  submitBtnText: { color: '#FFF', fontSize: fontSize.lg, fontWeight: '800' },
  skipChallengeBtn: { alignItems: 'center', padding: spacing.sm },
  skipChallengeBtnText: { color: colors.textLight, fontSize: fontSize.sm },
  // Result styles
  resultContainer: { paddingBottom: 48 },
  resultHeader: { paddingTop: 52, paddingBottom: 32, alignItems: 'center', gap: spacing.md, borderBottomLeftRadius: 32, borderBottomRightRadius: 32 },
  resultEmoji: { fontSize: 64 },
  resultTitle: { fontSize: fontSize.xxl, fontWeight: '800', color: '#FFF' },
  scoreCircle: { backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: radius.full, width: 80, height: 80, justifyContent: 'center', alignItems: 'center', flexDirection: 'row', alignItems: 'baseline', gap: 2 },
  scoreNumber: { fontSize: 32, fontWeight: '800', color: '#FFF' },
  scoreDivider: { fontSize: fontSize.lg, color: 'rgba(255,255,255,0.8)', fontWeight: '600' },
  resultBody: { padding: spacing.md, gap: spacing.md },
  resultCard: { backgroundColor: colors.surface, borderRadius: radius.xl, padding: spacing.md, ...shadows.small },
  resultCardTitle: { fontSize: fontSize.sm, fontWeight: '700', color: colors.textSecondary, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  naturalText: { fontSize: fontSize.lg, fontWeight: '700', color: colors.text },
  errorItem: { backgroundColor: colors.surfaceAlt, borderRadius: radius.md, padding: spacing.sm, marginBottom: 6, gap: 2 },
  errorOriginal: { fontSize: fontSize.sm, color: colors.error, fontWeight: '600' },
  errorCorrected: { fontSize: fontSize.sm, color: colors.success, fontWeight: '600' },
  errorExplanation: { fontSize: fontSize.sm, color: colors.textSecondary, fontStyle: 'italic' },
  feedbackCard: { backgroundColor: colors.primaryLight, borderWidth: 1, borderColor: colors.borderPurple },
  feedbackText: { fontSize: fontSize.md, color: colors.primary, lineHeight: 22 },
  paragraphPreview: { fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 22, fontStyle: 'italic' },
  doneBtn: { borderRadius: radius.xl, overflow: 'hidden', ...shadows.medium },
  doneBtnGradient: { padding: spacing.md, alignItems: 'center' },
  doneBtnText: { color: '#FFF', fontSize: fontSize.lg, fontWeight: '800' },
  retryBtn: { backgroundColor: colors.primaryLight, borderRadius: radius.xl, padding: spacing.md, alignItems: 'center', borderWidth: 2, borderColor: colors.primary },
  retryBtnText: { color: colors.primary, fontSize: fontSize.md, fontWeight: '700' },
  skipBtn: { alignItems: 'center', padding: spacing.sm },
  skipBtnText: { color: colors.textLight, fontSize: fontSize.sm },
});
