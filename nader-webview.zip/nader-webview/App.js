import React, { useState, useEffect } from 'react';
import { StyleSheet, View, StatusBar, ActivityIndicator, Text } from 'react-native';
import { WebView } from 'react-native-webview';
import { Asset } from 'expo-asset';
import * as FileSystem from 'expo-file-system';

export default function App() {
  const [htmlContent, setHtmlContent] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadHTML();
  }, []);

  const loadHTML = async () => {
    try {
      // Load the bundled HTML asset
      const [asset] = await Asset.loadAsync(require('./assets/app.html'));

      // Read its content
      const content = await FileSystem.readAsStringAsync(asset.localUri);
      setHtmlContent(content);
    } catch (e) {
      console.error('Failed to load HTML:', e);
      setError(e.message);
    }
  };

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>خطأ في التحميل: {error}</Text>
      </View>
    );
  }

  if (!htmlContent) {
    return (
      <View style={styles.center}>
        <Text style={styles.loadingEmoji}>🐘</Text>
        <ActivityIndicator size="large" color="#7C3AED" style={{ marginTop: 16 }} />
        <Text style={styles.loadingText}>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#7C3AED" />
      <WebView
        source={{ html: htmlContent, baseUrl: 'https://localhost' }}
        style={styles.webview}
        originWhitelist={['*']}
        allowFileAccess={true}
        allowUniversalAccessFromFileURLs={true}
        allowFileAccessFromFileURLs={true}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={false}
        mixedContentMode="always"
        // Allow Groq API calls and Pollinations images
        onShouldStartLoadWithRequest={() => true}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#7C3AED',
  },
  webview: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  center: {
    flex: 1,
    backgroundColor: '#7C3AED',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingEmoji: {
    fontSize: 72,
  },
  loadingText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 16,
    marginTop: 12,
  },
  errorText: {
    color: '#FF6B6B',
    textAlign: 'center',
    padding: 24,
  },
});
