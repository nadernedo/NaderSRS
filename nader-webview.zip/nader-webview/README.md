# 🐘 Nader App — دليل بناء الـ APK

## كيف يعمل؟
التطبيق يستخدم **Expo + WebView** لتشغيل الـ React Web App داخل موبايل أندرويد.
- الكود الكامل موجود في `assets/app.html`
- `App.js` يحمّله في WebView فقط
- الكل يشتغل offline ما عدا توليد الكلمات بالـ AI

---

## 🚀 خطوات بناء الـ APK (مجاناً بالكامل)

### المتطلبات
- [Node.js 18+](https://nodejs.org)
- حساب مجاني على [expo.dev](https://expo.dev)

---

### الخطوة 1: تثبيت الأدوات
```bash
npm install -g eas-cli
```

### الخطوة 2: داخل مجلد المشروع
```bash
cd nader-webview
npm install
```

### الخطوة 3: تسجيل دخول Expo
```bash
eas login
```

### الخطوة 4: ربط المشروع (مرة واحدة فقط)
```bash
eas init
```
سيعطيك `projectId` — أضفه في `app.json` هنا:
```json
"extra": { "eas": { "projectId": "ID_هنا" } }
```

### الخطوة 5: 🎯 بناء الـ APK
```bash
eas build -p android --profile preview
```
انتظر 5-10 دقائق ← رابط APK مباشر للتحميل! ✅

---

## 🔑 إعداد Groq API داخل التطبيق
1. افتح التطبيق
2. اذهب لـ **Settings** ← **Groq API**
3. احصل على مفتاح مجاني من [console.groq.com](https://console.groq.com)
4. أدخله واضغط "حفظ"

---

## 🧪 تشغيل محلي (للتجربة)
```bash
npm install
npx expo start
```
امسح QR بتطبيق **Expo Go** على جوالك.

---

## 📁 الملفات
```
nader-webview/
├── App.js              ← يحمّل HTML في WebView
├── app.json            ← إعدادات Expo
├── eas.json            ← إعدادات البناء
├── package.json        ← الـ dependencies
└── assets/
    ├── app.html        ← التطبيق الكامل (115KB)
    ├── icon.png        ← أيقونة التطبيق
    └── splash.png      ← شاشة البداية
```
